package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReferenceDetailsPage {

	 private WebDriver driver;
	    private WebDriverWait wait;

	    public ReferenceDetailsPage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }
	    
	    By referencestab = By.xpath("//ul[@class='nav nav-tabs m-0']//child::li[7]");
	   
	    By contacttype = By.id("select2-contactType-container");
	    By Email = By.id("email");
	    By Status = By.id("select2-status-container");
	    By select2SearchInput = By.cssSelector("input.select2-search__field");
	    private By clickVerifyEmail = By.id("sendOtpEmail");
	    private By enterEmailOtp = By.id("emailOtp");
	    private By verifyEmail = By.id("emailVerify");
	            By save  =By.id("referanceSave");
	   
	       
	    
	    public void selectcontacttype(String value) {
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	 wait.until(ExpectedConditions.elementToBeClickable((contacttype))).click();
    	 WebElement searchBox = wait.until(
    		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
    	 searchBox.clear();
    	    searchBox.sendKeys(value);
    	    searchBox.sendKeys(Keys.ENTER);
			   
	    	
	    }
	 public void Enteremail(String value) {
		 WebElement block = driver.findElement(Email);
	        block.clear();
	        block.sendKeys(value);
		 
	 }
	 public void selectstatus(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Status))).click();
		    WebElement searchBox = wait.until(
    		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
    	 searchBox.clear();
    	    searchBox.sendKeys(value);
    	    searchBox.sendKeys(Keys.ENTER);
		    
		 
	 }
	    
	   
	  public void verifyEmailOtp() throws InterruptedException {     
	        WebElement sendOtpBtn = wait.until(
	                ExpectedConditions.refreshed(
	                        ExpectedConditions.elementToBeClickable(clickVerifyEmail)
	                )
	        );
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sendOtpBtn);
	        sendOtpBtn.click();

	        Thread.sleep(3000); // wait for popup or OTP field to appear

	        // ------------------------
	        // 2️⃣ Close popup if any
	        // ------------------------
	        try {
	            wait.until(ExpectedConditions.elementToBeClickable(
	                    By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
	            )).click();
	        } catch (Exception ignored) {}

	        // ------------------------
	        // 3️⃣ Enter OTP
	        // ------------------------
	        WebElement otpInput = wait.until(
	                ExpectedConditions.refreshed(
	                        ExpectedConditions.visibilityOfElementLocated(enterEmailOtp)
	                )
	        );

	        otpInput.clear();
	        otpInput.sendKeys("123456");
	        System.out.println("Email OTP entered successfully.");

	        // ------------------------
	        // 4️⃣ Click "Verify OTP"
	        // ------------------------
	        WebElement verifyBtn = wait.until(
	                ExpectedConditions.refreshed(
	                        ExpectedConditions.elementToBeClickable(verifyEmail)
	                )
	        );

	        try {
	            verifyBtn.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", verifyBtn);
	        }

	        // ------------------------
	        // 5️⃣ Close final popup if any
	        // ------------------------
	        try {
	            WebElement popupBtn = wait.until(
	                    ExpectedConditions.elementToBeClickable(
	                            By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
	                    )
	            );
	            popupBtn.click();
	        } catch (Exception ignored) {}

	        System.out.println("Email OTP Verified Successfully!");

	        Thread.sleep(3000);
	    }
	
	  public void save(){
			 WebElement savebtn = driver.findElement(save);
			   savebtn.click();
		}





	  public void clickreferencetab() {
				WebElement tab = driver.findElement(referencestab);
				tab.click();
			}
		    
		
	  }

