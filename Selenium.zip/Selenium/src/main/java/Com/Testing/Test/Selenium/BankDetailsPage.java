package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BankDetailsPage {
	 private WebDriver driver;
	    private WebDriverWait wait;

	    public BankDetailsPage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }
    By Bankdetailstab = By.xpath("//ul[@class='nav nav-tabs m-0']//child::li[5]");
	By Custtype = By.id("select2-custType-container");
	By Bankname = By.id("select2-bankName-container");
	By Accountnumber = By.id("accountNumber");
	By IBANnumber = By.id("ibanNumber");
	By select2SearchInput = By.cssSelector("input.select2-search__field");
	By Currency = By.id("select2-currency-container");
	By Overseasbank = By.id("select2-overSeaBnkAct-container");
	By Isdurbaccount = By.id("select2-isDisbursementAcc-container");
	By IsrepAccount = By.id("select2-isRepaymentYN-container");
	By save = By.id("saveBank");
	    // Page Actions //
	
	public void Clickbankdetailstab() {
		WebElement tab = driver.findElement(Bankdetailstab);
		tab.click();
		}
	
	public void selectcustomertype(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Custtype))).click();

		    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//li[contains(@id, 'select2-custType') and text()='" + value + "']")));
		    
		    addrOption.click();
	}
	public void selectbankname(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Bankname))).click();
		    WebElement searchBox = wait.until(
 		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 	 searchBox.clear();
 	    searchBox.sendKeys(value);
 	    searchBox.sendKeys(Keys.ENTER);
		    
	}
	public void Enteraccountno(String accno) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Accountnumber));
        input.clear();
        input.sendKeys(accno);
		
	}
	
	public void EnterIBANno(String IBAN) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(IBANnumber));
        input.clear();
        input.sendKeys(IBAN);	
	}
	
	public void selectcurrency(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Currency))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectisoverseas(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Overseasbank))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectisdisursementacc(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Isdurbaccount))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectisrepacc(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((IsrepAccount))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}

	public void save(){
		 WebElement savebtn = driver.findElement(save);
		 savebtn.click();
		 }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
