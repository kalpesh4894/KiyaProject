package Com.Testing.Test.Selenium.Utils;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import Com.Testing.Test.Selenium.Driver.DriverManager;

public class ScreenshotsListener implements ITestListener {
	
	
	  @Override
	    public void onTestFailure(ITestResult result) {
		    // Get the driver from DriverManager
		        Screenshots.captureScreenshot(
		            DriverManager.getDriver(), 
		            result.getName() + "_" + System.currentTimeMillis()
		        );
		    }

	    // other ITestListener methods can be empty
	    @Override public void onTestStart(ITestResult result) {}
	    @Override public void onTestSuccess(ITestResult result) {}
	    @Override public void onTestSkipped(ITestResult result) {}
	    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
	    @Override public void onStart(ITestContext context) {}
	    @Override public void onFinish(ITestContext context) {}
	}
	
	


