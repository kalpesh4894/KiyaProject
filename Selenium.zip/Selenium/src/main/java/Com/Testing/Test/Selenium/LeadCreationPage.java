package Com.Testing.Test.Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeadCreationPage {

	WebDriver driver;
	
	  // 1️⃣ Click to open dropdown
	  // Open dropdown
    @FindBy(id = "select2-idType-container")
    private WebElement idTypeDropdown;

    // Select "CIVIL ID Number"
    @FindBy(id = "select2-idType-result-dure-20001")
    private WebElement civilIdOption;

    // Civil ID input field
    @FindBy(id = "civilid")
    private WebElement civilIdInput;


    // ---------- ACTION METHODS ---------- //

    public void selectCivilIdType() {
        idTypeDropdown.click();     // open dropdown
        civilIdOption.click();      // click Civil ID Number option
    }

    public void enterCivilIdValue(long civilIdNumber) {
        civilIdInput.sendKeys(String.valueOf(civilIdNumber));
    }

    // Usage
    lead.selectCivilIdType();                // First select the dropdown option
    lead.enterCivilIdValue(123456789102L);   // Then enter Civil ID

    @FindBy(xpath = "//*[@id='fNameDiv']")
    private WebElement firstNameInput;

    // Method to enter name
    public void enterFirstName(String name) {
        firstNameInput.sendKeys(name);
    }
    @FindBy(xpath = "//*[@id='firstNameArabicDiv']")
    private WebElement firstNameArabicInput;

    // Method to enter Arabic name
    public void enterFirstNameArabic(String name) {
        firstNameArabicInput.sendKeys(name);
    }
 // Nationality dropdown container
    @FindBy(xpath = "//*[@id='select2-nationalityId-container']")
    private WebElement nationalityDropdown;

    // Option "DZA"
    @FindBy(xpath = "//*[@id='select2-nationalityId-result-yaab-DZA']")
    private WebElement nationalityOption;

    @FindBy(xpath = "//*[@id='emailDiv']")
    private WebElement emailInput;

    // Method to enter email
    public void enterEmail(String email) {
        emailInput.sendKeys(email);
    }

    
	
    @FindBy(xpath = "//*[@id='mobileDiv']")
    private WebElement mobileInput;

    // Method to enter mobile number
    public void enterMobileNumber(String mobile) {
        mobileInput.sendKeys(mobile);
    }

    
 // Product dropdown container
    @FindBy(xpath = "//*[@id='select2-product-container']")
    private WebElement productDropdown;

    // Option to select (product with value "01")
    @FindBy(xpath = "//*[@id='select2-product-result-6hw7-01']")
    private WebElement productOption;

    
 // Sub-product dropdown container
    @FindBy(xpath = "//*[@id='select2-subProduct-container']")
    private WebElement subProductDropdown;

    // Option to select
    @FindBy(xpath = "//*[@id='subProductDiv']/div/span")
    private WebElement subProductOption;

    
    //verify email click
    @FindBy(xpath = "//*[@id='sendOtpEmail']")
    private WebElement sendOtpEmailButton;

    // Method to click
    public void clickSendOtpEmail() {
        sendOtpEmailButton.click();
    }
    // handle alert 
    
    Alert alert = driver.switchTo().alert();
    alert.accept();
    
    
    
    
    
    
    
    //enter email pwd
    @FindBy(xpath = "//*[@id='emailOtpDiv']/div")
    private WebElement emailOtpInput;

    // Method to enter OTP
    public void enterEmailOtp() {
        emailOtpInput.sendKeys("123456");  // hardcoded OTP
    }

    //click verify mo pwd @FindBy(xpath = "//*[@id='sendOtpMobile']")
    private WebElement sendOtpMobileButton;

 // Method to click
 public void clickSendOtpMobile() {
     sendOtpMobileButton.click();
 }

 //click on operation completed successfully pop up
 
 
 Alert alert = driver.switchTo().alert();
 alert.accept();
 
 
 
    
    
    
    
    
}
