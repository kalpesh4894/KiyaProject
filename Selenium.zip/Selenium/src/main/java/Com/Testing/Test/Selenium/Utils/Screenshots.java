package Com.Testing.Test.Selenium.Utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

public class Screenshots {

    // Capture screenshot and save with a file name
    public static void captureScreenshot(WebDriver driver, String fileName) {
        try {
            // Take screenshot
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            
            // Create folder if not exists
            File destDir = new File("D:\\KFIC\\KFICSNAPS");
            if (!destDir.exists()) {
                destDir.mkdirs();
            }

            // Save file
            File dest = new File(destDir, fileName + ".png");
            FileUtils.copyFile(src, dest);

            System.out.println("Screenshot saved: " + dest.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

