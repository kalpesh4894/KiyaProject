package Com.Testing.Test.Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;

    @FindBy(id = "loginId")
    WebElement usernameTxt;

    @FindBy(id = "uiPwd")
    WebElement passwordTxt;

    @FindBy(id = "userLogin")
    WebElement loginBtn;

    // Constructor
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        // Initialize explicit wait
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public DashboardPage login(String user, String pass) {
        // Wait and send username
        wait.until(ExpectedConditions.visibilityOf(usernameTxt)).sendKeys(user);

        // Wait and send password
        wait.until(ExpectedConditions.visibilityOf(passwordTxt)).sendKeys(pass);

        // Wait and click login button
        wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();

        // Return DashboardPage object
        return new DashboardPage(driver);
    }
}
