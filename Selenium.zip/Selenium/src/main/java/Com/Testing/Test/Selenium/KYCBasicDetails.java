package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class KYCBasicDetails {
	
	  private WebDriver driver;
	    private WebDriverWait wait;

	    public KYCBasicDetails(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }
	
	
	
	
	
	By kyc = By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/main/div/div/div/div/div/div/div[5]/nav/ul/li[2]/a");
    By basicdetails = By.xpath("//*[@id=\"myTab\"]/li[1]/a");

	By baseedit = By.cssSelector("a.editBtn");
	   //Customer Details //
	By title = By.xpath("//*[@id=\"select2-title-container\"]");

	By titledrop = By.id("select2-title-result-fetb-1");
	By visatype = By.xpath("//*[@id=\"select2-visaType-container\"]");
	By visadrop = By.xpath("//*[@id=\"select2-visaType-result-qkgr-02\"]");
	By Edulevel = By.id("select2-educationLevel-container");
	By Edudrop = By.xpath("//*[@id=\"select2-educationLevel-result-m0om-03\"]");
	By DOB = By.id("dateOfBirth");
	By maritalstat = By.xpath("//*[@id=\"select2-maritalStatus-container\"]");
	By maritalstatdrop  = By.xpath("//*[@id=\"select2-maritalStatus-result-y9nq-4\"]");
	By nofdependants = By.id("noOfDependents");
	By ispep = By.id("select2-isPEPRetail-container");
	By ispepdrop = By.id("select2-isPEPRetail-result-ccod-2");
	By isRtoPep = By.id("select2-isRelativeToPEP-container");
	By isRtoPepdrop = By.id("select2-isRelativeToPEP-result-pj5d-2");
	By relparttkfc =  By.id("select2-relatedPartyToKFICRetail-container");
	By relparttkfcdrop = By.id("relatedPartyToKFICRetailDiv");
	By taxrescoun = By.id("select2-taxResidentInAnyCountry-container");
	By taxrescoundrop = By.id("select2-taxResidentInAnyCountry-result-x7q8-2");
	By passport = By.xpath("//*[@id=\"select2-doHoldAmericanPassport-container\"]");
	By passportdrop = By.xpath("//*[@id=\"select2-doHoldAmericanPassport-result-kfz2-2\"]");
	By disability = By.xpath("//*[@id=\"select2-disabilityCondition-container\"]");
	By disabilitydrop = By.xpath("//*[@id=\"select2-disabilityCondition-result-mkuv-2\"]");
	By savebtn = By.id("basicDetailsSave");
	
	       //Page Actions //
	
	public void clickKYC() {
		driver.findElement(kyc).click();
		
	}
	public void clickbasicdetails() {
		driver.findElement(basicdetails).click();
	}
	public void editB() throws InterruptedException {
		WebElement lt = wait.until(ExpectedConditions.visibilityOfElementLocated(baseedit));
		lt.click();
		Thread.sleep(4000);
		
	}

	public void titleselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    // Step 1. Click the title box
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-title-container"))).click();

	    // Step 2. Select item based on text
	    WebElement titleOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-title') and text()='" + titleText + "']")));
	    
	    titleOption.click();
	}

	public void visaselect(String visa) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    // Step 1. Click the title box
	    WebElement as =wait.until(ExpectedConditions.elementToBeClickable(visatype));
	     as.click();

	    // Step 2. Select item based on text
	    WebElement visaOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@id,'select2-visaType-result') and text()='" + visa + "']")));
	    
	    visaOption.click();
				
	}
	public void educationSelect(String education) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(Edulevel)).click();

	    WebElement eduOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-educationLevel') and normalize-space(text())='" + education + "']"))
	    );

	    eduOption.click();
	}

	public void EnterDOB(String date) {
		  WebElement dobField = wait.until(ExpectedConditions.visibilityOfElementLocated(DOB));
	        dobField.clear();
	        dobField.sendKeys(date);
	}
	public void maritalStatusSelect(String status) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(maritalstat)).click();

	    WebElement statusOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-maritalStatus') and normalize-space(text())='" + status + "']"))
	    );

	    statusOption.click();
	}

	public void enterdependants(String number) {
		 WebElement dep = driver.findElement(nofdependants);
	        dep.clear();
	        dep.sendKeys(number);
	}
	public void isPEPSelect(String pep) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	    wait.until(ExpectedConditions.elementToBeClickable(ispep)).click();

	    WebElement pepOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-isPEPRetail') and normalize-space(text())='" + pep + "']"))
	    );

	    pepOption.click();
	}

	public void isRelativeToPEPSelect(String rel) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	    wait.until(ExpectedConditions.elementToBeClickable(isRtoPep)).click();

	    WebElement relOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-isRelativeToPEP') and normalize-space(text())='" + rel + "']"))
	    );

	    relOption.click();
	}

	public void relatedPartyKFICSelect(String rel) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(relparttkfc)).click();

	    WebElement rtkOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-relatedPartyToKFICRetail') and normalize-space(text())='" + rel + "']"))
	    );

	    rtkOption.click();
	}

	public void taxResidentSelect(String tax) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(taxrescoun)).click();

	    WebElement taxOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-taxResidentInAnyCountry') and normalize-space(text())='" + tax + "']"))
	    );

	    taxOption.click();
	}

	public void passportSelect(String passportAns) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(passport)).click();

	    WebElement passOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-doHoldAmericanPassport') and normalize-space(text())='" + passportAns + "']"))
	    );

	    passOption.click();
	}

	public void disabilitySelect(String disabilityAns) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    wait.until(ExpectedConditions.elementToBeClickable(disability)).click();

	    WebElement disOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id,'select2-disabilityCondition') and normalize-space(text())='" + disabilityAns + "']"))
	    );

	    disOption.click();
	}

	public void save() {
		
		driver.findElement(savebtn).click();
		}
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
