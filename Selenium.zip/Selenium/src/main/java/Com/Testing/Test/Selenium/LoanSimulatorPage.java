package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoanSimulatorPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public LoanSimulatorPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // -------------------------------
    // Locators
    // -------------------------------
                      
    private By Purpose = By.id("select2-purposeMap-container");
    private By purpSelect =By.id("select2-purposeMap-result-5nmd-9");
    By Make = By.id("select2-makeLoanMap-container");
    By Model = By.id("select2-modelLoanMap-container");
    By Region = By.id("select2-regionLoanMap-container");
    By search = By.cssSelector("input.select2-search__field");
    private By AssetPrice = By.id("assetPrice");
 //   private By DPTC = By.id("downPaidToCompany");
    private By DPTC = By.xpath("//*[@id='downPaidToCompany']");
//    private By DPTD = By.id("downPaidToDealer");
    private By Tenure = By.id("tenure");
    private By RepType = By.id("select2-repayTypeMap-container");
    private By Principle = By.id("select2-principleEmiFreqMap-container");
    private By RepaymentCalcOn = By.id("select2-repayCalOnMap-container");
    private By LoanStartDate = By.id("loanStartDate");
    private By FirstInstDate = By.id("firstEmiDate");
    private By CalcEmi = By.id("saveAndGenerateBtn");
    private By closeloansimpage = By.id("consentModClsBtn");
                                    
    // -------------------------------
    // Select2 helper
    // -------------------------------
    public void selectFromSelect2(By dropdown, String value) throws InterruptedException {
        WebElement dd = wait.until(ExpectedConditions.elementToBeClickable(dropdown));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dd);
        dd.click();

        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@class='select2-search__field']")));
        input.sendKeys(value);
        Thread.sleep(500);
        input.sendKeys(Keys.ENTER);
        Thread.sleep(500);
    }

    // -------------------------------
    // Actions
    // -------------------------------
   
    
    public void selectVehiclePurpose() throws InterruptedException {
        //  Click on the Purpose dropdown
        WebElement purposeDropdown = wait.until(
                ExpectedConditions.elementToBeClickable(By.id("select2-purposeMap-container"))
        );
        purposeDropdown.click();

        // Type "Vehicle Purchase" in the search box
        WebElement input = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='select2-search__field']"))
        );
        input.sendKeys("Vehicle Purchase");

        //  Press Enter to select
        input.sendKeys(Keys.ENTER);

        Thread.sleep(500); // small wait to ensure selection is registered
    }

 // -------------------------------
 // Vehicle Details Selection
 // -------------------------------

 public void selectMake(String make) throws InterruptedException {
     selectFromSelect2(Make, make);
 }

 public void selectModel(String model) throws InterruptedException {
     selectFromSelect2(Model, model);
 }

 public void selectRegion(String region) throws InterruptedException {
     selectFromSelect2(Region, region);
 }


    public void enterAssetPrice(long i) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(AssetPrice));
        el.clear();
        el.sendKeys(String.valueOf(i)); // ✅ convert long to String
    }


    public void enterDPTC(long i) throws InterruptedException {

        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(DPTC));

        // Scroll into view
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);

        // Activate the field
        el.click();

        // Clear manually (keypress-safe)
        el.sendKeys(Keys.CONTROL, "a");
        el.sendKeys(Keys.BACK_SPACE);

        // Type digit-by-digit as real keypresses
        String value = String.valueOf(i);
        for (char c : value.toCharArray()) {
            el.sendKeys(String.valueOf(c));   // each key triggers onkeypress correctly
            Thread.sleep(150);                // small delay to avoid UI overriding
        }
    }

  

    public void enterTenure(long i) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(Tenure));
        el.clear();
        el.sendKeys(String.valueOf(i));
    }

    public void selectRepaymentType(String type) throws InterruptedException {
        selectFromSelect2(RepType, type);
    }

    public void selectPrincipalFrequency(String frequency) throws InterruptedException {
        selectFromSelect2(Principle, frequency);
    }

    public void selectRepaymentCalc(String calcOption) throws InterruptedException {
        selectFromSelect2(RepaymentCalcOn, calcOption);
    }

    public void enterLoanStartDate(String date) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(LoanStartDate));
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='" + date + "';", el);
    }

    public void enterFirstInstallmentDate(String date) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(FirstInstDate));
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='" + date + "';", el);
    }

//    public void clickCalculateEMI() throws InterruptedException {
//        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(CalcEmi));
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btn);
//        btn.click();
//        Thread.sleep(5000);
//        try {
//            wait.until(ExpectedConditions.elementToBeClickable(
//                    By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
//            )).click();
//        } catch (Exception ignored) {}
//
//    }
    
    public void clickCalculateEMI() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(CalcEmi));

        // scroll to the button
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btn);
        btn.click();

        // Wait for possible popup — non-blocking
        try {
            WebElement popupBtn = new WebDriverWait(driver, Duration.ofSeconds(8))
                    .until(ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                "//button[contains(.,'OK') or contains(.,'Close') or contains(.,'Yes') or contains(.,'Confirm') or contains(@class,'swal')]"
                            )
                    ));
            popupBtn.click();
            Thread.sleep(10000);
            System.out.println("Popup clicked successfully.");
        } catch (Exception e) {
            System.out.println("No popup appeared. Proceeding...");
        }
    }

    
   
    
    public void close_loansim() {
    	
    	 WebElement cl = wait.until(ExpectedConditions.elementToBeClickable(closeloansimpage));
         ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cl);
         cl.click();	
    	   	
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
