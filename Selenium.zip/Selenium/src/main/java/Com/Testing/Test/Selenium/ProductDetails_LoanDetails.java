package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetails_LoanDetails {
	private WebDriver driver;
    private WebDriverWait wait;

    public ProductDetails_LoanDetails(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
	
	
	
	
	By Loandetailstab = By.cssSelector("a.nav-link[href='#menu2']");
	By edit = By.cssSelector("a.editBtn");
	By Repaymentschedule = By.id("repaymentBtn1");
	By closeschedule =	By.className("mh-cross");
	By Save = By.id("saveproduct");
	
	
	   //Page Actions 
	
	public void clickloandetails() {
		WebElement loandetls = wait.until(ExpectedConditions.visibilityOfElementLocated(Loandetailstab));
	    loandetls.click();
	}
	public void editrecord() {
	    WebElement edi = wait.until(ExpectedConditions.visibilityOfElementLocated(edit));
	    edi.click();
	}
	
	public void GenerateRepaymentSchedule() {
		WebElement generate = wait.until(ExpectedConditions.visibilityOfElementLocated(Repaymentschedule));
	    generate.click();
	}
	
	public void closeschedule() {
		WebElement close = wait.until(ExpectedConditions.visibilityOfElementLocated(closeschedule));
	       close.click();
		
	}
	public void save() {
		WebElement savedet = wait.until(ExpectedConditions.visibilityOfElementLocated(Save));
	    savedet.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
