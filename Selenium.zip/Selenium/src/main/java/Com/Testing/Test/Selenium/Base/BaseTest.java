package Com.Testing.Test.Selenium.Base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import Com.Testing.Test.Selenium.Driver.DriverManager;
import Com.Testing.Test.Selenium.Utils.PropertyReader;

public class BaseTest {

    protected WebDriver driver;
    
   
    private Properties prop;
    private PropertyReader pr;
    public static String browsername;
    
    
    @BeforeTest
    public void getProperty() {
        pr = new PropertyReader();
        prop = pr.init_prop();
        browsername = prop.getProperty("browser");
        
    }


    @BeforeClass
    public void setUp() {
    	
    	
    	
     //   pr.init_prop(browsername); 
        // read browser from config file

        System.out.println("+++++++++++++"+browsername);
        if (browsername == null) browsername = "chrome";
        

        switch (browsername.toLowerCase()) {

            case "edge":
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("start-maximized");
                driver = new EdgeDriver(edgeOptions);
                break;

            case "chrome":
            default:
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("start-maximized");
                driver = new ChromeDriver(chromeOptions);
                break;
        }

        // ✔ Store driver in DriverManager for Listeners (screenshots, logs)
        DriverManager.setDriver(driver);

        // ✔ Implicit Wait (GLOBAL)
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // ✔ Maximize Window (in case options ignore)
        driver.manage().window().maximize();
    }

    public WebDriver getDriver() {
        return driver;
    }

//    @AfterClass
//    public void tearDown() {
//        if (driver != null) {
//            driver.quit();
//            DriverManager.setDriver(null);
//        }
//    }

    public void handlePopupAfterSave(String successMessage) {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));

        try {
            WebElement popupBtn = wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
                )
            );

            popupBtn.click();
            Assert.fail("Unexpected popup appeared after Save");

        } catch (TimeoutException e) {
            System.out.println(successMessage);
        }
    }
    

 public void PageScrollUp() throws InterruptedException {
    	
    	JavascriptExecutor js1 = (JavascriptExecutor) driver;
        js1.executeScript("window.scrollBy(0, -500);");
        Thread.sleep(3000);
    }
    
    public void PageScrollDown() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 300);");
        Thread.sleep(3000);
    }
    public void PageScrollDown1() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 450);");
        Thread.sleep(3000);
    }
    public void GoToDDEStage() throws InterruptedException {
    	PageScrollDown1();
    	By DDE = By.cssSelector("a[href*='openApplicationTabs']");

      	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		   wait.until(ExpectedConditions.elementToBeClickable((DDE))).click();
		  
    }


   














}
