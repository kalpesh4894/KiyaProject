package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class KYCIdentificationDetailsPage {

	
	 private WebDriver driver;
	    private WebDriverWait wait;

	    public KYCIdentificationDetailsPage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }
	
	
	By identitab = By.xpath("//ul[@class='nav nav-tabs m-0']//child::li[3]");
	By editidenty = By.xpath("//*[@id=\"dt-authdata\"]/tbody/tr/td[5]/a");
	By issuedate = By.id("issueDate");
	By expirydate = By.id("expiryDate");
	By savid = By.id("saveIdenty");
	
	//Page Actions //
	
	public void clickIdtab() {
		
		driver.findElement(identitab).click();
	}
	
	public void clickedi() throws InterruptedException {
		WebElement idn  = wait.until(ExpectedConditions.visibilityOfElementLocated(editidenty));
		idn.click();
		Thread.sleep(4000);
	}
	
	

	public void SelectIssueDate() {

	    String year = "2022";
	    String month = "Jul";
	    String day = "20";

	    // Open date picker
	    driver.findElement(By.id("issueDate")).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}

	public void SelectExpriyDate() {

	    String year = "2040";
	    String month = "Jul";
	    String day = "25";

	    // Open date picker
	    driver.findElement(By.id("expiryDate")).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}	
	
	//For reducing code duplicacy we can reuse above two datepicker methods//
	
 public void saveidenty() {
		
	 List<WebElement> savebtn = driver.findElements(By.id("saveIdenty"));
	  savebtn.get(0).click();
		}
	
	
	
 

 


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
