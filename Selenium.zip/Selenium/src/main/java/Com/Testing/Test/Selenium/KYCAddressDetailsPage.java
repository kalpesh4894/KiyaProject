package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class KYCAddressDetailsPage {
	
	 private WebDriver driver;
	    private WebDriverWait wait;

	    public KYCAddressDetailsPage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }
	
	By addrdetailstab = By.xpath("//ul[@class='nav nav-tabs m-0']//child::li[2]");
//	By AddDetails = By.id("//*[@id=\"myTab\"]/li[2]/a");
	By Addedit = By.xpath("//*[@id=\"dt-authdata\"]/tbody/tr/td[5]/a");
	
	
	By Addtype = By.xpath("//*[@id=\"select2-addressType-container\"]");
	By Addtypedrop = By.xpath("//*[@id=\"select2-addressType-result-m5hq-4\"]");
	By chckbx1 = By.id("isPermantAdd");
	By chckbx2 = By.id("isBusinessAdd");
	By Addstart = By.xpath("//*[@id=\"addressStartDate\"]");
	By Country = By.xpath("//*[@id=\"select2-country-container\"]");
	By Countrydrop = By.xpath("//*[@id=\"select2-country-result-504r-KWT\"]");
	
	By district = By.xpath("//*[@id=\"select2-district-container\"]");
	By distdrop = By.xpath("//*[@id=\"select2-district-result-um9b-ASM\"]");
	By Area = By.xpath("//*[@id=\"select2-area-container\"]");
	By Areadrop = By.xpath("//*[@id=\"select2-area-result-zg05-123\"]");
	By Block = By.id("block");
	By Street = By.id("street");
	By Building = By.id("building");
	By BuildingType = By.id("buildingType");
	By unittype = By.xpath("//*[@id=\"select2-unitType-container\"]");
	By unittypedrop = By.xpath("//*[@id=\"select2-unitType-result-nfbt-1\"]");
	By unitno = By.id("unitNo");
	By floor = By.id("floor");
	By Save = By.id("saveAddr");
	
	
       //Page Actions //
	
	
	public void clickaddressdetails() {
		driver.findElement(addrdetailstab).click();
	}
	public void editA() throws InterruptedException {
		WebElement lt = wait.until(ExpectedConditions.visibilityOfElementLocated(Addedit));
		lt.click();
		Thread.sleep(4000);
		
	}
	
	public void Addressselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-addressType-container"))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-addressType') and text()='" + titleText + "']")));
	    
	    addrOption.click();
	}
	
	public void selectcheckboxes() {
		WebElement lt = wait.until(ExpectedConditions.visibilityOfElementLocated(chckbx1));
		lt.click();

		WebElement los = wait.until(ExpectedConditions.visibilityOfElementLocated(chckbx2));
		los.click();
		
		
	}
	
	public void SelectAddStartDate(String date) {
		 WebElement AddStrField = wait.until(ExpectedConditions.visibilityOfElementLocated(Addstart));
	        AddStrField.clear();
	        AddStrField.sendKeys(date);
	}
		 
		 
	 
	public void Countryselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-country-container"))).click();

	    WebElement CountryOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-country') and text()='" + titleText + "']")));
	    
	    CountryOption.click();
	}

	
	public void Districtselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-district-container"))).click();

	    WebElement DistrictOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-district') and text()='" + titleText + "']")));
	    
	    DistrictOption.click();
	}
	public void Areaselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-area-container"))).click();

	    WebElement AreaOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-area') and text()='" + titleText + "']")));
	    
	    AreaOption.click();
	}

	
	public void enterBlock(String number) {
		 WebElement block = driver.findElement(Block);
	        block.clear();
	        block.sendKeys(number);
	}
	
	public void enterStreet(String number) {
		 WebElement street = driver.findElement(Street);
	        street.clear();
	        street.sendKeys(number);
	}
	
	public void enterBuilding(String number) {
		 WebElement building = driver.findElement(Building);
	        building.clear();
	        building.sendKeys(number);
	}
	
	public void enterbuildingtype(String type) {
		 WebElement buildingtype = driver.findElement(BuildingType);
	        buildingtype.clear();
	        buildingtype.sendKeys(type);
	}
	
	public void enterunitno(String number) {
		 WebElement building = driver.findElement(unitno);
	        building.clear();
	        building.sendKeys(number);
	}
	public void enterfloor(String number) {
		 WebElement Floor = driver.findElement(floor);
	        Floor.clear();
	        Floor.sendKeys(number);
	}
	

	public void Unittypeselect(String titleText) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(By.id("select2-unitType-container"))).click();

	    WebElement UnitOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-unitType') and text()='" + titleText + "']")));
	    
	    UnitOption.click();
	}

public void save() {
		
		driver.findElement(Save).click();
		}
	
	
	
	
	
}
