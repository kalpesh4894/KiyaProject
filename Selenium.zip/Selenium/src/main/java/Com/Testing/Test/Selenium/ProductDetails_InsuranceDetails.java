package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetails_InsuranceDetails {
	
	private WebDriver driver;
    private WebDriverWait wait;

    public ProductDetails_InsuranceDetails(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }


	
	
	By Prod_details = By.cssSelector("a[href*='openApplicationTabs'][href*='PRODUCT DETAILS']");
	By Insurance_details = By.xpath("//a[contains(@onclick,'viewInsuranceDetails')]");
	By edit_1 = By.xpath("//tr[1]//a[contains(@class,'editBtn')]");
	By edit_2 = By.xpath("//tr[2]//a[contains(@class,'editBtn')]");
    By edit_3 = By.xpath("//tr[3]//a[contains(@class,'editBtn')]");
    By search_button = By.id("searchButton");
    By record = By.name("loanItemSelect");
    By Policy_number = By.id("mainPolicyNo");
    By insurance_year = By.id("select2-insuranceYear-container");
    By select2SearchInput = By.cssSelector("input.select2-search__field");
    By garrage = By.id("select2-insideOutsideGarage-container");
    By remarks = By.name("remarks");
    By save = By.id("saveInsurance");
    
    
    
   public void productdetails() { 
    WebElement productdetls = wait.until(ExpectedConditions.visibilityOfElementLocated(Prod_details));
    productdetls.click();
   }
   
   
   public void insurancedetails() {
	   WebElement insurancedtls = wait.until(ExpectedConditions.visibilityOfElementLocated(Insurance_details));
	    insurancedtls.click();
   }
    
   public void selectgrid1() {
	   WebElement record = wait.until(ExpectedConditions.visibilityOfElementLocated(edit_1));
	    record.click();
   }
   public void selectgrid2() {
	   WebElement record = wait.until(ExpectedConditions.visibilityOfElementLocated(edit_2));
	    record.click();
   }
   public void selectgrid3() {
	   WebElement record = wait.until(ExpectedConditions.visibilityOfElementLocated(edit_3));
	    record.click();
   }
   
   
   public void select_loanitem() {
    	   WebElement search = driver.findElement(search_button);
    	   search.click();
    	   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

   	    wait.until(ExpectedConditions.elementToBeClickable(record)).click();

       }
    
    
    public void EnterPolicyNumber(String value) {
    	
    		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Policy_number));
            input.clear();
            input.sendKeys(value);
    		
    }
    
    
    public void selectinsuranceyear(String value) {
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((insurance_year))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
    }
    
    public void selectgarrage(String value) {
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((garrage))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
    }
    public void EnterRemarks(String value) {
    	
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(remarks));
        input.clear();
        input.sendKeys(value);
		
}
    
    public void savebtn() {
    	WebElement saveb = driver.findElement(save);
		 saveb.click();
    }
    
    
    
}
