package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetails_LoanItemDetails {
	private WebDriver driver;
    private WebDriverWait wait;

    public ProductDetails_LoanItemDetails(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
	
	By Loanitemdtls = By.cssSelector("a.nav-link[href='#menu1']");
	By edit = By.cssSelector("a.editBtn");
	By Vehicle_maker = By.id("select2-vehMaker-container");
	By Vehicle_model = By.id("select2-vehModel-container");
    By Vehicle_Category = By.id("select2-vehCat-container");
    By Vehicle_Subcategory = By.id("select2-vehSubCat-container");
    By Region = By.id("select2-region-container");
	By HP_Bookmark = By.id("select2-hpBookMark-container");
	By select2SearchInput = By.cssSelector("input.select2-search__field");
	By IsApplcntOwner = By.id("select2-isApplicantOwner-container");
	By Chassino = By.id("chassisNumber");
	By Plateno =By.id("plateNumber");
	By Engineno = By.id("engineNumber");
	By Color = By.id("select2-colour-container");
	By Manufactcountry = By.id("select2-manufactureCountry-container");
	By YOM = By.id("select2-manufactureYear-container");
	By Dealerrebtamt = By.className("dealerRebateAmt_txt");
	By Dealertype = By.id("select2-dealerType-container");
	By Dealername = By.id("select2-dealerName-container");
	By Dealersalesname = By.id("select2-dealerSalesManName-container");
	By Dealeramt = By.id("delaerSalesmanAmnt_txt");
	By Allctamt = By.id("collAllocatedAmtVeh_txt");
	By Coveragepercent = By.id("collCoveragePerVeh_txt");
	By Save = By.id("saveLoanItem");
	
			
	      //Page Actions //
	public void clickloanitemdetails() {
		WebElement loanitdetls = wait.until(ExpectedConditions.visibilityOfElementLocated(Loanitemdtls));
	    loanitdetls.click();
	}
	
	public void click_edit() {
		WebElement edi = wait.until(ExpectedConditions.visibilityOfElementLocated(edit));
	    edi.click();
		
	}
	public void selectvehiclemaker(String value) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Vehicle_maker));
        input.clear();
        input.sendKeys(value);
	}
	public void selectvehiclemodel(String value) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Vehicle_maker));
        input.clear();
        input.sendKeys(value);
	}
	public void selectregion(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Region))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectvehiclecatgory(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Vehicle_Category))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectvehiclesubcategory(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Vehicle_Subcategory))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectishpbookmark(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((HP_Bookmark))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectisapplicantowner(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((IsApplcntOwner))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
      searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void enterchassisno(String value) {
WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Chassino))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
      searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
		
		
	}
	public void enterplateeno(String value) {
WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Plateno))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
      searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
		
	}
	public void enterengineno(String value) {
		wait.until(ExpectedConditions.elementToBeClickable((Engineno))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
      searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
		
	}
	public void selectcolor(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable(Color)).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectcountryofmanufacturer(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Manufactcountry))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(value);
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectyearpfmanufacturer(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((YOM))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void enterdealerrebateamt(long i) {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Dealerrebtamt))).click();
	    WebElement searchBox = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
 searchBox.clear();
    searchBox.sendKeys(String.valueOf(i));
    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectdealertype(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Dealertype))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectdealername(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Dealername))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void selectdealersalemanname(String value) {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		    
		    wait.until(ExpectedConditions.elementToBeClickable((Dealersalesname))).click();
		    WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(select2SearchInput));
	 searchBox.clear();
	    searchBox.sendKeys(value);
	    searchBox.sendKeys(Keys.ENTER);
	}
	public void enterdealersalesmanamt(long i) {
  
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Dealeramt));
        input.clear();
        input.sendKeys(String.valueOf(i));
	}
	public void enterallocatedamt(long i) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Allctamt));
        input.clear();
        input.sendKeys(String.valueOf(i));	
	}
	public void enterpercentage(long i) {
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(Coveragepercent));
        input.clear();
        input.sendKeys(String.valueOf(i));	
	}
	public void save() {
		WebElement sa = driver.findElement(Save);
		sa.click();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
