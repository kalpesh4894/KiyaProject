package Com.Testing.Test.Selenium;

import org.openqa.selenium.By;

public class IncomeExpense_IncomeDetails {
	
	By tab = By.cssSelector("a.sn-active.active");
	By Incometab = By.cssSelector("a.nav-link.active.show");
    By Cust_type =  By.id("select2-customerType-container");
    By income_type = By.id("select2-incomeType-container");
    By incomeamt = By.id("incomeAmt_txt");
    By addincome = By.id("addIncomebt");
    By savebtn = By.id("saveIncomeDtls");
    By Expensetab = By.cssSelector("a.nav-link[href='#menu1']");
    By 





}
