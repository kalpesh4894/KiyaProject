package Com.Testing.Test.Selenium.Driver;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import Com.Testing.Test.Selenium.Utils.PropertyReader;

public class DriverManager {
	
	
	public static WebDriver driver;
	
	public static WebDriver getDriver() {
		return driver;
	}
	
  public static void setDriver(WebDriver driver) {
	DriverManager.driver =driver;
	
}
  public static void init() {
	  String browser = null;
	  browser = PropertyReader.readkey("browser");
	  if(driver == null) {
		  switch(browser) {
		  case "edge":
		 EdgeOptions edgeoptions = new EdgeOptions();
		 edgeoptions.addArguments("Start -- maximized");
		 edgeoptions.addArguments("--guest");
		 driver = new EdgeDriver(edgeoptions);
		 break;
		
		  case "chrome":
			  ChromeOptions chromeoptions = new ChromeOptions();
				 chromeoptions.addArguments("Start -- maximized");
				 
				 driver = new ChromeDriver(chromeoptions);
				 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			  break;
			  default:
				  System.out.print("No browser found");
				  		  
		  }
	  }
	  
  }
  
  
  
  public static void down() {
	  
	  if(driver == null) {
		  driver.quit();
		  driver  = null;
	  }
	  
	  
	  
	  
	  
	  
	 
	  
  }
  
  
  
  
  
  
  
  
  
  
  
}

