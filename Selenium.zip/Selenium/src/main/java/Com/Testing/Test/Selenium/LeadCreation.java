package Com.Testing.Test.Selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.*;

import java.time.Duration;

public class LeadCreation {

    private WebDriver driver;
    private WebDriverWait wait;

    public LeadCreation(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // -------------------------------
    // Locators
    // -------------------------------
    private By appTypeDropdown = By.id("select2-applicationType-container");
    private By idTypeDropdown = By.id("select2-idType-container");
    private By idNumber = By.id("idNumber");
    private By custSearch = By.id("search");
    private By convertToApp = By.id("convertpreLeadToApp");
                                   
    private By custName = By.id("fName");
    private By custNameArabic = By.id("firstNameArabic");
    private By nationalityDropdown = By.id("select2-nationalityId-container");
    private By email = By.id("email");
    private By mobileNo = By.id("mobileNo");
    private By productDropdown = By.id("select2-product-container");
    private By subProductDropdown = By.id("select2-subProduct-container");

    // Verification buttons
    private By clickVerifyEmail = By.id("sendOtpEmail");
    private By enterEmailOtp = By.id("emailOtp");
    private By clickVerifyMobile = By.id("sendOtpMobile");
    private By enterMobileOtp = By.id("mobileOtp"); 
    private By verifyEmail = By.id("emailVerify");
    private By verifyMobile = By.id("mobileVerify");
    private By CalcEmi =By.id("calculateEmi1"); 
    private By SayYesConvert = By.id("warningPopYesConvertAp");

    // -------------------------------
    // Page Actions
    // -------------------------------

    public void enterCivilIdNumber(String civilId) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(idNumber));
        input.clear();
        input.sendKeys(civilId);
    }

    
    
    public void enterCustomerName(String name) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(custName));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        String script =
            "arguments[0].value='" + name + "';" +
            "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
            "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));" +
            "arguments[0].dispatchEvent(new Event('blur', { bubbles: true }));";

        js.executeScript(script, input);
    }



    public void enterCustomerNameArabic(String nameArabic) {
        // Using JavaScript to avoid freezing on Arabic input
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.getElementById('firstNameArabic').value='" + nameArabic + "';");
    }

    public void enterEmail(String emailValue) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(email));
        input.clear();
        input.sendKeys(emailValue);
    }

    public void enterMobile(String mobile) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(mobileNo));
        input.clear();
        input.sendKeys(mobile);
    }

    // -------------------------------
    // Select2 dropdown helper
    // -------------------------------
    public void selectFromSelect2(By dropdown, String value) throws InterruptedException {
        driver.findElement(dropdown).click();

        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@class='select2-search__field']")));
        input.sendKeys(value);

        Thread.sleep(500); // allow search results to appear
        input.sendKeys(Keys.ENTER);
    }

    public void selectAppType(String value) throws InterruptedException {
        selectFromSelect2(appTypeDropdown, value);
    }

    public void selectIdType(String value) throws InterruptedException {
        selectFromSelect2(idTypeDropdown, value);
    }

    public void selectNationality(String country) throws InterruptedException {
        selectFromSelect2(nationalityDropdown, country);
    }

    public void selectProduct(String product) throws InterruptedException {
        selectFromSelect2(productDropdown, product);
    }

    public void selectSubProduct(String subProduct) throws InterruptedException {
        selectFromSelect2(subProductDropdown, subProduct);
    }

    // -------------------------------
    // Customer Search
    // -------------------------------
    public void searchCustomer(String civilId, String appType, String idType) throws InterruptedException {
        selectAppType(appType);
        selectIdType(idType);
        enterCivilIdNumber(civilId);

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(custSearch));
        searchBtn.click();

        Thread.sleep(2000); // optional wait for results or popup
    }

    // -------------------------------
    // Convert to Application
    // -------------------------------
  

   
    public void verifyEmailOtp() throws InterruptedException {

       
        WebElement sendOtpBtn = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.elementToBeClickable(clickVerifyEmail)
                )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sendOtpBtn);
        sendOtpBtn.click();

        Thread.sleep(3000); // wait for popup or OTP field to appear

        // ------------------------
        // 2️⃣ Close popup if any
        // ------------------------
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
            )).click();
        } catch (Exception ignored) {}

        // ------------------------
        // 3️⃣ Enter OTP
        // ------------------------
        WebElement otpInput = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.visibilityOfElementLocated(enterEmailOtp)
                )
        );

        otpInput.clear();
        otpInput.sendKeys("123456");
        System.out.println("Email OTP entered successfully.");

        // ------------------------
        // 4️⃣ Click "Verify OTP"
        // ------------------------
        WebElement verifyBtn = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.elementToBeClickable(verifyEmail)
                )
        );

        try {
            verifyBtn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", verifyBtn);
        }

        // ------------------------
        // 5️⃣ Close final popup if any
        // ------------------------
        try {
            WebElement popupBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
                    )
            );
            popupBtn.click();
        } catch (Exception ignored) {}

        System.out.println("Email OTP Verified Successfully!");

        Thread.sleep(3000);
    }


    
    public void verifyMobileOtp() throws InterruptedException {

        // ------------------------
        // 1️⃣ Click "Send OTP"
        // ------------------------
        WebElement sendOtpBtn = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.elementToBeClickable(clickVerifyMobile)
                )
        );

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sendOtpBtn);

        try {
            sendOtpBtn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", sendOtpBtn);
        }

        // ------------------------
        // 2️⃣ Handle JS alert if appears
        // ------------------------
        try {
            WebDriverWait alertWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            alertWait.until(ExpectedConditions.alertIsPresent());
            Alert alert = driver.switchTo().alert();
            System.out.println("Alert text: " + alert.getText());
            alert.accept();
            System.out.println("Alert accepted successfully.");
        } catch (Exception ignored) {
            System.out.println("No alert present.");
        }

        Thread.sleep(1000);

        // ------------------------
        // 3️⃣ Enter Mobile OTP
        // ------------------------
        WebElement otpInput = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.visibilityOfElementLocated(enterMobileOtp)
                )
        );

        otpInput.clear();
        otpInput.sendKeys("123456");

        // ------------------------
        // 4️⃣ Click "Verify Mobile"
        // ------------------------
        WebElement verifyBtn = wait.until(
                ExpectedConditions.refreshed(
                        ExpectedConditions.elementToBeClickable(verifyMobile)
                )
        );

        try {
            verifyBtn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", verifyBtn);
        }

        // ------------------------
        // 5️⃣ Close final popup if any
        // ------------------------
        try {
            WebElement popupBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
                    )
            );
            popupBtn.click();
        } catch (Exception ignored) {}

        System.out.println("Mobile OTP Verified Successfully!");
    }

    
    public void PageScrollUp() throws InterruptedException {
    	
    	JavascriptExecutor js1 = (JavascriptExecutor) driver;
        js1.executeScript("window.scrollBy(0, -500);");
        Thread.sleep(3000);
    }
    
    public void PageScrollDown() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 300);");
        Thread.sleep(3000);
    }
    public void PageScrollDown1() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 450);");
        Thread.sleep(3000);
    }
    
    public void handleNoRecordPopup() {
        try {
            WebElement popup = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//*[contains(text(),'No Record Found')]")
            ));
            WebElement okBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'OK') or contains(text(),'Ok')]")
            ));
            okBtn.click();
            System.out.println("Popup handled successfully.");
        } catch (Exception e) {
            System.out.println("No popup found.");
        }
    }
    public void clickEmi() {
    WebElement clkemi = wait.until(ExpectedConditions.visibilityOfElementLocated(CalcEmi));
    clkemi.click();
    }
    
    public void convertToApplication() {
        WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(convertToApp));
        btn.click();
    }
    
    public void clickYesConvert() {
    	WebElement Conv = wait.until(ExpectedConditions.visibilityOfElementLocated(SayYesConvert));
    	Conv.click();
    	
    }
    
//    public String generateRegistationNumber(String no) {
//		int len = RANDOM.nextInt(8) + 8;
//		StringBuilder regNo = new StringBuilder();
//		for (int i = 0; i < len; i++)
//			if (i % 2 == 0)
//				regNo.append(ALPHANUMERIC.charAt(RANDOM.nextInt(ALPHANUMERIC.length())));
//			else
//				regNo.append(NUMBERS.charAt(RANDOM.nextInt(NUMBERS.length())));
//		return no + regNo.toString();
//	}
//        
}
