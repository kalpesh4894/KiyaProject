package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class EmploymentDetails {
	private WebDriver driver;
    private WebDriverWait wait;

    public EmploymentDetails(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
   
	By Employmenttab = By.xpath("//ul[@class='nav nav-tabs m-0']//child::li[4]");
	By Natureofemployment = By.id("select2-natureOfEmplmt-container");
	By Occupation = By.id("select2-occupation-container");
	By nameofemployer = By.id("select2-nameofEmployer-container");
	By EntityName = By.id("companyName");
	By Entitytype = By.id("select2-companyType-container");
	By Dateofregistration = By.id("dateOfRegistration");
	By Registrationcountry = By.id("select2-country-container");
	By Dateofestablishment = By.id("dateofEstablishement");
	By Commregno = By.id("registrationNo");
	By Taxideno = By.id("taxNo");
	By Modeofsalary = By.id("select2-modeOfSalary-container");
	By Dateofemployment = By.id("select2-nameofEmployer-container");
	By Employmenttype = By.id("select2-employmentType-container");
	By Sector = By.id("select2-sector-container");
	By Empbuactcode = By.id("select2-employerBusActCode-container");
	By Employeraddress = By.id("employerAddress");
	By Prevaddress =  By.id("preRegisterdAdd");
	By Phoneno =By.id("phoneNumber");
	By Website = By.id("website");
	By Emial = By.id("email");
	By Position = By.id("select2-position-container");
	
	
	
	               //Page Actions //
	
	
	public void clickemploymenttab() {
		WebElement tab = driver.findElement(Employmenttab);
		tab.click();
		}
	
	public void selectnatureofemployment(String value) {
		wait.until(ExpectedConditions.elementToBeClickable(Natureofemployment)).click();

		WebElement searchBox = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(
		                By.className("select2-search__field")));

		searchBox.sendKeys(value);
		searchBox.sendKeys(Keys.ENTER);

		
	}
	
	
 public void selectmodeofsalary(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Modeofsalary))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-modeOfSalary') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }
	
 public void selectnameofemployer(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((nameofemployer))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-nameofEmployer') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }

	
 
	
 public void selectposition(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Position))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-position') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }

 public void selectdateofemployment() {

	    String year = "2012";
	    String month = "Jul";
	    String day = "20";

	    // Open date picker
	    driver.findElement((Dateofemployment)).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}
 public void selectemploymenttype(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Employmenttype))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-employmentType') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }
 public void selectsector(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Sector))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-sector') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }
	
	
 public void selectemploymentbusinessactcode(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	    wait.until(ExpectedConditions.elementToBeClickable((Sector))).click();

	    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//li[contains(@id, 'select2-employerBusActCode') and text()='" + value + "']")));
	    
	    addrOption.click();
	 
 }
	
 public void selectemployeraddress(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	   WebElement Addr = wait.until(ExpectedConditions.elementToBeClickable((Employeraddress)));
	   Addr.click();
	   Addr.sendKeys(value);
         
	 }
	
 public void selectprevaddress(String value) {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    
	   WebElement Addr = wait.until(ExpectedConditions.elementToBeClickable((Prevaddress)));
	   Addr.click();
	   Addr.sendKeys(value);
         
	 }
 
 
 public void saveidenty() {
		
	 List<WebElement> savebtn = driver.findElements(By.id("saveIdenty"));
	  savebtn.get(0).click();
		}
 
 
 
 public void handlePopupAfterSave() {
     WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));

     try {
         WebElement popupBtn = wait.until(
             ExpectedConditions.elementToBeClickable(
                 By.xpath("//button[contains(text(),'OK') or contains(text(),'Close')]")
             )
         );

         // If popup appears, click it
         popupBtn.click();

         // Fail the test because popup should not appear
         Assert.fail("Test failed: Popup appeared after clicking Save.");

     } catch (TimeoutException e) {
         // This is expected: no popup appeared
         System.out.println("Employment details saved successfully");
     }
 }
 
 

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
