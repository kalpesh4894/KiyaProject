package Com.Testing.Test.Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class DashboardPage {

    WebDriver driver;
    WebDriverWait wait;

    // Locator for PreLead
    By preLead = By.xpath("/html/body/div[1]/header/div/div/div/div/div/div[2]/ul[2]/li[4]/a");

    By Inbox =By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/header/div/div/div/div/div/div[2]/ul[2]/li[6]/a");
    // Constructor
    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Method to click PreLead using JavaScript
    public void clickPreLead() {
        // Wait until visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(preLead));

        // Locate the element
        WebElement element = driver.findElement(preLead);

        // Click using JavaScript
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }
    
  
    public void GoToInbox() {
    	WebElement inbx = wait.until(ExpectedConditions.visibilityOfElementLocated(Inbox));
    	inbx.click(); 
    	
    	
       }
    
}
