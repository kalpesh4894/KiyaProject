package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RepaymentDetailsPage {
	private WebDriver driver;
    private WebDriverWait wait;

    public RepaymentDetailsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//	By repaytab = By.id("//ul[@class='nav nav-tabs m-0']//child::li[6]");
	By repaytab = By.linkText("Repayment Details");

	By Repaymode = By.id("select2-repaymentMode-container");
	By save = By.id("saveRepaymentDtls");
	
	
	public void selectRepaymode(String value) {
		
			 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

			    
			    wait.until(ExpectedConditions.elementToBeClickable((Repaymode))).click();

			    WebElement addrOption = wait.until(ExpectedConditions.elementToBeClickable(
			            By.xpath("//li[contains(@id, 'select2-repaymentMode') and text()='" + value + "']")));
			    
			    addrOption.click();
			 
		 }
	
	public void clickrepaymenttab() {
		WebElement tab = driver.findElement(repaytab);
		tab.click();
	}
	public void save(){
		 WebElement savebtn = driver.findElement(save);
		   savebtn.click();
	}
	
	
	}


