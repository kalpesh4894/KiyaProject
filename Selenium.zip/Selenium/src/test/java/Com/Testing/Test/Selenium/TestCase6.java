package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Com.Testing.Test.Selenium.Base.BaseTest;


import Com.Testing.Test.Selenium.Driver.DriverManager;

public class TestCase6 extends BaseTest{
	
	
    private LoginPage loginPage;
    private DashboardPage dashboard;
    private LeadCreation lead;
    private BankDetailsPage bankdetails;
    private KYCBasicDetails kbd;
    
    private KYCIdentificationDetailsPage kidenty;
    @BeforeClass
    public void setup() {
        

        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

        loginPage = new LoginPage(driver);
        dashboard = new DashboardPage(driver);
        lead = new LeadCreation(driver);
        bankdetails = new BankDetailsPage(driver);
        kbd = new KYCBasicDetails(driver);
              
    }


@Test

public void FillBankDetails() throws InterruptedException {
	 loginPage.login("user1", "abcd@1234");
 	dashboard.GoToInbox();
     WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
 	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
 	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid 

 	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
 	 srch.clear();
 	 srch.sendKeys("Tony");
 	 srch.sendKeys(Keys.ENTER);
 	Thread.sleep(2000);	    	
 	 
 	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
 	  

 	   
 	   Actions actions = new Actions(driver);
 	    actions.doubleClick(record).perform();
       Thread.sleep(15000);
       By dde = By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/main/div/div/div/div/div/div/div[5]/div[2]/div/div/div[1]/table/tbody/tr/td[1]/a");
       WebElement ddeclick = wait.until(ExpectedConditions.elementToBeClickable(dde));
        ddeclick.click();
        lead.PageScrollDown();
        kbd.clickKYC();
        Thread.sleep(2500);
        
        bankdetails.Clickbankdetailstab();
        lead.PageScrollDown();
        driver.switchTo().frame("viewBankDetailsFrame");
        bankdetails.selectcustomertype("Main Applicant");
        bankdetails.selectbankname("Bank of bahrain and kuwait");
        bankdetails.Enteraccountno("123456785332");
        bankdetails.EnterIBANno("67898765hjggjgjgkjgkjgkjgkjgkj");
        bankdetails.selectcurrency("USD");
        bankdetails.selectisoverseas("yes");
        bankdetails.selectisdisursementacc("YES");
        bankdetails.selectisrepacc("Yes");
        bankdetails.save();
        handlePopupAfterSave("Bank details saved successfully");
        
      
        
        
        
        
               
}

}
