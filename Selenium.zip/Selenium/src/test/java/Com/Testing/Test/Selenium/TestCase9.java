package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Com.Testing.Test.Selenium.Base.BaseTest;

public class TestCase9 extends BaseTest{
	
	
	 private LoginPage loginPage;
	    private DashboardPage dashboard;
	    private LeadCreation lead;
	    private ProductDetails_InsuranceDetails prodinsurance;
	    @BeforeClass
	    public void setup() {
	        

	        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

	        loginPage = new LoginPage(driver);
	        dashboard = new DashboardPage(driver);
	        lead = new LeadCreation(driver);
	        prodinsurance = new ProductDetails_InsuranceDetails(driver);
	    }
	    @Test
	    public void FillInsuranceDetails() throws InterruptedException {
	    	 loginPage.login("user1", "abcd@1234");
		     	dashboard.GoToInbox();
		         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		     	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
		     	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid 

		     	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
		     	 srch.clear();
		     	 srch.sendKeys("Tony");
		     	 srch.sendKeys(Keys.ENTER);
		     	Thread.sleep(2000);	    	
		     	 
		     	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
		     	  

		     	   
		     	   Actions actions = new Actions(driver);
		     	    actions.doubleClick(record).perform();
		           Thread.sleep(15000);
		           
		           GoToDDEStage();
		           PageScrollDown();
		         prodinsurance.productdetails();
		         
		         prodinsurance.insurancedetails();
		         driver.switchTo().frame("viewInsuranceDetailsFrame");
		         prodinsurance.selectgrid1();
		         PageScrollDown();
		         prodinsurance.select_loanitem();
		         prodinsurance.EnterPolicyNumber("12345677890");
		         prodinsurance.selectinsuranceyear("3 Year");
		         prodinsurance.selectgarrage("Outside Garage");
		         prodinsurance.EnterRemarks("None");
		         prodinsurance.savebtn();
		         handlePopupAfterSave("Insurance details 1 saved successfully");
		         
		         prodinsurance.selectgrid2();
		         PageScrollDown();
		         prodinsurance.select_loanitem();
		         prodinsurance.EnterPolicyNumber("13345677890");
		         prodinsurance.selectinsuranceyear("3 Year");
		         prodinsurance.selectgarrage("Outside Garage");
		         prodinsurance.EnterRemarks("None");
		         prodinsurance.savebtn();
		         handlePopupAfterSave("Insurance details 2 saved successfully");
		           
		         prodinsurance.selectgrid3();
		         PageScrollDown();
		         prodinsurance.EnterPolicyNumber("12305677890");
		         prodinsurance.selectinsuranceyear("3 Year");
		         prodinsurance.EnterRemarks("None");
		         prodinsurance.savebtn();  
		         handlePopupAfterSave("Insurance details 3 saved successfully");
		           
	    }
	        


}