package Com.Testing.Test.Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		 driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");
	       driver.manage().window().maximize();
	       Thread.sleep(4000);
		   // Create LoginPage object
	        LoginPage loginPage = new LoginPage(driver);

	        // Perform login
	        loginPage.login("user1", "abcd@1234");


	        // Create DashboardPage object
	        DashboardPage dashboard = new DashboardPage(driver);

	        // Click on PreLead
	        dashboard.clickPreLead();

	        // Optional: continue with other actions or close browser
	        // driver.quit();
	    }
	

}
