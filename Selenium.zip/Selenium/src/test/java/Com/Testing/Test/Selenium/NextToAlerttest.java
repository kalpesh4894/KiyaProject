

package Com.Testing.Test.Selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Com.Testing.Test.Selenium.Driver.DriverManager;

public class NextToAlerttest {
	
	
//	@BeforeTest
//	public void setUp() {
//		DriverManager.init();
//		
//	}

    private WebDriver driver;
    private LoginPage loginPage;
    private DashboardPage dashboard;
    private LeadCreation lead;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

        loginPage = new LoginPage(driver);
        dashboard = new DashboardPage(driver);
        lead = new LeadCreation(driver);
    }

    @Test
    public void loginAndClickPreLead() throws Exception {

        // Login
        loginPage.login("user1", "abcd@1234");
        System.out.println("Logged in successfully");

        // Navigate to PreLead
        dashboard.clickPreLead();

        // Perform customer search with application type and ID type
        lead.searchCustomer("123456789102", "Personal Loan", "Civil ID");

        // Handle "No Record Found" popup if it appears
        lead.handleNoRecordPopup();

        // Handle JS alert popup
        try {
            Alert alert = driver.switchTo().alert();
            System.out.println("Alert says: " + alert.getText());
            alert.accept();  // Click Yes
            System.out.println("Alert accepted successfully.");
        } catch (NoAlertPresentException e) {
            System.out.println("No JS alert present.");
        }

        Thread.sleep(2000);
        System.out.println("Alert handled successfully");

        // Enter customer name AFTER popup is handled
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 200);"); // Scroll down 200 pixels
        Thread.sleep(3000);
        lead.enterCustomerName("Simran");
        System.out.println("Customer name entered successfully");
         //pass hai //
        Thread.sleep(3000);
        lead.enterCustomerNameArabic("سهةقشى ناشى");
        System.out.println("Customer name entered successfully");
        
        lead.selectNationality("Afghanistan");
        System.out.println("Nationality selected successfully");
        
        lead.enterEmail("asff@gmail.com");
        System.out.println("Email entered");
        Thread.sleep(3000);

        lead.enterMobile("89898877");
        System.out.println("Mo no entered successfully");
        Thread.sleep(3000);
        
        lead.selectProduct("Vehicle Loan");
        lead.selectProduct("Vehicle Loan");
        
        lead.selectSubProduct("01");
        Thread.sleep(2000);

        lead.verifyEmailOtp();
        
        lead.verifyMobileOtp();
        
        //Use  ----  ---//
        
    } 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    @AfterClass
//    public void tearDown() {
//        if (driver != null) {
//            driver.quit();
//            System.out.println("Browser closed successfully.");
//        }
//    }
}
