package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Com.Testing.Test.Selenium.Driver.DriverManager;

public class TestCase3 extends BaseTest{
	
	private WebDriver driver;
    private LoginPage loginPage;
    private DashboardPage dashboard;
    private LeadCreation lead;
    private LoanSimulatorPage loansim;
    private KYCBasicDetails kbd;
    private KYCAddressDetailsPage kaddress;
    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        DriverManager.setDriver(driver);
        driver.manage().window().maximize();
        

        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

        loginPage = new LoginPage(driver);
        dashboard = new DashboardPage(driver);
        lead = new LeadCreation(driver);
        loansim = new LoanSimulatorPage(driver);
        kbd = new KYCBasicDetails(driver);
        kaddress = new KYCAddressDetailsPage(driver);
 
    }

    
    
    @Test
    public void FillAddressDetails() throws InterruptedException {
        loginPage.login("user1", "abcd@1234");
    	dashboard.GoToInbox();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
    	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid
  
    	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
    	 srch.clear();
    	 srch.sendKeys("Rehman");
    	 srch.sendKeys(Keys.ENTER);
    	 Thread.sleep(2000);	    	
    	 
    	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
    	  

    	   
    	   Actions actions = new Actions(driver);
    	    actions.doubleClick(record).perform();
          Thread.sleep(15000);
          By dde = By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/main/div/div/div/div/div/div/div[5]/div[2]/div/div/div[1]/table/tbody/tr/td[1]/a");
          WebElement ddeclick = wait.until(ExpectedConditions.elementToBeClickable(dde));
           ddeclick.click();
           lead.PageScrollDown();
           kbd.clickKYC();
           Thread.sleep(5000);
           kaddress.clickaddressdetails();
           lead.PageScrollDown1();
           Thread.sleep(5000);
           driver.switchTo().frame("viewAddressDetailsFrame");

           
           kaddress.Addressselect("BUSINESS ADDRESS");
           Thread.sleep(5000);
           lead.PageScrollDown();
           kaddress.selectcheckboxes();
           kaddress.SelectAddStartDate("12-12-2023");
           kaddress.Countryselect("KUWAIT");
           kaddress.Districtselect("AHMADI");
           kaddress.Areaselect("MANGAF");
           kaddress.enterBlock("2");
           kaddress.enterStreet("4");
           kaddress.enterBuilding("450");
           kaddress.enterbuildingtype("Residential");
           kaddress.Unittypeselect("Apartment");
           kaddress.enterunitno("3");
           kaddress.enterfloor("2");
           kaddress.save();
           
          
 
 
         System.out.println("Address details saved successfully"); 


    	
    }
    
    









}
