package Com.Testing.Test.Selenium;

public class BaseTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
