package Com.Testing.Test.Selenium;

public class DatePicker {
	 
	
	//Method 1 : using sendkeys
	//driver.findelement(By.xpath("sdfds").sendkeys("04/05/2022);
	
	//Method 2 : Using datepicker 
	
	String year = "2022";
	String Month ="7";
	String day = "20";
	
}
