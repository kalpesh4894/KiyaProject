package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Com.Testing.Test.Selenium.Driver.DriverManager;
import Com.Testing.Test.Selenium.Utils.PropertyReader;
@Listeners(Com.Testing.Test.Selenium.Utils.ScreenshotsListener.class)
public class TestCase2 extends BaseTest {
	
        
	  private WebDriver driver;
	    private LoginPage loginPage;
	    private DashboardPage dashboard;
	    private LeadCreation lead;
	    private LoanSimulatorPage loansim;
	    private KYCBasicDetails kbd;
	 
	    @BeforeClass
	    public void setup() {
	        driver = new ChromeDriver();
	        DriverManager.setDriver(driver);
	        driver.manage().window().maximize();
	        

	        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");
	      
	        loginPage = new LoginPage(driver);
	        dashboard = new DashboardPage(driver);
	        lead = new LeadCreation(driver);
	        loansim = new LoanSimulatorPage(driver);
	        kbd = new KYCBasicDetails(driver);
	        
	          
	       
	        
	        
	        

	    }
	    
	    // Page actions on inbox 
	    
	    
	    
	    @Test(priority=1)
	    public void searchLead() throws InterruptedException {
	        loginPage.login("user1", "abcd@1234");
	    	dashboard.GoToInbox();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
	    	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid
	  
	    	 Properties prop = PropertyReader.init_prop();
		     	String leadName = prop.getProperty("lead_name");
		     	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
		     	 srch.clear();
		     	 srch.sendKeys(leadName);
		     	 srch.sendKeys(Keys.ENTER);
	    	 
	    	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
	    	  By leadNameCell = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]/td[4]");

		     	 WebElement leadCell = wait.until(
		     	         ExpectedConditions.visibilityOfElementLocated(leadNameCell)
		     	 );

		     	 String actualLeadName = leadCell.getText().trim();

		     	 if (actualLeadName.equalsIgnoreCase(leadName)) {
		     	     System.out.println("TEST PASS: Lead found in inbox → " + actualLeadName);
		     	 } else {
		     	     throw new AssertionError(
		     	         "TEST FAIL: Expected Lead: " + leadName + " but Found: " + actualLeadName
		     	     );
		     	 }
	    	     	 
		      		 
	    	   Actions actions = new Actions(driver);
	    	    actions.doubleClick(record).perform();
              Thread.sleep(15000);
              By dde = By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/main/div/div/div/div/div/div/div[5]/div[2]/div/div/div[1]/table/tbody/tr/td[1]/a");
              WebElement ddeclick = wait.until(ExpectedConditions.elementToBeClickable(dde));
               ddeclick.click();
               lead.PageScrollDown();
               kbd.clickKYC();
               Thread.sleep(5000);
               kbd.clickbasicdetails();
               lead.PageScrollDown1();
               Thread.sleep(5000);
               driver.switchTo().frame("viewBasicDetailsFrame");

               
               kbd.editB();
               Thread.sleep(5000);
               lead.PageScrollDown();
               kbd.titleselect("Mr.");
               kbd.visaselect("Resident Visa");
               kbd.educationSelect("Masters");
               kbd.EnterDOB("02-11-2000");
               kbd.maritalStatusSelect("SINGLE");
               kbd.enterdependants("2");
               kbd.isPEPSelect("NO");
               kbd.isRelativeToPEPSelect("NO");
               kbd.relatedPartyKFICSelect("NO");
               kbd.taxResidentSelect("NO");
               kbd.passportSelect("NO");
               kbd.disabilitySelect("NO");
               kbd.save();
     
             System.out.println("Basic details saved successfully"); 
	
 
	    	
	    }
	    
        

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}       