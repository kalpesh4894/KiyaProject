package Com.Testing.Test.Selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class alerttest {

    private WebDriver driver;
    private LoginPage loginPage;
    private DashboardPage dashboard;
    private LeadCreation lead;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

        loginPage = new LoginPage(driver);
        dashboard = new DashboardPage(driver);
        lead = new LeadCreation(driver);
    }

    @Test
    public void loginAndClickPreLead() throws Exception {

        // Login
        loginPage.login("user1", "abcd@1234");
        System.out.println("Logged in successfully");

        // Navigate to PreLead
        dashboard.clickPreLead();

        // Perform customer search with application type and ID type
        lead.searchCustomer("123456789102", "Personal Loan", "Civil ID");

        // Handle "No Record Found" popup if it appears
        lead.handleNoRecordPopup();

        // Optional: convert to application if needed
        // lead.convertToApplication();
    

    try {
        // Switch to the alert
        Alert alert = driver.switchTo().alert();

        // Print alert text (optional)
        System.out.println("Alert says: " + alert.getText());

        // Click Yes (accept the alert)
        alert.accept();  // .dismiss() would be "No"
        System.out.println("Alert accepted successfully.");
    } catch (NoAlertPresentException e) {
        System.out.println("No JS alert present.");}
    
     Thread.sleep(2000);
     System.out.println("Alert handled successfully");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("Browser closed successfully.");
        }
    }
}
