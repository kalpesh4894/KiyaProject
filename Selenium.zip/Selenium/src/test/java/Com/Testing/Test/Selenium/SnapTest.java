package Com.Testing.Test.Selenium;

	import org.testng.Assert;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Listeners;
	import org.testng.annotations.Test;

	import Com.Testing.Test.Selenium.Driver.DriverManager;
	import Com.Testing.Test.Selenium.Utils.ScreenshotsListener;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.chrome.ChromeOptions;

	@Listeners(ScreenshotsListener.class)
	public class SnapTest {

	    private WebDriver driver;

	    @BeforeClass
	    public void setup() {
	        ChromeOptions options = new ChromeOptions();
	        options.addArguments("start-maximized");
	        driver = new ChromeDriver(options);

	        // ✅ Important: set driver in DriverManager for listener
	        DriverManager.setDriver(driver);
	    }

	    @Test
	    public void testFailScreenshot() {
	        driver.get("https://www.google.com");
	        System.out.println("Google page opened.");

	        // ✅ Force fail to test screenshot
	        Assert.fail("Force fail to test screenshot capture.");
	    }
	}


