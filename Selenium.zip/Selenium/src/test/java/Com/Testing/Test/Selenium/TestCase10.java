package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Com.Testing.Test.Selenium.Base.BaseTest;

public class TestCase10 extends BaseTest{
	
	 private LoginPage loginPage;
	    private DashboardPage dashboard;
	    private LeadCreation lead;
	    private ProductDetails_InsuranceDetails prodinsurance;
	    private ProductDetails_LoanItemDetails prodloanitemdetails;
	    @BeforeClass
	    public void setup() {
	        

	        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

	        loginPage = new LoginPage(driver);
	        dashboard = new DashboardPage(driver);
	        lead = new LeadCreation(driver);
	        prodinsurance = new ProductDetails_InsuranceDetails(driver); 
	        prodloanitemdetails = new ProductDetails_LoanItemDetails(driver);
	    }
	    @Test
	    public void FillloanItemDetails() throws InterruptedException {
	    	 loginPage.login("user1", "abcd@1234");
		     	dashboard.GoToInbox();
		         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		     	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
		     	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid 

		     	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
		     	 srch.clear();
		     	 srch.sendKeys("Tony");
		     	 srch.sendKeys(Keys.ENTER);
		     	Thread.sleep(2000);	    	
		     	 
		     	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
		     	  

		     	   
		     	   Actions actions = new Actions(driver);
		     	    actions.doubleClick(record).perform();
		           Thread.sleep(15000);
		           
		           GoToDDEStage();
		           PageScrollDown();
		           prodinsurance.productdetails();
		         prodloanitemdetails.clickloanitemdetails();
		         prodloanitemdetails.click_edit();
		 //        prodloanitemdetails.selectvehiclemaker("");
		  //       prodloanitemdetails.selectvehiclemodel("");
		  ///       prodloanitemdetails.selectregion("");
		   //      prodloanitemdetails.selectvehiclecatgory("");
		  //       prodloanitemdetails.selectvehiclesubcategory("");
		 //        prodloanitemdetails.selectishpbookmark("");
		         prodloanitemdetails.selectisapplicantowner("Yes");
		         prodloanitemdetails.enterchassisno("1HGCM82633A004352");
		         prodloanitemdetails.enterplateeno("8675576867555687");
		         prodloanitemdetails.enterengineno("9876guigf6f7t");
		         prodloanitemdetails.selectcolor("Dark Red");
		  //     prodloanitemdetails.selectcountryofmanufacturer("");
		         prodloanitemdetails.selectyearpfmanufacturer("2007");
		         prodloanitemdetails.enterdealerrebateamt(9);
		         prodloanitemdetails.selectdealertype("");
		         prodloanitemdetails.selectdealername("");
		         prodloanitemdetails.selectdealersalemanname("");
		         prodloanitemdetails.enterdealersalesmanamt(20l);
		         prodloanitemdetails.enterallocatedamt(9l);
		         prodloanitemdetails.enterpercentage(100l);
		         prodloanitemdetails.save();
	    }	         

}
