package Com.Testing.Test.Selenium;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Com.Testing.Test.Selenium.Base.BaseTest;

import Com.Testing.Test.Selenium.Driver.DriverManager;

public class LeadCreationFlowTest extends BaseTest {
	
	

	    private LoginPage loginPage;
	    private DashboardPage dashboard;
	    private LeadCreation lead;
	    private LoanSimulatorPage loansim;
	    private BankDetailsPage bankdetails;
	    private KYCBasicDetails kbd;
	    private KYCAddressDetailsPage kaddress;
	    private KYCIdentificationDetailsPage kidenty;
	    private RepaymentDetailsPage repay;
	    private ReferenceDetailsPage reference;
	    
	    @BeforeClass
	    public void testSetup() {

	        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

	        loginPage = new LoginPage(driver);
	        dashboard = new DashboardPage(driver);
	        lead = new LeadCreation(driver);
	        loansim = new LoanSimulatorPage(driver);
	        kbd = new KYCBasicDetails(driver);
	        kaddress = new KYCAddressDetailsPage(driver);
	        kidenty = new KYCIdentificationDetailsPage(driver);
	        bankdetails = new BankDetailsPage(driver);
	        repay = new RepaymentDetailsPage(driver);
	        reference = new ReferenceDetailsPage(driver);
	    }
  
	    @Test(priority = 1)
	    public void loginAndClickPreLead() throws Exception {

	        // Login
	        loginPage.login("user1", "abcd@1234");
	        System.out.println("Logged in successfully");

	        // Navigate to PreLead
	        dashboard.clickPreLead();

	        // Perform customer search with application type and ID type
	        lead.searchCustomer("122056780112", "Personal Loan", "Civil ID");

	        // Handle "No Record Found" popup if it appears
	        lead.handleNoRecordPopup();

	        // Handle JS alert popup
	        try {
	            Alert alert = driver.switchTo().alert();
	            System.out.println("Alert says: " + alert.getText());
	            alert.accept();  // Click Yes
	            System.out.println("Alert accepted successfully.");
	        } catch (NoAlertPresentException e) {
	            System.out.println("No JS alert present.");
	        }

	        Thread.sleep(2000);
	        System.out.println("Alert handled successfully");

	        // Enter customer name AFTER popup is handled
	   
	       
	        lead.PageScrollDown();
	    
	        lead.enterCustomerName("Aadi");
	        System.out.println("Customer name entered successfully");
	         //pass hai //
	        Thread.sleep(3000);
	        lead.enterCustomerNameArabic("سهةقشى ناشى");
	        System.out.println("Customer name entered successfully");
	        
	        lead.selectNationality("Afghanistan");
	        System.out.println("Nationality selected successfully");
	        
	        lead.enterEmail("asff@gmail.com");
	        System.out.println("Email entered");
	        Thread.sleep(3000);

	        lead.enterMobile("89898877");
	        System.out.println("Mo no entered successfully");
	        Thread.sleep(3000);
	        
	        lead.selectProduct("Vehicle Loan");
	        lead.selectProduct("Vehicle Loan");
	        
	        lead.selectSubProduct("01");
	        Thread.sleep(2000);

	        lead.verifyEmailOtp();
	   
	        lead.verifyMobileOtp();
	        
	        lead.PageScrollUp();
	        
	       
	        lead.clickEmi();
	        
	        Thread.sleep(5000);
	        
	       
	        loansim.selectVehiclePurpose();
	        
	        loansim.enterAssetPrice(1000L);
	        
	        loansim.enterDPTC(20L);
	        
	 //       loansim.enterDPTD(100);
	        
	        loansim.enterTenure(12L);
	        
	        loansim.selectRepaymentType("standard");
	        
	        loansim.selectPrincipalFrequency("Monthly");
	        
	        loansim.enterLoanStartDate("28-11-2025");
	        
	        loansim.enterFirstInstallmentDate("30-11-2025");
	        
	        loansim.clickCalculateEMI();
	        
	        Thread.sleep(5000);
	        
	        lead.PageScrollUp();
	        
	        loansim.close_loansim();
	        
	        lead.PageScrollDown1();
	        
	        lead.convertToApplication();
	        
	        lead.clickYesConvert();
	        
	        System.out.print("Lead Created Successfully");
	        
	    }
	     
	      @Test(priority = 2)
	      
	      public void BasicDetails() throws InterruptedException {
	      	
	      	dashboard.GoToInbox();
	      	
	      	
	      	
	      	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
	    	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid
	  
	    	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
	    	 srch.clear();
	    	 srch.sendKeys("Aadi");
	    	 srch.sendKeys(Keys.ENTER);
	    	 	    	
	    	 
	    	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));

	    	   
	    	   Actions actions = new Actions(driver);
	    	    actions.doubleClick(record).perform();
              Thread.sleep(15000);
              By dde = By.xpath("//*[@id=\"htmlRoot\"]/body/div[1]/main/div/div/div/div/div/div/div[5]/div[2]/div/div/div[1]/table/tbody/tr/td[1]/a");
              WebElement ddeclick = wait.until(ExpectedConditions.elementToBeClickable(dde));
               ddeclick.click();
               lead.PageScrollDown();
               kbd.clickKYC();
               Thread.sleep(5000);
               kbd.clickbasicdetails();
               lead.PageScrollDown1();
               Thread.sleep(5000);
               driver.switchTo().frame("viewBasicDetailsFrame");

               
               kbd.editB();
               Thread.sleep(5000);
               lead.PageScrollDown();
               kbd.titleselect("Mr.");
               kbd.visaselect("Resident Visa");
               kbd.educationSelect("Masters");
               kbd.EnterDOB("02-11-2000");
               kbd.maritalStatusSelect("SINGLE");
               kbd.enterdependants("2");
               kbd.isPEPSelect("NO");
               kbd.isRelativeToPEPSelect("NO");
               kbd.relatedPartyKFICSelect("NO");
               kbd.taxResidentSelect("NO");
               kbd.passportSelect("NO");
               kbd.disabilitySelect("NO");
               kbd.save();
               handlePopupAfterSave("Basic details saved successfully");
     
             
             driver.switchTo().defaultContent();
 	        Thread.sleep(3000);
 	        
 
	    	
	    }
		
		
		@Test(priority = 3)
		
		public void AddressDetails() throws InterruptedException {
			driver.switchTo().defaultContent();
	        Thread.sleep(3000);
	        
			 lead.PageScrollUp();
			 kaddress.clickaddressdetails();
	           lead.PageScrollDown1();
	           Thread.sleep(5000);
	           driver.switchTo().frame("viewAddressDetailsFrame");

	           
	           kaddress.Addressselect("BUSINESS ADDRESS");
	           Thread.sleep(5000);
	           lead.PageScrollDown();
	           kaddress.selectcheckboxes();
	           kaddress.SelectAddStartDate("12-12-2023");
	           kaddress.Countryselect("KUWAIT");
	           kaddress.Districtselect("AHMADI");
	           kaddress.Areaselect("MANGAF");
	           kaddress.enterBlock("2");
	           kaddress.enterStreet("4");
	           kaddress.enterBuilding("450");
	           kaddress.enterbuildingtype("Residential");
	           kaddress.Unittypeselect("Apartment");
	           kaddress.enterunitno("3");
	           kaddress.enterfloor("2");
	           kaddress.save();
	           
	          
	 
	 
	         System.out.println("Address details saved successfully"); 
	         driver.switchTo().defaultContent();
	 	        Thread.sleep(3000);
	 	        


		}
		
		
		@Test(priority = 4)
		public void IdentitficationDetails() throws InterruptedException {
			driver.switchTo().defaultContent();
	        Thread.sleep(3000);
	        
			lead.PageScrollUp();
			 kidenty.clickIdtab();
		        lead.PageScrollDown1();
		        Thread.sleep(5000);
		        driver.switchTo().frame("viewIdentifiDetailsIdFrame");
		        		
		       kidenty.clickedi();
		       kidenty.SelectIssueDate();
		       Thread.sleep(1000);
		       kidenty.SelectExpriyDate();

		       Thread.sleep(1000);
		       kidenty.saveidenty();
		       handlePopupAfterSave("Identification details saved successfully");
		       driver.switchTo().defaultContent();
		        Thread.sleep(3000);
		        

		 
		}
	

       @Test(priority = 5)
      public void FillBankDetails() throws InterruptedException {
    	  driver.switchTo().defaultContent();
    	  Thread.sleep(3000);
	        
			lead.PageScrollUp();
			bankdetails.Clickbankdetailstab();
	        lead.PageScrollDown();
	        driver.switchTo().frame("viewBankDetailsFrame");
	        bankdetails.selectcustomertype("Main Applicant");
	        bankdetails.selectbankname("Bank of bahrain and kuwait");
	        bankdetails.Enteraccountno("123456785332");
	        bankdetails.EnterIBANno("67898765hjggjgjgkjgkjgkjgkjgkj");
	        bankdetails.selectcurrency("USD");
	        bankdetails.selectisoverseas("yes");
	        bankdetails.selectisdisursementacc("YES");
	        bankdetails.selectisrepacc("Yes");
	        bankdetails.save();
	        handlePopupAfterSave("Bank details saved successfully");
	        driver.switchTo().defaultContent();
	        Thread.sleep(3000);
    	  
	
	
	
}
       @Test(priority = 6)
       public void FillRepaymentDetails() throws InterruptedException {
     	  driver.switchTo().defaultContent();
     	  
     	 driver.switchTo().defaultContent();
   	     Thread.sleep(3000);
   	      lead.PageScrollUp();
   	   repay.clickrepaymenttab();
       lead.PageScrollDown();
       driver.switchTo().frame("viewRepaymentDetailsFrame");
       
       repay.selectRepaymode("CASH");
       
       repay.save();
       handlePopupAfterSave("Repayment details saved successfully");
       driver.switchTo().defaultContent();
       Thread.sleep(3000);
	  
 	
 }

       @Test(priority = 7)
       public void FillReferenceDetails() throws InterruptedException {
     	  driver.switchTo().defaultContent();
     	 driver.switchTo().defaultContent();
   	     Thread.sleep(3000);
   	      lead.PageScrollUp();
   	   reference.clickreferencetab();
       lead.PageScrollDown1();
       driver.switchTo().frame("viewReferenceDetailsFrame");
       reference.selectcontacttype("Other Email Id");
       reference.Enteremail("santosh@yahoo.com");
       reference.selectstatus("Active");
      reference.verifyEmailOtp();
       
       reference.save();
       handlePopupAfterSave("Reference details saved successfully");
       
       driver.switchTo().defaultContent();
       Thread.sleep(3000);  
 	
 	
 	
 }


       @Test(priority = 8)
       public void FillInsuranceDetails() {
     	  driver.switchTo().defaultContent();
     	  
 	
 	
 	
 }












}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	