package Com.Testing.Test.Selenium;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Com.Testing.Test.Selenium.Base.BaseTest;
import Com.Testing.Test.Selenium.Utils.PropertyReader;

public class TestCase11 extends BaseTest{
	    private LoginPage loginPage;
	    private DashboardPage dashboard;
	    private LeadCreation lead;
	    private ProductDetails_InsuranceDetails prodinsurance ;
	  
	    private ProductDetails_LoanDetails prodloandetails;
	    @BeforeClass
	    public void setup() {
	        

	        driver.get("http://172.21.0.93:6661/finairoLending-1.0.1");

	        loginPage = new LoginPage(driver);
	        dashboard = new DashboardPage(driver);
	        lead = new LeadCreation(driver);
	        prodinsurance = new ProductDetails_InsuranceDetails(driver);
	        prodloandetails = new ProductDetails_LoanDetails(driver);
	    }
	    @Test
	    public void FillloanItemDetails() throws InterruptedException {
	    	 loginPage.login("user1", "abcd@1234");
		     	dashboard.GoToInbox();
		         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		     	 By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
		     	 By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]"); //Itgives first record on grid 
		     	Properties prop = PropertyReader.init_prop();
		     	String leadName = prop.getProperty("lead_name");
		     	 WebElement srch = wait.until(ExpectedConditions.visibilityOfElementLocated(Search));
		     	 srch.clear();
		     	 srch.sendKeys(leadName);
		     	 srch.sendKeys(Keys.ENTER);
		     	Thread.sleep(2000);	    	
		     	 
		     	  WebElement record = wait.until(ExpectedConditions.elementToBeClickable(gridRecord));
		     	  

		     	   
		     	   Actions actions = new Actions(driver);
		     	    actions.doubleClick(record).perform();
		           Thread.sleep(15000);
		           
		           GoToDDEStage();
		           PageScrollDown();
		         prodinsurance.productdetails();
		         prodloandetails.clickloandetails();
		         PageScrollDown1();
		         driver.switchTo().frame("viewproductIdFrame");
		         prodloandetails.editrecord();
		         PageScrollDown1();
		         prodloandetails.GenerateRepaymentSchedule();
		         driver.switchTo().defaultContent();
		         PageScrollUp();
		         driver.switchTo().frame("viewproductIdFrame");
		         prodloandetails.closeschedule();
		         PageScrollDown1();
		         prodloandetails.save();
		         handlePopupAfterSave("Loan details have been saved successfully");
		         

}
}