package Selenium.Utils;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utilities {
	
	WebDriver driver;
	
	
	
 public static void selectFromDropdown(WebDriver driver,
            By dropdownLocator,
            By searchInputLocator,
            String value) {

WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

// Click dropdown
wait.until(ExpectedConditions.elementToBeClickable(dropdownLocator)).click();

// Wait for search input
WebElement searchBox = wait.until(
ExpectedConditions.visibilityOfElementLocated(searchInputLocator));

searchBox.clear();
searchBox.sendKeys(value);
searchBox.sendKeys(Keys.ENTER);
}

 public static void selectFromDropdown(WebDriver driver, By container, String value) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    
	    // Click dropdown container
	    wait.until(ExpectedConditions.elementToBeClickable(container)).click();

	    // Wait for the search input inside the dropdown
	    By searchInputLocator = By.cssSelector(".select2-container--open input.select2-search__field");
	    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(searchInputLocator));

	    searchInput.clear();
	    searchInput.sendKeys(value);

	    // Use ENTER via Actions in case normal sendKeys fails
	    searchInput.sendKeys(Keys.ENTER);
	}
 
 
 
 public static void selectFromDropdownInput(WebDriver driver, String value) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    By searchInputLocator = By.cssSelector("input.select2-search__field");

	    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(searchInputLocator));
	    searchInput.clear();
	    searchInput.sendKeys(value);
	    searchInput.sendKeys(Keys.ENTER);
	}

	public static void enterText(WebDriver driver,
            By locator,
            String value) {

WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

WebElement element = wait.until(
ExpectedConditions.visibilityOfElementLocated(locator));

element.clear();
element.sendKeys(value);
}
	

	
	

	public static void enterAmount(WebDriver driver, By locator, long value) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	    
	    // Clear the field first
	    element.clear();

	    // Use JavaScript to set the value directly
	    String script = "arguments[0].value = arguments[1];" +
	                    "arguments[0].dispatchEvent(new Event('input'));" +
	                    "arguments[0].dispatchEvent(new Event('change'));";
	    ((JavascriptExecutor) driver).executeScript(script, element, value);

	    // Optional: Send Keys in case JS doesn’t trigger validation
	    // element.sendKeys(String.valueOf(value));
	}
	
	

	
	
	
//	    public static void enteramountdouble(WebDriver driver, By vehicleprice, String value) {
//
//	        vehicleprice.click();
//
//	        // select existing value (like 0.000)
//	        vehicleprice.sendKeys(Keys.CONTROL + "a");
//
//	        // delete existing value
//	        vehicleprice.sendKeys(Keys.DELETE);
//
//	        // enter new value
//	        vehicleprice.sendKeys(value);
//
//	        // trigger javascript blur event
//	        vehicleprice.sendKeys(Keys.TAB);
//	    }
	
	    public static void enteramountdouble(WebDriver driver, By locator, String value) {

	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

	        element.click();

	        element.sendKeys(Keys.CONTROL + "a");
	        element.sendKeys(Keys.DELETE);

	        element.sendKeys(value);

	        // trigger blur event
	        element.sendKeys(Keys.TAB);
	    }
	
	   
	
	
	
	
	
	
	
	
//	public static void click(WebDriver driver, By locator) {
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//
//        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
//    }
//	
	public static void click(WebDriver driver, By locator) {

	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	    WebElement element = wait.until(
	            ExpectedConditions.presenceOfElementLocated(locator));

	    wait.until(ExpectedConditions.elementToBeClickable(locator));

	    try {
	        new Actions(driver)
	                .moveToElement(element)
	                .click()
	                .perform();
	    } catch (Exception e) {
	        ((JavascriptExecutor) driver)
	                .executeScript("arguments[0].click();", element);
	    }
	}
	   
	
	
	
	
	
	
	
	
	
	
	
	

}
