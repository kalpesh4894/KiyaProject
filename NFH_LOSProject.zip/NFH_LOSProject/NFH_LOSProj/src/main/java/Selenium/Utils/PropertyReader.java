package Selenium.Utils;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {

  private  static Properties prop;


public static Properties init_prop() {

	prop = new Properties();
    try {
        String path = System.getProperty("user.dir") + "/src/main/resources/data.properties";
        FileInputStream ip = new FileInputStream(path);
        prop.load(ip);

    } catch (Exception e) {
        e.printStackTrace();
    }

    return prop;
}
}