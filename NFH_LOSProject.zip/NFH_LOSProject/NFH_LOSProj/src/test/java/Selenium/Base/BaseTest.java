package Selenium.Base;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import Selenium.DriverFactory.DriverFactory;
import Selenium.Utils.ScreenshotUtil;

public class BaseTest {

   public WebDriver driver;
    protected String browser = "edge";

    @BeforeClass
    public void setupClass() {
        DriverFactory.initDriver(browser);
        driver = DriverFactory.getDriver();
        driver.get("http://172.21.0.123:1997/finairoLending-1.0.1/");
    }

//    @AfterClass
//    public void teardownClass() {
//        DriverFactory.quitDriver();
//    }

     
    @AfterMethod
    public void takeScreenshotAfterTest(ITestResult result) {

        String testName = result.getMethod().getMethodName();

        // Capture screenshot for PASS, FAIL, SKIP
        if (result.getStatus() == ITestResult.SUCCESS) {
            ScreenshotUtil.captureScreenshot(driver, testName + "_PASS");
        }
        else if (result.getStatus() == ITestResult.FAILURE) {
            ScreenshotUtil.captureScreenshot(driver, testName + "_FAIL");
        }
        else if (result.getStatus() == ITestResult.SKIP) {
            ScreenshotUtil.captureScreenshot(driver, testName + "_SKIP");
        }
    }
    
    
    

}