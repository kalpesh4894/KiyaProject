package Selenium.Pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import Selenium.Utils.Utilities;

public class KYC_Basicdetails {
	private WebDriver driver;
    public KYC_Basicdetails(WebDriver driver) {
        this.driver = driver;
        new WebDriverWait(driver, Duration.ofSeconds(15));
    }	
	
	

    By kyc_Tab = By.xpath("//a[contains(@href,'activeTab=KYC')]");
	By basicdetailstab = By.xpath("//a[@href=\"#menu0\"]");
	By edit = By.cssSelector("a.editBtn");
	By nationality = By.id("select2-nationality-container");
	By select2SearchInput = By.cssSelector(".select2-container--open input.select2-search__field");
	By title = By.id("select2-custPrefix-container");
	By nameasperid = By.id("nameAsPOI");
	By Countryofjur = By.id("select2-countryOfJurisdiction-container");
	By Edulevel = By.id("select2-educationLevel-container");
	By Dob = By.id("dob");
	By Maritalstatus = By.id("select2-maritalSts-container");
	By Noofdependants = By.id("noOfDependents");
	By Cattoclient = By.id("select2-clientCategory-container");
	By Autobllisted = By.id("select2-autoBlackList-container");
	By Unblacklisted = By.id("select2-UNBlackListValidated-container");
	By Unblackreason = By.id("select2-blacklistReason-container");
	By Returnedcheques = By.id("select2-returnedCheques-container");
	By Chequeanlist = By.id("select2-chequeAbuserList-container");
	By Haveindica = By.id("select2-usIndica-container");
	By save = By.id("saveBasic");
	By nameblacklisted = By.id("select2-nameBlacklistedYN-container");
	By idno = By.id("select2-nationIdBlackListedYN-container");
		
	By custcategory = By.id("select2-customerType-container");
	By Id_type = By.id("select2-idType-container");
	By idn = By.id("idNumber");
	By email = By.id("email");
	By mobile = By.id("mobileNo");
	By first = By.id("custFirstName");
	By second = By.id("custSecondName");
	By Family = By.id("custFamilyName");
	By nameasper = By.id("nameAsPOI");
	
		
	    //Page actions using utilities //
	
	
	public void clickkyc() {
		WebElement ele= driver.findElement(kyc_Tab);
		ele.click();
		
	}
	
	public void editbasicdetails() {
		WebElement ele = driver.findElement(edit);
		ele.click();
	}
	
	
	public void selectnationality(String value) {
	    Utilities.selectFromDropdown(driver, nationality, value);
	}

	public void selecttitle(String value) {
	    Utilities.selectFromDropdown(driver, title, value);
	}
	
		
	
	public void enternameasperid(String value) {
		Utilities.enterText(driver, nameasperid, value);
	}
	public void selectcountry(String value) {
		Utilities.selectFromDropdown(driver, Countryofjur,  value);
		
	}
	public void selectedulevel(String value) {
		Utilities.selectFromDropdown(driver, Edulevel, value);
			
	}
   public void selectnameblcklisted(String value) {
	Utilities.selectFromDropdown(driver, nameblacklisted, value);   
   }
   
   public void idnoblacklisted(String value) {
	   Utilities.selectFromDropdown(driver, idno, value);
   }
   
   
   
	public void SelectDOB() {

	    String year = "1993";
	    String month = "Jul";
	    String day = "20";

	    // Open date picker
	    driver.findElement(By.id("dob")).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}
    
  
    
    public void selectMaritalstatus(String value) {
    	Utilities.selectFromDropdown(driver, Maritalstatus,  value);
    	
    }
    
    public void enternoofdependants(String value) {
    	Utilities.enterText(driver, Noofdependants, value);
    }
    public void selectcatofclient(String value) {
    	Utilities.selectFromDropdown(driver, Cattoclient,  value);
    	
    }
    public void selectAutoblacklist(String value) {
    	Utilities.selectFromDropdown(driver, Autobllisted, value);
    	
    }
    public void selectUNblacklist(String value) {
    	Utilities.selectFromDropdown(driver, Unblacklisted,  value);
    	
    }
  
    public void selectUnblacklistreason(String value) {
    	Utilities.selectFromDropdown(driver, Unblackreason,  value);
    	
    }
    
    
    public void selectreturnscheque(String value) {
    	Utilities.selectFromDropdown(driver, Returnedcheques,  value);
    	
    }
    public void selectchequeabuserlist(String value) {
    	Utilities.selectFromDropdown(driver, Chequeanlist, value);
    	
    }
    public void selectdoeshaveindica(String value) {
    	Utilities.selectFromDropdown(driver, Haveindica,  value);
    	
    }
    
	public void clickSave() {
		
		Utilities.click(driver, save);
	}


	public void selectcustcategory(String value) {
		Utilities.selectFromDropdown(driver, custcategory, value);
	}
	
	public  void enteridnumber(String value) {
		Utilities.enterText(driver, idn , value);
	}
	
	public  void enteremail(String value) {
		Utilities.enterText(driver, email , value);
	}
	
	public  void entermobile(String value) {
		Utilities.enterText(driver, mobile , value);
	}
	
	public void Enterdetails(String fname, String sname , String famname , String nameasperid) {
		Utilities.enterText(driver, first, fname);
		Utilities.enterText(driver, second, sname);
		Utilities.enterText(driver, Family, famname);
		Utilities.enterText(driver, nameasper, nameasperid);
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
	
	
	

