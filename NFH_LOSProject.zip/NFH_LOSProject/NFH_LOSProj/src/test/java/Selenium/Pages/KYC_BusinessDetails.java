package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;

public class KYC_BusinessDetails extends BasePage {

	public KYC_BusinessDetails(WebDriver driver) {
        super(driver);
       
    }
	
	
	By businesstab = By.xpath("//a[contains(@href, 'menu5')]");
	By autoblacklisted =  By.id("autoBlacklisted");
    By UNblacklisted = By.id("unListValidated");
    By returncheque = By.id("returnedCheques");
    By abuserlist =By.id("chequeAbuserList");
	By sourceofincome = By.id("primrySourseIncome");
	By bankname = By.id("bankName");
	By totalcreditturnover = By.id("totCreditTurnOver");
	By noofmonths = By.id("noOfMonths");
	By consideration = By.id("avgCreditTurnoverPerc");
	By addturn = By.id("addCredTrnvbt");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
