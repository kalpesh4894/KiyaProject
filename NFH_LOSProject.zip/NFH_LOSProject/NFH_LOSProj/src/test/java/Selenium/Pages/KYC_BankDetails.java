package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class KYC_BankDetails extends BasePage {
	public KYC_BankDetails(WebDriver driver) {
        super(driver);
    }
	
    By banktab = By.partialLinkText("Bank");	
	By bankname = By.id("select2-bankName-container");
	By accountnumber = By.id("accountNumber");
	By ibanno = By.id("ibanNumber");
	By save = By.id("saveBank");
	
	
	public void clickbanktab() {
		Utilities.click(driver, banktab);
	}
	
	public void enteribanno(String value) {
		Utilities.enterText(driver, ibanno, value);
	}
	public void selectbankname(String value) {
		Utilities.selectFromDropdown(driver, bankname, value);
	}
	public void enteraccountno(String value) {
		Utilities.enterText(driver, accountnumber, value);
	}
	
	public void save() {
		Utilities.click(driver, save);
	}
	
	

}
