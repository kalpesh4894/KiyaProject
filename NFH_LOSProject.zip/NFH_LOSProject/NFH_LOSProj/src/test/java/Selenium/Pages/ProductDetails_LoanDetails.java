package Selenium.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class ProductDetails_LoanDetails extends BasePage {
	public ProductDetails_LoanDetails(WebDriver driver) {
        super(driver);
    }
	
	
	By loandetailstab = By.xpath("//a[normalize-space()='Loan Details']");
	By collateral = By.id("select2-collateralId-container");
	By vatexemption = By.id("select2-vatExempted-container");
	By vatpaymentmode = By.id("select2-vatPaymentMode-container");
	By tenure = By.id("requiredTenure");
	By lifeinsurancepaymentmode = By.id("select2-lifeInsurancePaymentMode-container");
	By firstemidate = By.id("firstEmiDate");
	By save = By.id("saveproduct");
	
	   By frequency = By.id("select2-frequency-container");
	   
	   public void selectfrequency(String value) {
	        Utilities.selectFromDropdown(driver, frequency, value);
	    }
	public void clickloandetailstab() {
		Utilities.click(driver, loandetailstab);
		
	}
	public void selectcollateral(String value) {
		Utilities.selectFromDropdown(driver, collateral, value);
		
	}
	public void selectvatexemption(String value) {
		Utilities.selectFromDropdown(driver, vatexemption, value);
	}
	public void selectvatpaymentmode(String value) {
		Utilities.selectFromDropdown(driver, vatpaymentmode, value);
	}

	public void entertenure(String value) {
	    WebElement ele = driver.findElement(tenure);
	    ele.clear();
	    ele.sendKeys(value);
	    ele.sendKeys(Keys.TAB);
	}
	
	
	
	
	
	//	public void entertenure(String value) {
//		Utilities.enterText(driver, tenure, value);
//	}
	public void selectlifeinsurancepaymentmode(String value) {
		Utilities.selectFromDropdown(driver, lifeinsurancepaymentmode,value);
		
	}
	public void selectfirstemidate() {
		 String year = "2025";
		    String month = "Jun";
		    String day = "25";

		    // Open date picker
		    driver.findElement(firstemidate).click();

		    // Select year from dropdown
		    Select yearDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-year")));
		    yearDropdown.selectByVisibleText(year);

		    // Select month from dropdown
		    Select monthDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-month")));
		    monthDropdown.selectByVisibleText(month);

		    // Select day
		    List<WebElement> allDates = driver.findElements(
		            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

		    for (WebElement dt : allDates) {
		        if (dt.getText().equals(day)) {
		            dt.click();
		            break;
		        }
		    }
	}
	public void save() {
		Utilities.click(driver, save);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
