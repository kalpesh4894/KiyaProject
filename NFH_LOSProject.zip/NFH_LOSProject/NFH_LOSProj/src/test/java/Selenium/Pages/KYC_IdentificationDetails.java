package Selenium.Pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class KYC_IdentificationDetails extends BasePage {

	
    public KYC_IdentificationDetails(WebDriver driver) {
        super(driver);
       
    }
    By identitab = By.xpath("//a[contains(@onclick,'viewIdentifiDetailsIdFrame')]");
	By editidenty = By.cssSelector("a.editBtn");
	By issuedate = By.id("issueDate");
	By expirydate = By.id("expiryDate");
	By savid = By.id("saveIdenty");
	
	
	
public void clickIdtab() {
		
		Utilities.click(driver, identitab);
	}
	
	public void clickedi() throws InterruptedException {
	Utilities.click(driver, editidenty);
	
	}
	
	

	public void SelectIssueDate() {

	    String year = "2022";
	    String month = "Jul";
	    String day = "20";

	    // Open date picker
	    driver.findElement(By.id("issueDate")).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}

	public void SelectExpriyDate() {

	    String year = "2040";
	    String month = "Jul";
	    String day = "25";

	    // Open date picker
	    driver.findElement(By.id("expiryDate")).click();

	    // Select year from dropdown
	    Select yearDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-year")));
	    yearDropdown.selectByVisibleText(year);

	    // Select month from dropdown
	    Select monthDropdown = new Select(
	            driver.findElement(By.className("ui-datepicker-month")));
	    monthDropdown.selectByVisibleText(month);

	    // Select day
	    List<WebElement> allDates = driver.findElements(
	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

	    for (WebElement dt : allDates) {
	        if (dt.getText().equals(day)) {
	            dt.click();
	            break;
	        }
	    }
	}	
	
	//For reducing code duplicacy we can reuse above two datepicker methods//
	
 public void clicksave() {
		
	Utilities.click(driver, savid);
		}
	
	
    
    
    
}
    
    
    
    
 