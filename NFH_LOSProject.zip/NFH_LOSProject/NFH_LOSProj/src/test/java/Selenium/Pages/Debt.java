package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class Debt extends BasePage {
	

	public Debt(WebDriver driver) {
        super(driver);
    }
	
	By debttab = By.linkText("Debt");
	By creditcheck = By.linkText("Credit Bureau Exposure Check");
	By product = By.id("select2-product-container");
	By amt = By.id("financeAmount_txt");
	By crntmsdpayment = By.id("currentMissedPayment");
	By historicalmsdpayment = By.id("historicalMissedPayment");
	By status = By.id("select2-currentStatus-container");
	By savebtn = By.id("saveExistingExposure");
	By save= By.id("saveCreditBuero");
	By sectab = By.linkText("Credit Bureau Check Details");

	     //Page actions //
	
	public void clickdebt() {
		Utilities.click(driver, debttab);
	}
	public void clickcreditcheck() {
		Utilities.click(driver, creditcheck);
	}
	public void selectproduct(String value) {
		Utilities.selectFromDropdown(driver, product, value);
	}
	public void enteramt(long l) {
		Utilities.enterAmount(driver, amt, l);
	}
	public void selectstatus(String value) {
		Utilities.selectFromDropdown(driver, status, value);
	}
	public void entermisspayment(String value) {
		Utilities.enterText(driver, crntmsdpayment, value);
	}
	public void enterhistmisspayment(String value) {
		Utilities.enterText(driver, historicalmsdpayment,value);
	}
	
	public void save() {
		Utilities.click(driver, savebtn);
	}
	public void clicksectab() {
		Utilities.click(driver, sectab);
	}
	  
	public void savec() {
		Utilities.click(driver, save);
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
