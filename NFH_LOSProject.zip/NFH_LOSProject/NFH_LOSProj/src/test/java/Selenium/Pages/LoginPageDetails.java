package Selenium.Pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
public class LoginPageDetails {

    private WebDriver driver;
    private WebDriverWait wait;

    // PageFactory locators
    @FindBy(id = "loginId")
    private WebElement username;

    @FindBy(id = "passwordField")
    private WebElement pwd;
    
    
    @FindBy(id = "userLogin")
    private WebElement loginButton;
    By logo = By.cssSelector("img[alt='Indostar']");

    // Constructor
    public LoginPageDetails(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Login action
    public void login(String userId, String password) {
      
        wait.until(ExpectedConditions.visibilityOf(username));
        username.clear();
        username.sendKeys(userId);

      
        wait.until(ExpectedConditions.visibilityOf(pwd));
        pwd.clear();
        pwd.sendKeys(password);

       
        wait.until(ExpectedConditions.elementToBeClickable(loginButton));
        loginButton.click();
    }
    public boolean isLogoVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(logo));
            return driver.findElement(logo).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
    
    
    
}
