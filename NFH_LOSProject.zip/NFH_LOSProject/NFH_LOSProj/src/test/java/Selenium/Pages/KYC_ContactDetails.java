package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class KYC_ContactDetails extends BasePage{

	public KYC_ContactDetails(WebDriver driver) {
        super(driver);
    }
	By contacttab = By.linkText("Contact Details");
	By contacttype = By.id("select2-contactType-container");
	By status = By.id("select2-status-container");
	By relwithcust = By.id("select2-relationWithCust-container");
	By name = By.id("relationName");
	By mono = By.id("contactNumber");
	By checkbox = By.id("isDefault");
	By save = By.id("referanceSave");
	
	public void clickcontacttab() {
		Utilities.click(driver, contacttab);
	}
	
	public void selectcontacttype(String value) {
		Utilities.selectFromDropdown(driver, contacttype, value);
		
	}
	public void selectrelation(String value) {
		Utilities.selectFromDropdown(driver, relwithcust, value);
	}
	public void entername(String value) {
		Utilities.enterText(driver, name, value);
	}
	
	public void entermono(String value) {
		Utilities.enterText(driver, mono, value);
	}
	public void selectstatus(String value) {
		Utilities.selectFromDropdown(driver, status, value);
		
	}
	public void checkbox() {
		Utilities.click(driver, checkbox);
	}
	public void save() {
		Utilities.click(driver, save);
	}
	
	
	
	
	
	
	
	
	
	
	
}
