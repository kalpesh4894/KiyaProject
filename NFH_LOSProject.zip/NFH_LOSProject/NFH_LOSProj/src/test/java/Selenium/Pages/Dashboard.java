package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.List;

public class Dashboard {

    private WebDriver driver;
    private WebDriverWait wait;

    By LeadCreateIcon = By.className("item-preLead");
    By inboxIcon = By.xpath("//a[@data-original-title ='Inbox']");
    By searchinput = By.cssSelector("input[placeholder='Enter keyword here']");
    By dde = By.linkText("Detail Data Entry");
   

    public Dashboard(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void EnterPrelead() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(LeadCreateIcon));
        element.click();
    }
   
    public void EnterInox() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(inboxIcon));
        element.click();
    }

    public boolean isLeadPresentInInbox() {
        List<WebElement> rows = driver.findElements(By.cssSelector("#dt-authdata tbody tr"));
        return rows.size() > 0;  // true if at least one row exists
    }

    public void searchLeadInGrid(String value) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(searchinput));
        searchBox.clear();
        searchBox.sendKeys(value);
        searchBox.sendKeys(Keys.ENTER);

        // wait for at least one row to appear after search
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.cssSelector("#dt-authdata tbody tr"), 0));
    }
    
    public void openFirstRecordFromInbox(String leadId) {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        By Search = By.xpath("//*[@id=\"dt-authdata_filter\"]/label/input");
        By gridRecord = By.xpath("//*[@id='dt-authdata']/tbody/tr[1]");

        WebElement srch = wait.until(
                ExpectedConditions.visibilityOfElementLocated(Search));

        srch.clear();
        srch.sendKeys(leadId);
        srch.sendKeys(Keys.ENTER);

        WebElement record = wait.until(
                ExpectedConditions.elementToBeClickable(gridRecord));

        Actions actions = new Actions(driver);
        actions.doubleClick(record).perform();
    }
    
    
    public void GotoDDE() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    	
    	WebElement ele = driver.findElement(dde);
    	ele.click();
    }






}
