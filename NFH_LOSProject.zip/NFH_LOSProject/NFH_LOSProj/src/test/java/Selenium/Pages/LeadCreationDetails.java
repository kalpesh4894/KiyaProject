package Selenium.Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Selenium.Utils.Utilities;

public class LeadCreationDetails {
	
	
	private WebDriver driver;
    public LeadCreationDetails(WebDriver driver) {
        this.driver = driver;
        new WebDriverWait(driver, Duration.ofSeconds(15));
    }
	
		
    //Page actions //
	
	By Id_type = By.id("select2-idType-container");
	By search_field = By.className("select2-search_field");
	By Id_number = By.id("idNumber");
	By Cust_type = By.id("select2-custType-container");
	By Fisrtname = By.id("fName");
	By Secondname = By.id("sName");
	By Familyname = By.id("famName");
	By MobileNo = By.id("mobileNo");
	By Product = By.id("select2-product-container");
	By Subproduct = By.id("select2-subProduct-container");
	By SearchButton = By.id("search");
	By ConverttoApp = By.id("convertpreLeadToApp");
	By select2SearchInput = By.cssSelector("input.select2-search__field");
	By Norecmsg = By.id("searchMsg");
	By Companyname = By.id("companyName");
	private By SayYesConvert = By.id("warningPopYesConvertAp");
			
	  //Page Actions using Utility Class//
	
	public void Entercompanyname(String value) {
		Utilities.enterText(driver, Companyname, value);
	}
	
	public void selectIdtype(String value) {
        Utilities.selectFromDropdown(driver, Id_type, select2SearchInput, value);
       
	}
	
	
	public void enterIdNumber(String value) {
        Utilities.enterText(driver, Id_number, value);
    }

	

    public void enterfirstname(String value) {
        Utilities.enterText(driver, Fisrtname, value);
    }

    public void entersecondName(String value) {
        Utilities.enterText(driver, Secondname, value);
    }
    public void enterFamilyname(String value) {
        Utilities.enterText(driver, Familyname, value);
    }

    public void entermobileno(String value) {
        Utilities.enterText(driver, MobileNo, value);
    }

    public void selectproducttype(String value) {
        Utilities.selectFromDropdown(driver, Product, select2SearchInput, value);
    }

    public void selectsubproducttype(String value) {
        Utilities.selectFromDropdown(driver, Subproduct, select2SearchInput, value);
    }
    
    public void search() {
        Utilities.click(driver, SearchButton);
    }

    public void convertToApplication() {
        Utilities.click(driver, ConverttoApp);
    }

    public void clickYesConvert() {
        Utilities.click(driver, SayYesConvert);
    }
	 
    
}
