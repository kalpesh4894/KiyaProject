package Selenium.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.JavascriptExecutor;
import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class KYC_EmploymentDetails extends BasePage {

	
	public KYC_EmploymentDetails(WebDriver driver) {
        super(driver);
    }

  By empltab =By.cssSelector("a[href='#menu3");
  By natureofemp = By.id("select2-natureOfEmplmt-container");
  By sourceofincome = By.id("select2-activityNote-container");
  By modeofsal = By.id("select2-modeOfSalary-container");
  By natureofempl = By.id("select2-nameofEmployer-container");
  By others = By.id("othersName");
  By emplclass = By.id("select2-employerClass-container");
  By position = By.id("position");
  By dateofoest = By.id("dateofEstablishement");
  By doemploy = By.id("dateOfEmployment");
  By dateofcontr = By.id("contractValidityDate");
  By empltype =By.id("select2-employmentType-container");
  By sector = By.id("select2-sector-container");
  By employemnttype = By.id("select2-employmentType-container");
  By incometype = By.id("select2-incomeType-container");
  By incomeamount =By.id("incomeAmt_txt");
  By addincome = By.id("addIncomebt");
  By deducttype = By.id("select2-deductionType-container");
  By deductamount = By.id("deductionAmt_txt");
  By save = By.id("saveEmployment");
  By adddeduct = By.id("addDeductionBt");
  
  
  
        public void clickempltab() {
        	Utilities.click(driver, empltab);
        }
        public void selectNatureofemployemnt(String value) {
        	Utilities.selectFromDropdown(driver, natureofemp, value);
        }
       
        public void selectsourceofincome(String value) {
        	Utilities.selectFromDropdown(driver, sourceofincome, value);
        }
        public void selectmodeofsalary(String value) {Utilities.selectFromDropdown(driver, modeofsal, value);}
        public void selectnatureofemployer(String value) {Utilities.selectFromDropdown(driver, natureofempl, value);}
        public void selectemploymentclass(String value) {Utilities.selectFromDropdown(driver, emplclass, value);}
        public void selectemploymentype(String value) {Utilities.selectFromDropdown(driver, employemnttype, value);}
        public void selectsector(String value) {Utilities.selectFromDropdown(driver, sector, value);}
        public void  enterothers(String value) {Utilities.enterText(driver, others, value);}
        public void enterposition(String value) {Utilities.enterText(driver, position, value);}
        public void enterdateofestablishment() {
        	String year = "2012";
    	    String month = "Jul";
    	    String day = "20";

    	    // Open date picker
    	    driver.findElement(dateofoest).click();

    	    // Select year from dropdown
    	    Select yearDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-year")));
    	    yearDropdown.selectByVisibleText(year);

    	    // Select month from dropdown
    	    Select monthDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-month")));
    	    monthDropdown.selectByVisibleText(month);

    	    // Select day
    	    List<WebElement> allDates = driver.findElements(
    	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

    	    for (WebElement dt : allDates) {
    	        if (dt.getText().equals(day)) {
    	            dt.click();
    	            break;
    	        }
    	    }
        }
        public void enterdateofemployment() {
        	String year = "2017";
    	    String month = "Jul";
    	    String day = "20";

    	    // Open date picker
    	    driver.findElement(doemploy).click();

    	    // Select year from dropdown
    	    Select yearDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-year")));
    	    yearDropdown.selectByVisibleText(year);

    	    // Select month from dropdown
    	    Select monthDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-month")));
    	    monthDropdown.selectByVisibleText(month);

    	    // Select day
    	    List<WebElement> allDates = driver.findElements(
    	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

    	    for (WebElement dt : allDates) {
    	        if (dt.getText().equals(day)) {
    	            dt.click();
    	            break;
    	        }
    	    }
        }
        public void entercontractvaliditydate() {
        	String year = "2050";
    	    String month = "Jul";
    	    String day = "20";

    	    // Open date picker
    	    driver.findElement(dateofcontr).click();

    	    // Select year from dropdown
    	    Select yearDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-year")));
    	    yearDropdown.selectByVisibleText(year);

    	    // Select month from dropdown
    	    Select monthDropdown = new Select(
    	            driver.findElement(By.className("ui-datepicker-month")));
    	    monthDropdown.selectByVisibleText(month);

    	    // Select day
    	    List<WebElement> allDates = driver.findElements(
    	            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

    	    for (WebElement dt : allDates) {
    	        if (dt.getText().equals(day)) {
    	            dt.click();
    	            break;
    	        }
    	    }
  
        }  	  
        
    	    public void selectincometype(String value) {
           	 Utilities.selectFromDropdown(driver, incometype, value);
            }   
        
    	      	

    	    public void enterincomeamt(long amount) {
    	        Utilities.enterAmount(driver, incomeamount, amount);
    	    }

    	    public void enterdeductamt(long amount) {
    	        Utilities.enterAmount(driver, deductamount, amount);
    	    }
    	    public void clickadd() {
           	 Utilities.click(driver, addincome);
            }  
        
    	    public void selectdeduct(String value) {
              	 Utilities.selectFromDropdown(driver, deducttype, value);
               }   
           
           
       	   
               	    public void clickadd2() {
              	 Utilities.click(driver, adddeduct);
               }  
           
       	  public void clicksave() {
       		  Utilities.click(driver, save);
       	  }    
        
        }
        





















