package Selenium.Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class KYYC_AddressDetails extends BasePage {
	public KYYC_AddressDetails(WebDriver driver) {
        super(driver);
    }
      //Page Locators //
	
	By addressDetailsTab = By.linkText("Address Details");
	By addtype = By.id("select2-addressType-container");
	By PropOwnership = By.id("select2-proptyOwshp-container");
	By flat = By.id("flatOrVilla");
	By gate = By.id("gate");
	By Build = By.id("building");
	By avenue = By.id("avenue");
	By block = By.id("select2-pinCode-container");
	By city = By.id("select2-state-container");
	By Pobox = By.id("poBoxNumber");
	By permcheckbox = By.id("isPermantAdd");
	By Bussadd = By.id("isBusinessAdd");  
    By MailingAdr = By.id("isMailingAddr");
    By save = By.id("saveAddr");
 
    
             // Page Actions //
    
   public void clickaddr() {
	   Utilities.click(driver, addressDetailsTab);
   } 
   
      
    
   public void selectaddrtype(String value) {
	   Utilities.selectFromDropdown(driver, addtype, value);
   }
   
   public void selectpropown(String value) {
	   Utilities.selectFromDropdown(driver, PropOwnership, value);
   }
   public void selectblock(String value) {
	   Utilities.selectFromDropdown(driver, block, value);
   }
   public void selectcity(String value) {
	   Utilities.selectFromDropdown(driver, city, value);
   }
   
   
  public void enterflat(String value) {
	Utilities.enterText(driver, flat, value);  
  }
   public void entergate(String value) {
	  Utilities.enterText(driver, gate, value);
  }
    public void entervilla(String value) {
	  Utilities.enterText(driver, Build, value);
   }
    public void enteravenue(String value) {
	  Utilities.enterText(driver, avenue, value);
}
    public void enterpo(String value) {
  	  Utilities.enterText(driver, Pobox, value);
  }
   
   public void clicksave() {
	Utilities.click(driver, save);
   }
 
   public void checkbox1() {
	   WebElement checkbox = driver.findElement(permcheckbox);
	   if (!checkbox.isSelected()) {
	       checkbox.click();
	   }
   }	   
	   public void checkbox2() {
		   WebElement checkbox = driver.findElement(Bussadd);
		   if (!checkbox.isSelected()) {
		       checkbox.click();
		   }}
		   public void checkbox3() {
			   WebElement checkbox = driver.findElement(MailingAdr);
			   if (!checkbox.isSelected()) {
			       checkbox.click();
			   }
	   
	   
			
	   
	   
	   
	   
	   
   }









































}
    
    
