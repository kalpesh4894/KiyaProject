package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;
import org.openqa.selenium.WebElement;
public class ProductDetails_CollateralDetails extends BasePage {
	public ProductDetails_CollateralDetails(WebDriver driver) {
        super(driver);
    }
	
	
	By proddetails = By.xpath("//a[contains(@href,'activeTab=Product Details')]");
//	By collatdetails  = By.xpath("//a[contains(@onclick,'viewCollateralBasicDtlFrame')]");
	By collatdetails = By.xpath("//a[normalize-space()='Collateral Details']");
	By recwithnfh = By.id("select2-regWithNfh-container");
	By vehpurpose = By.id("vehiclePurposeDiv");
	By hirepurchase = By.id("select2-hirePurchase-container");
	By sectype = By.id("select2-isPrimrySecurity-container");
	By vehdealer = By.id("select2-vehDealer-container");
	By dealersalesmon = By.id("select2-dealerSaleman-container");
	By vehiclecategory = By.id("select2-vehCat-container");
	By vehiclemaker = By.id("select2-vehMaker-container");
	By vehiclemodel = By.id("select2-vehModel-container");
	By Vehmodelcategory = By.id("select2-vehModelCat-container");
	By country = By.id("select2-manufactureCountry-container");
	By chassisno = By.id("chasisNumber");
	By engineno = By.id("engineNumber");
	By color = By.id("select2-colour-container");
	By yomanu = By.id("select2-manufactureYear-container");
	By vehicleprice = By.id("vehiclePrice_txt");
	By dppercent = By.id("downPaymentPer_txt");
	By dptonfh = By.id("initialPaymt_txt");
	By dptodealer = By.id("paymentToDealer_txt");
	By actualvehprice = By.id("actVehiclePrice_txt");
	By adminfees = By.id("adminCharge_txt");
	By adminpaymode = By.id("select2-modeOfPayment-container");
	By isinsurancewithnfh = By.id("select2-isInsuredWithNFH-container");
	By save = By.id("saveCollateral");
	
	
	   // Page actions //
	
	
//	public void clickprodscreen() {}
//	public void clickprodcollateraldetails() {}
//	public void selectrecavailwithnfh() {}
//	public void selectvehiclepurpose() {}
//	public void selectsecuritytype() {}
//	public void selectvehicledealer() {}
//	public void selectdealersalesmon() {}
//	public void selectvehiclecategory() {}
//	public void selectvehiclemaker() {}
//	public void selectvehiclemodel() {}
//	public void selectvehiclemodelcategory() {}
//	public void selectcountry() {}
//	public void selectcolor() {}
//	public void selectyomanufact() {}
//	public void enterchassisno() {}
//	public void enterengineno() {}
//	public void entervehicleprice() {}
//	
	 public void clickProductScreen() {
	        Utilities.click(driver, proddetails);
	    }

	    public void clickCollateralDetails() {
	        Utilities.click(driver, collatdetails);
	    }

	    public void selectRegWithNFH(String value) {
	        Utilities.selectFromDropdown(driver, recwithnfh, value);
	    }

	    public void selectVehiclePurpose(String value) {
	        Utilities.selectFromDropdown(driver, vehpurpose, value);
	    }

	    public void selectHirePurchase(String value) {
	        Utilities.selectFromDropdown(driver, hirepurchase, value);
	    }

	    public void selectSecurityType(String value) {
	        Utilities.selectFromDropdown(driver, sectype,  value);
	    }

	    public void selectVehicleDealer(String value) {
	        Utilities.selectFromDropdown(driver, vehdealer,  value);
	    }

	    public void selectDealerSalesman(String value) {
	        Utilities.selectFromDropdown(driver, dealersalesmon,  value);
	    }

	    public void selectVehicleCategory(String value) {
	        Utilities.selectFromDropdown(driver, vehiclecategory,  value);
	    }

	    public void selectVehicleMaker(String value) {
	        Utilities.selectFromDropdown(driver, vehiclemaker, value);
	    }

	    public void selectVehicleModel(String value) {
	        Utilities.selectFromDropdown(driver, vehiclemodel,  value);
	    }

	    public void selectVehicleModelCategory(String value) {
	        Utilities.selectFromDropdown(driver, Vehmodelcategory, value);
	    }

	    public void selectCountry(String value) {
	        Utilities.selectFromDropdown(driver, country, value);
	    }

	    public void selectColor(String value) {
	        Utilities.selectFromDropdown(driver, color,  value);
	    }

	    public void selectYearOfManufacture(String value) {
	        Utilities.selectFromDropdown(driver, yomanu, value);
	    }

	    public void enterChassisNumber(String value) {
	        Utilities.enterText(driver, chassisno, value);
	    }

	    public void enterEngineNumber(String value) {
	        Utilities.enterText(driver, engineno, value);
	    }

	   
	    public void enterVehiclePrice(String price) throws InterruptedException {
	    	Utilities.enteramountdouble(driver, vehicleprice, price);
	    }
	    
	    
	    
	    
	    
//	    public void enterVehiclePrice(double value) {
//	        Utilities.enterAmountdouble(driver, vehicleprice, value);
//	    }

	    public void enterDownPaymentPercent(String value) {
	        Utilities.enteramountdouble(driver, dppercent, value);
	    }

	    public void enterDownPaymentToNFH(long value) {
	        Utilities.enterAmount(driver, dptonfh, value);
	    }

	    public void enterDownPaymentToDealer(String value) {
	        Utilities.enteramountdouble(driver, dptodealer, value);
	    }
	
	public void enterActualVehiclePrice(String value) {
        Utilities.enteramountdouble(driver, actualvehprice, value);
    }

    public void enterAdminFees(String value) {
        Utilities.enteramountdouble(driver, adminfees, value);
    }
   
    public void selectAdminPaymentMode(String value) {
        Utilities.selectFromDropdown(driver, adminpaymode, value);
    }

    public void selectInsuranceWithNFH(String value) {
        Utilities.selectFromDropdown(driver, isinsurancewithnfh, value);
    }

    public void clickSave() {
        Utilities.click(driver, save);
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
