package Selenium.Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class PolicyReview extends BasePage {
	public PolicyReview(WebDriver driver) {
        super(driver);
    }
	
	By policyreviewtab = By.linkText("Policy Review");
    By policytab = By.cssSelector("a[href='#menu0']");
	By policyreviewact = By.id("generatePolCheck");
	By policycheckbox = By.id("selectAllActionTaken");
	By deviate = By.id("deviate");
	By Creditscorecardtab = (By.cssSelector("a[href='#menu1']"));
	By internalscore = By.id("generateBRE");
	By customerriskrating =By.cssSelector("a[href='#menu2']");
	By customerriskbtn = By.id("generate");
	
	


	
	
	
	public void clickpolicyreview() {
		Utilities.click(driver, policyreviewtab);
	}
	public void clickcreditpolicycheck() {
		Utilities.click(driver,policytab );
	}
	public void clickpolicycheck() {
		Utilities.click(driver,policyreviewact );
	}
	
	public void clickcheck() {
		Utilities.click(driver,policyreviewact );
	}
	public void clickcheckb() {
		Utilities.click(driver,policycheckbox);
	}
	public void clickdeviate() {
		Utilities.click(driver, deviate );
	}
	
	
	
	public void clickcreditscorecardtab() {
		Utilities.click(driver, Creditscorecardtab );		
	}
	public void clickscorecard() {
		Utilities.click(driver, internalscore );
	}
	
	public void clickcustomerriskratingtab() {
		Utilities.click(driver, customerriskrating);
	}
	public void clickrating() {
		Utilities.click(driver, customerriskbtn);
	}
	
	 public void handlePopupIfPresent() {

	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));

	        try {
	            WebElement popupBtn = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                    By.xpath("//button[contains(text(),'Yes') or contains(text(),'OK') or contains(text(),'Close')]")
	                )
	            );

	            popupBtn.click();
	            System.out.println("Popup appeared and handled");

	        } catch (TimeoutException e) {
	            System.out.println("No popup appeared, continuing execution");
	        }
	    }
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
