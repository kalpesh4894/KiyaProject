package Selenium.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class ProductDetails_RepaymentAndSourcingDetails extends BasePage {
	public ProductDetails_RepaymentAndSourcingDetails(WebDriver driver) {
        super(driver);
    }
	
	By repaymenttab = By.cssSelector("a.nav-link[href='#menu2']");
	                                 
	By sourcingtab  = By.cssSelector("a.nav-link[href='#menu3']");
	By repaymode = By.id("select2-repaymentMode-container");
	By Isdefault = By.id("select2-isDefault-container");
	By checkid = By.id("copyAllColl");
	By saverepayment = By.id("saveRepaymentDtls");
	By savesourcing = By.id("saveSourcing");
	
	 public void clickrepaymentdetailstab() {
		 Utilities.click(driver, repaymenttab);
	 }
	 public void selectrepaymentmode(String value) {
		 Utilities.selectFromDropdown(driver, repaymode, value);
	 }
	 public void selectisdefault(String value) {
		 Utilities.selectFromDropdown(driver, Isdefault, value);
	 }
	 public void clickchecbox() {
		 Utilities.click(driver, checkid);
	 }
	 public void savekrepayment() {
		 Utilities.click(driver, saverepayment );
	 }
	 
	 public void clicksourcingdetailstab() {
		 Utilities.click(driver, sourcingtab);
	 }
	 public void clicksavesourcing() {
		 Utilities.click(driver, savesourcing);
	 }
	public void clicksaverapayment() {
		Utilities.click(driver, saverepayment);
	}

}
