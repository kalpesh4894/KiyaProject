package Selenium.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Selenium.BasePages.BasePage;
import Selenium.Utils.Utilities;

public class CorporateDetails extends BasePage {
	public CorporateDetails(WebDriver driver) {
        super(driver);
    }
	
	By app_type = By.id("select2-applicantType-container");
	By comp = By.id("companyName");
	By email_corp = By.id("email");
	By Formorg = By.id("select2-formOfOrganization-container");
	By regdate = By.id("registrationDate");
	By expdate = By.id("expirationDate");
	By placeofest = By.id("select2-placeOfEstablishment-container");
	By vatregno = By.id("vatRegNumber");
	By industry = By.id("select2-purposeCode-container");
	By sector = By.id("select2-subPurposeCode-container");
	By nhra = By.id("nhraNumber");
	By savebtn = By.id("saveBasic");
	
	By flat = By.id("flatOrVillaC");
	By villa = By.id("buildingC");
	By avenue = By.id("avenueC");
	By block = By.id("select2-pinCodeC-container");
	By city = By.id("select2-stateC-container");
	By POBOX = By.id("poBoxNumberC");
   
	
	
	
	
	By businesstab = By.linkText("Business Details"); 
	By Autoblack = By.id("autoBlacklisted");
	By unblack = By.id("unListValidated");
	By returnedcheques = By.id("returnedCheques");
	By chequeabuser = By.id("chequeAbuserList");
	By sourceofinc = By.id("primrySourseIncome");
	By bankname = By.id("bankName");
	By Totalcredturnover = By.id("totCreditTurnOver");
	By Noofmonths = By.id("noOfMonths");
	By percentturnover = By.id("avgCreditTurnoverPerc");
	By addcred =By.id("addCredTrnvbt");
	By calculate = By.id("fundBtn");
	By savebusnes = By.id("saveBusin");
	By check1 = By.id("isPermantAddC");
	By check2 = By.id("isBusinessAddC");
	By check3 = By.id("isMailingAddrC");

	
	public void Enteraddress(String flatC , String BuildC , String AvenueC) {
		driver.findElement(flat).sendKeys(flatC);
		driver.findElement(villa).sendKeys(BuildC);
		driver.findElement(avenue).sendKeys(AvenueC);
		
		
	}
	public void selectblock(String value) {
		Utilities.selectFromDropdown(driver, block, value);
	}
	
	public void selectarea(String value) {
		Utilities.selectFromDropdown(driver, city, value);
	}
	
	public void checkboxes() {
		Utilities.click(driver, check1);
		Utilities.click(driver, check2);
		Utilities.click(driver, check3);
	}
	
	
	
	
	public void gotobusinessdetails() {
		Utilities.click(driver, businesstab);
	}
	
	
	public void selectautoblacklisted() {
		WebElement dropdown = driver.findElement(Autoblack);
     	Select select = new Select(dropdown);
		select.selectByVisibleText("NO");	
		
		
	}
	public void selectunblacklisted() {
		WebElement dropdown = driver.findElement(unblack);
     	Select select = new Select(dropdown);
		select.selectByVisibleText("NO");	
		
	}
	public void selectreturnedcheques() {
		WebElement dropdown = driver.findElement(returnedcheques);
     	Select select = new Select(dropdown);
		select.selectByVisibleText("NIL");	
		
	}
	public void selectchequeabuser() {
		WebElement dropdown = driver.findElement(chequeabuser);
     	Select select = new Select(dropdown);
		select.selectByVisibleText("UNLISTED");	
		
	}
	public void selectsourceofincome() {
	WebElement dropdown = driver.findElement(sourceofinc);
 	Select select = new Select(dropdown);
	select.selectByVisibleText("Business Income");	
	}	
	
	public void selectBank() {
		WebElement dropdown = driver.findElement(bankname);
	 	Select select = new Select(dropdown);
		select.selectByVisibleText("AL HILAL BANK");	
		
	}
	
	public void entertotalcreditturnover(String value) {
		Utilities.enterText(driver, Totalcredturnover, value);
		
	}
	
	public void entermonths(String value) {
		Utilities.enterText(driver, Noofmonths, value);
		
	}
	
	public void selectconsideration() {
		WebElement dropdown = driver.findElement(percentturnover);
	 	Select select = new Select(dropdown);
		select.selectByVisibleText("25");	
		driver.findElement(addcred).click();
		
	}
	
	
	public void Calculate() throws InterruptedException {
		driver.findElement(calculate).click();
		Thread.sleep(3000);
		driver.findElement(savebusnes);
	}
	
	
	
	
	
	
	
	
	
	
	public void selectapp_type(String value) {
		Utilities.selectFromDropdown(driver, app_type, value);
	}
	public void selectcompanyname(String value) {
		Utilities.selectFromDropdown(driver, comp, value);
	}
	public void selectformoforg(String value) {
		Utilities.selectFromDropdown(driver, Formorg, value);
	}
	public void selectplaceofest(String value) {
		Utilities.selectFromDropdown(driver, placeofest, value);
	}
	public void selectinsutry(String value) {
		Utilities.selectFromDropdown(driver, industry, value);
	}
	public void selectsector(String value) {
		Utilities.selectFromDropdown(driver, sector, value);
	}
	public void enteremail(String value) {
		 Utilities.enterText(driver, email_corp, value);
	}
	public void selectregdate() {
		 String year = "2012";
		    String month = "Jul";
		    String day = "25";

		    // Open date picker
		    driver.findElement(regdate).click();

		    // Select year from dropdown
		    Select yearDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-year")));
		    yearDropdown.selectByVisibleText(year);

		    // Select month from dropdown
		    Select monthDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-month")));
		    monthDropdown.selectByVisibleText(month);

		    // Select day
		    List<WebElement> allDates = driver.findElements(
		            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

		    for (WebElement dt : allDates) {
		        if (dt.getText().equals(day)) {
		            dt.click();
		            break;
		        }
		    }
		}	
		
		
	
	public void selectexpdate() {
		
		 String year = "2056";
		    String month = "Jul";
		    String day = "25";

		    // Open date picker
		    driver.findElement(expdate).click();

		    // Select year from dropdown
		    Select yearDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-year")));
		    yearDropdown.selectByVisibleText(year);

		    // Select month from dropdown
		    Select monthDropdown = new Select(
		            driver.findElement(By.className("ui-datepicker-month")));
		    monthDropdown.selectByVisibleText(month);

		    // Select day
		    List<WebElement> allDates = driver.findElements(
		            By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));

		    for (WebElement dt : allDates) {
		        if (dt.getText().equals(day)) {
		            dt.click();
		            break;
		        }
		    }
		}	
		
	
	public void entervatregno(String value) {
		Utilities.enterText(driver, vatregno, value);
	}
	public void enterNHRA(String value) {
		Utilities.enterText(driver, nhra, value);
		
	}

	
	

}
