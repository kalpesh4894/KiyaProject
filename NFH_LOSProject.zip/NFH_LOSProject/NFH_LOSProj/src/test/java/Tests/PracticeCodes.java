package Tests;

public class PracticeCodes {

	    public static void main(String[] args) {
	        String sentence = "i am working in infosys";
	        String reversed = "";

	        for (int i = sentence.length() - 1; i >= 0; i--) {
	            reversed += sentence.charAt(i);
	        }

	        System.out.println(reversed);
	    }
}
