package Tests;


import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Selenium.Utils.PropertyReader;
import Selenium.Base.BaseTest;
import Selenium.Pages.Dashboard;
import Selenium.Pages.Debt;
import Selenium.Pages.KYC_BankDetails;
import Selenium.Pages.LeadCreationDetails;
import Selenium.Pages.LoginPageDetails;
import Selenium.Pages.PolicyReview;
import Selenium.Pages.ProductDetails_CollateralDetails;
import Selenium.Pages.ProductDetails_LoanDetails;
import Selenium.Pages.ProductDetails_RepaymentAndSourcingDetails;
import Selenium.Utils.ScrollUtils;
import Selenium.Pages.KYC_Basicdetails;
import Selenium.Pages.KYC_ContactDetails;
import Selenium.Pages.KYC_EmploymentDetails;
import Selenium.Pages.KYC_IdentificationDetails;
import Selenium.Pages.KYYC_AddressDetails;


public class LoginTest extends BaseTest {

    private LoginPageDetails loginPage;
    private Dashboard dashboard;
    private LeadCreationDetails leadCreation;
    private KYC_Basicdetails basicdetails;
    private KYYC_AddressDetails adddetails;
    private KYC_IdentificationDetails idetails;
    private KYC_EmploymentDetails employment;
    private KYC_BankDetails bank;
    private KYC_ContactDetails contact;
    private Debt debt;
    private ProductDetails_CollateralDetails collaterals;
    private ProductDetails_LoanDetails loandetails;
    private ProductDetails_RepaymentAndSourcingDetails repaysource;
    private PolicyReview policy;
    
    @BeforeClass
    
    public void testSetup() {
    	
    	
    	 loginPage = new LoginPageDetails(driver);
    	 dashboard = new Dashboard(driver);
    	 leadCreation = new LeadCreationDetails(driver);
    	 basicdetails = new KYC_Basicdetails(driver);
    	 adddetails = new KYYC_AddressDetails(driver);
    	 idetails = new KYC_IdentificationDetails(driver);
    	 employment = new KYC_EmploymentDetails(driver);
    	 bank = new KYC_BankDetails(driver);
    	 contact = new KYC_ContactDetails(driver);
    	 debt = new Debt(driver);
    	 collaterals = new ProductDetails_CollateralDetails(driver);
    	 loandetails = new ProductDetails_LoanDetails(driver); 
    	 repaysource = new ProductDetails_RepaymentAndSourcingDetails(driver);
    	 policy = new PolicyReview(driver);
   }
       
    @Test(priority = 1)
    public void loginCase() {

        loginPage = new LoginPageDetails(driver);

        
        String username = "20";
        String password = "abcd@1234";

        loginPage.login(username, password);
        if (loginPage.isLogoVisible()) {
            System.out.println("Login successful! Logo is visible.");
        } else {
            System.out.println("Login failed! Logo not visible.");
        }
    }
    
    
    @Test(priority = 2, dependsOnMethods = {"loginCase"})
    public void leadcreation() {
        dashboard.EnterPrelead();
        Properties prop = PropertyReader.init_prop();
        leadCreation.selectIdtype(prop.getProperty("idType"));
        leadCreation.enterIdNumber(prop.getProperty("idNumber"));
        leadCreation.enterfirstname(prop.getProperty("firstName"));
        leadCreation.entersecondName(prop.getProperty("secondName"));
        leadCreation.enterFamilyname(prop.getProperty("familyName"));
        leadCreation.entermobileno(prop.getProperty("mobile"));
        leadCreation.selectproducttype(prop.getProperty("product"));
        leadCreation.selectsubproducttype(prop.getProperty("subProduct"));
        leadCreation.search();
        ScrollUtils.scrollDown(driver, 200);
        leadCreation.convertToApplication();
        leadCreation.clickYesConvert();
   
        
    }
    
    
    @Test(priority=3, dependsOnMethods = {"leadcreation"})
       public void InboxAppearance() {
   	dashboard.EnterInox();
    	 Properties prop = PropertyReader.init_prop();
    	 String leadId = prop.getProperty("idNumber");
    	 
    	 dashboard.searchLeadInGrid(leadId);
     	 boolean leadExists = dashboard.isLeadPresentInInbox();
    	    Assert.assertTrue(leadExists, "Lead should appear in Inbox grid.");	
       }
   
  

    @Test(priority=4) 
    public void KYC_Basicdetails() throws InterruptedException {
    	    dashboard.EnterInox();
            String leadId = PropertyReader.init_prop().getProperty("idNumber");
            dashboard.openFirstRecordFromInbox(leadId);
    	   	ScrollUtils.scrollDown(driver, 400);
    	   	dashboard.GotoDDE();
    	   	basicdetails.clickkyc();
    
            ScrollUtils.scrollDown(driver,100);
            Thread.sleep(1000);
            driver.switchTo().frame("viewBasicDetailsFrame");
  	   	
    	   	basicdetails.editbasicdetails();
    	   	Thread.sleep(2000);
    	   	Properties prop = PropertyReader.init_prop();
    	   	basicdetails.selectnationality(prop.getProperty("Nationality"));
    	   	ScrollUtils.scrollDown(driver, 150);
    	   	basicdetails.selecttitle(prop.getProperty("title"));
    	   	basicdetails.enternameasperid(prop.getProperty("NameAsPerId"));
    	   	basicdetails.selectcountry(prop.getProperty("Countryofjur"));
    	   	basicdetails.selectedulevel(prop.getProperty("Edulevel"));
    	   	basicdetails.SelectDOB();
    	   	ScrollUtils.scrollDown(driver, 180);
    	   	basicdetails.selectMaritalstatus(prop.getProperty("Maritalstatus"));
    	   	basicdetails.enternoofdependants(prop.getProperty("NoofDependants"));
    	   	basicdetails.selectcatofclient(prop.getProperty("CategoryOfClient"));
    	    basicdetails.selectnameblcklisted("No");
    	   	basicdetails.idnoblacklisted("No");
    	   	
    	   	
   //   	basicdetails.selectAutoblacklist(prop.getProperty("Autoblacklisted"));
    	   	basicdetails.selectUNblacklist(prop.getProperty("Unblacklisted"));
   // 	   	basicdetails.selectUnblacklistreason(prop.getProperty("Unblacklistreason"));
    	   	basicdetails.selectreturnscheque(prop.getProperty("Returnedcheques"));
    	   	basicdetails.selectchequeabuserlist(prop.getProperty("ChequeAbuserlist"));
   // 	   	basicdetails.selectdoeshaveindica(prop.getProperty("Haveindica"));
    	   	basicdetails.clickSave();
    	   	driver.switchTo().defaultContent();
    	    
    	    
    }
    
    
    @Test(priority=5)
    public void Addressdetails() {
    	ScrollUtils.scrollUp(driver, 150);
    	adddetails.clickaddr();
    	driver.switchTo().frame("viewAddressDetailsFrame");
    	Properties prop = PropertyReader.init_prop();
    	adddetails.selectaddrtype(prop.getProperty("Addresstype"));
    	adddetails.selectpropown(prop.getProperty("Propertyownership"));
    	adddetails.enterflat(prop.getProperty("Flat"));
    	adddetails.entergate(prop.getProperty("Gate"));
    	adddetails.entervilla(prop.getProperty("Villa"));
    	adddetails.enteravenue(prop.getProperty("Avenue"));
    	adddetails.selectblock(prop.getProperty("Block"));
    	adddetails.selectcity(prop.getProperty("City"));
    	adddetails.enterpo(prop.getProperty("POBOX"));
    	ScrollUtils.scrollDown(driver,40);
    	adddetails.checkbox1();
    	adddetails.checkbox2();
    	adddetails.checkbox3();
    	
    	adddetails.clicksave();   	
    	
    	
    }
    
     @Test(priority=6)
     public void identificationdetails() throws InterruptedException {
    	 driver.switchTo().defaultContent();
       ScrollUtils.scrollUp(driver, 100);
       
       idetails.clickIdtab();
       driver.switchTo().frame("viewIdentifiDetailsIdFrame");
     		
	      
	       idetails.clickedi();
	       Thread.sleep(700);
	       idetails.SelectIssueDate();
	       Thread.sleep(500);
	       idetails.SelectExpriyDate();
           Thread.sleep(500);
	       idetails.clicksave();
	       driver.switchTo().defaultContent();
	       Thread.sleep(3000);
	        
    
     }
    
     @Test(priority=7)
     public void Employmentdetails() throws InterruptedException {
    	 driver.switchTo().defaultContent();
         ScrollUtils.scrollUp(driver, 200);
         
       employment.clickempltab();
  	   driver.switchTo().frame("viewemploymentIdFrame");
  	 Properties prop = PropertyReader.init_prop();
  	 String natureOfEmployment = prop.getProperty("Natureofemployment");
  	   //Selecting nature of employment //
  	  employment.selectNatureofemployemnt(natureOfEmployment);
  	     // Salaried flow  //
  	 if (natureOfEmployment.equalsIgnoreCase("Salaried")) {

         employment.selectmodeofsalary(prop.getProperty("Modeofsalary"));
         employment.selectnatureofemployer(prop.getProperty("Natureofemployer"));
         employment.selectemploymentclass(prop.getProperty("Employerclass"));
         employment.enterposition(prop.getProperty("Position"));
         employment.enterdateofemployment();
         employment.selectemploymentype(prop.getProperty("Employmenttype"));
         employment.entercontractvaliditydate();
         employment.selectsector(prop.getProperty("Sector"));
         employment.selectsourceofincome(prop.getProperty("Sourceofincome"));
     }

     //   Self Employed Flow  //
     else if (natureOfEmployment.equalsIgnoreCase("Self Employed")) {

         employment.selectsourceofincome(prop.getProperty("Sourceofincome"));
        
     }

  	employment.selectincometype(prop.getProperty("Incometype"));
  	
  	long incomeAmount = Long.parseLong(prop.getProperty("Incomeamt"));
  	long deductAmount = Long.parseLong(prop.getProperty("Deductamt"));
  	employment.enterincomeamt(incomeAmount);
  

  	employment.clickadd();
  	ScrollUtils.scrollDown(driver, 100);
  	Thread.sleep(2000);
  	employment.selectdeduct(prop.getProperty("Deducttype"));
  	employment.enterdeductamt(1000L);
  	employment.clickadd2();
  	Thread.sleep(2000);
  	 employment.clicksave();
    driver.switchTo().defaultContent();
 }
  	        		
  	      
    	 @Test(priority=8)
    	 public void bankdetails() {
    		 driver.switchTo().defaultContent();
             ScrollUtils.scrollUp(driver, 200);
             
           bank.clickbanktab();
      	   driver.switchTo().frame("viewBankDetailsFrame");
      	 Properties prop = PropertyReader.init_prop();
      	 bank.selectbankname(prop.getProperty("Bankname"));
      	 bank.enteraccountno(prop.getProperty("Accno"));
      	 bank.enteribanno(prop.getProperty("IBANno"));
         bank.save();
    		 
    	 }
 
       @Test(priority=9)
  public void contactdetails() {
    	   
    	   driver.switchTo().defaultContent();
           ScrollUtils.scrollUp(driver, 200);
           
         contact.clickcontacttab();
    	   driver.switchTo().frame("viewReferenceDetailsFrame");
    	 Properties prop = PropertyReader.init_prop(); 
    	   contact.selectcontacttype(prop.getProperty("Contacttype"));
    	   contact.selectrelation(prop.getProperty("Relationshipwithcustomer"));
    	   contact.entername(prop.getProperty("Name"));
    	   contact.entermono(prop.getProperty("Contactno"));
    	   
    	   
    	   contact.selectstatus(prop.getProperty("Status"));
    	   contact.checkbox();
    	   contact.save();
    	   
    	   
    	   
       }
        

      @Test(priority=10)
      public void Creditcheck() throws InterruptedException {
    	  ScrollUtils.scrollUp(driver, 100);
    	  debt.clickdebt();
    	  debt.clickcreditcheck();
    	  ScrollUtils.scrollDown(driver,200);
    	  driver.switchTo().frame("viewExistingExposureFrame");
    	  Properties prop = PropertyReader.init_prop(); 
    	  debt.selectproduct(prop.getProperty("Creditproduct"));
    	  debt.enteramt(1000l);
    	  debt.enterhistmisspayment("0");
    	  debt.entermisspayment("10");
    	  debt.selectstatus(prop.getProperty("Creditstatus"));
    	  debt.save(); 	
    	  Thread.sleep(2000);
    	  driver.switchTo().defaultContent();
    	  debt.clicksectab();
    	  driver.switchTo().frame("viewCreditBureoChkDtlsFrame");
    	  debt.savec();
    	 	  
    	  
      }


@Test(priority=11)
public void collateraldetails() throws InterruptedException {
	 driver.switchTo().defaultContent();
	 ScrollUtils.scrollUp(driver, 200);
        collaterals.clickProductScreen();
	    collaterals.clickCollateralDetails();
        driver.switchTo().frame("viewCollateralBasicDtlFrame");
        Properties prop = PropertyReader.init_prop();

	    // ===== Select Dropdowns =====
	    collaterals.selectRegWithNFH("Yes");
	    collaterals.selectVehiclePurpose("Normal");
	    collaterals.selectHirePurchase("Yes");
	    collaterals.selectSecurityType("Primary");
	    collaterals.selectVehicleDealer("Deals on wheels");
	    collaterals.selectDealerSalesman("sayed hashem baqer");
	    collaterals.selectVehicleCategory("Electric vehicle");
	    collaterals.selectVehicleMaker("110-kobilco");
	    collaterals.selectVehicleModel(prop.getProperty("Vehiclepro"));
	    collaterals.selectVehicleModelCategory("truck");
	    collaterals.selectCountry("japan");
	    collaterals.selectColor("amber");
	    collaterals.selectYearOfManufacture("2007");

	    // ===== Enter Text Fields =====
	    collaterals.enterChassisNumber(prop.getProperty("ChassisNumber"));
	    collaterals.enterEngineNumber(prop.getProperty("EngineNumber"));

	    // ===== Enter Numeric Fields =====
	    collaterals.enterVehiclePrice(prop.getProperty("VehiclePrice"));
	    Thread.sleep(5000);
	    collaterals.enterDownPaymentPercent(prop.getProperty("DownPaymentPercent"));

	 // collaterals.enterDownPaymentToNFH(prop.getProperty("DownPaymentNFH"));

	 collaterals.enterDownPaymentToDealer(prop.getProperty("DownPaymentDealer"));
	 Thread.sleep(2000);

	 collaterals.enterActualVehiclePrice(prop.getProperty("ActualVehiclePrice"));
     Thread.sleep(2000);
	 collaterals.enterAdminFees(prop.getProperty("AdminFees"));
	    // ===== More Dropdowns =====
	    collaterals.selectAdminPaymentMode(prop.getProperty("AdminPaymentMode"));
	    collaterals.selectInsuranceWithNFH(prop.getProperty("InsuranceWithNFH"));

	    Thread.sleep(2000);

	    // Save
	    collaterals.clickSave();

	    // Switch Back
	    driver.switchTo().defaultContent();
	}
	
	
	@Test(priority=12)
	public void loandetails() throws InterruptedException {
		 driver.switchTo().defaultContent();
		 ScrollUtils.scrollUp(driver, 200);
	     loandetails.clickloandetailstab();
	     driver.switchTo().frame("viewproductIdFrame");
	     Properties prop = PropertyReader.init_prop();
	     loandetails.selectcollateral(prop.getProperty("Vehprod"));
	     loandetails.selectvatexemption(prop.getProperty("Vaatexemption"));
	     loandetails.selectvatpaymentmode(prop.getProperty("Vatpaymentmode"));
	     ScrollUtils.scrollDown(driver, 150);
	     loandetails.selectfrequency("Monthly");
	   /*  loandetails.entertenure(prop.getProperty("tenure"));  */
	     
	     Thread.sleep(2000);
	     loandetails.selectlifeinsurancepaymentmode(prop.getProperty("Lifeinsurancepaymentmode"));
	      Thread.sleep(2000);
	     loandetails.selectfirstemidate();
	     Thread.sleep(1500);
	     loandetails.save();
	     
	     
	     
	     		
	}
	
	
	@Test(priority=13)
	public void Repaymentandsourcingetails() throws InterruptedException {
		 driver.switchTo().defaultContent();
		 ScrollUtils.scrollUp(driver, 200);
	     repaysource.clickrepaymentdetailstab();
	     driver.switchTo().frame("viewRepaymentDetailsFrame");
	     Properties prop = PropertyReader.init_prop();
	     repaysource.selectrepaymentmode(prop.getProperty("Repaymentmode"));
	     repaysource.selectisdefault("Yes");
	     repaysource.clickchecbox();
	     repaysource.clicksaverapayment();
	     Thread.sleep(2000);
	     driver.switchTo().defaultContent();
	     repaysource.clicksourcingdetailstab();
	     driver.switchTo().frame("viewSourceDetailsFrame");
	     Thread.sleep(500);
	     repaysource.clicksavesourcing();
	     driver.switchTo().defaultContent();
	}
	

//    @Test(priority=14)
//    public void policyreview() {
//    	
//    	driver.switchTo().defaultContent();
//    	ScrollUtils.scrollDown(driver,200);
//    	policy.clickpolicyreview();
//    	policy.clickcreditpolicycheck();
//    	driver.switchTo().frame("viewBHCFrame");
//        policy.clickpolicycheck();
//        policy.handlePopupIfPresent();
//        
//        policy.clickcheckb();
//        ScrollUtils.scrollDown(driver,200);
//        policy.clickdeviate();
//        policy.handlePopupIfPresent();
//        driver.switchTo().defaultContent();
//        policy.clickcreditscorecardtab();
//        driver.switchTo().frame("BreViewScreenFrame");
//        policy.clickscorecard();
//        driver.switchTo().defaultContent();
//        policy.clickcustomerriskratingtab();
//        driver.switchTo().frame("viewCreditRatingFrame");
//        policy.clickrating();
//        
//          	
//    	
//    	
//    }
//
//











}










     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
    
    
    



