package Tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Selenium.Base.BaseTest;
import Selenium.Pages.Dashboard;
import Selenium.Pages.Debt;
import Selenium.Pages.KYC_BankDetails;
import Selenium.Pages.KYC_Basicdetails;
import Selenium.Pages.KYC_ContactDetails;
import Selenium.Pages.KYC_EmploymentDetails;
import Selenium.Pages.KYC_IdentificationDetails;
import Selenium.Pages.KYYC_AddressDetails;
import Selenium.Pages.LeadCreationDetails;
import Selenium.Pages.LoginPageDetails;
import Selenium.Pages.ProductDetails_CollateralDetails;
import Selenium.Pages.ProductDetails_LoanDetails;
import Selenium.Pages.ProductDetails_RepaymentAndSourcingDetails;
import Selenium.Utils.PropertyReader;
import Selenium.Utils.ScrollUtils;

public class Gaurantor extends BaseTest {

    private LoginPageDetails loginPage;
    private Dashboard dashboard;
    private LeadCreationDetails leadCreation;
    private KYC_Basicdetails basicdetails;
    private KYYC_AddressDetails adddetails;
    private KYC_IdentificationDetails idetails;
    private KYC_EmploymentDetails employment;
    private KYC_BankDetails bank;
    private KYC_ContactDetails contact;
    private Debt debt;
    private ProductDetails_CollateralDetails collaterals;
    private ProductDetails_LoanDetails loandetails;
    private ProductDetails_RepaymentAndSourcingDetails repaysource;
 @BeforeClass
    
    public void testSetup() {
    	
    	
    	 loginPage = new LoginPageDetails(driver);
    	 dashboard = new Dashboard(driver);
    	 leadCreation = new LeadCreationDetails(driver);
    	 basicdetails = new KYC_Basicdetails(driver);
    	 adddetails = new KYYC_AddressDetails(driver);
    	 idetails = new KYC_IdentificationDetails(driver);
    	 employment = new KYC_EmploymentDetails(driver);
    	 bank = new KYC_BankDetails(driver);
    	 contact = new KYC_ContactDetails(driver);
    	 debt = new Debt(driver);
    	 collaterals = new ProductDetails_CollateralDetails(driver);
    	 loandetails = new ProductDetails_LoanDetails(driver); 
    	 repaysource = new ProductDetails_RepaymentAndSourcingDetails(driver);

    	 
   }
 
   @Test(priority=1)
   public void Gaurantor_Basicdetails() throws InterruptedException{
	   
	   dashboard.EnterInox();
       String leadId = PropertyReader.init_prop().getProperty("idNumber");
       dashboard.openFirstRecordFromInbox(leadId);
	   	ScrollUtils.scrollDown(driver, 400);
	   	dashboard.GotoDDE();
	   	basicdetails.clickkyc();

       ScrollUtils.scrollDown(driver,100);
       Thread.sleep(1000);
       driver.switchTo().frame("viewBasicDetailsFrame");
	    
	   
	   
  	   
   }
 
}
