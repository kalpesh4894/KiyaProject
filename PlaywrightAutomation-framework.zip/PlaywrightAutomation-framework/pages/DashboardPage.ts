import { Locator, Page, expect } from '@playwright/test';
import users from '../Utils/users.json';

export class DashboardPage {

  readonly page: Page;
  readonly prelead: Locator;
  
readonly searchInput: Locator;
  readonly inboxRows: Locator;
  readonly customerNameCell: Locator;

  constructor(page: Page) {
    this.page = page;
    this.prelead = page.locator('.item-preLead');
    this.searchInput = page.locator('input[type="search"], input.form-control').first();
    this.inboxRows = page.locator('table tbody tr');
    this.customerNameCell = page.locator('table tbody tr:first-child td:nth-child(2)');


  }
 
async navigateToNewLead() {
 await this.page.waitForLoadState('networkidle');
 await this.prelead.click();

}

async navigateToInbox() {
 await this.page.locator('a.item-summary').click();
 
}


  async verifyLeadAppearsInInbox() {
    const data = users.corporateLead;

    const searchText = `${data.firstName} ${data.secondName} ${data.familyName}`.trim();
    const expectedCustomerName = `${data.firstName} ${data.secondName} ${data.familyName}`.trim();
    
    await this.searchInput.fill(searchText);
    await this.searchInput.press('Enter');

    // Wait until at least 1 record appears
    await expect(this.inboxRows).not.toHaveCount(0, { timeout: 15000 });

    // Verify Customer Name column
    await expect(this.customerNameCell).toHaveText(expectedCustomerName, { ignoreCase: true, useInnerText: true });
  

  }
  async openFirstInboxRecord() {
  // Ensure at least one row is present
  await expect(this.inboxRows).not.toHaveCount(0, { timeout: 15000 });

  // Double click on the first row
  await this.inboxRows.first().dblclick();
}


}




