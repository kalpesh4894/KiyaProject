import { Page } from '@playwright/test';
import users from '../Utils/users.json';

export class KYCPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }
  async selector(
  dropdownContainer: string,
  value: string
) {
  const container = this.page.locator(dropdownContainer);

  await container.click();
  await this.page.keyboard.type(value);
  await this.page.keyboard.press('Enter');
}
async GotoCustomerOnboarding(){
  await this.page.getByRole('link', { name: 'Customer Onboarding' }).click();
  await this.page.locator('a[href*="openApplicationTabs"][href*="CUSTOMER ONBOARDING"]').click();

  await this.page.locator('#myTab li:first-child a').waitFor({ state: 'visible' });
  await this.page.locator('a:has-text("Personal Details")').click();
}

async FillCustomerDetails() {
  const frame = this.page.frameLocator('#viewBasicDetailsFrame');

  // Wait for the iframe content to load
  await frame.locator('table tbody tr:first-child td:nth-child(4) a').waitFor({ state: 'visible' });

  // Click Edit link in the grid (4th column)
  await frame.locator('table tbody tr:first-child td:nth-child(4) a').click();

  // Select Customer Classification
  await frame.locator('#select2-customerClassification-container').click();
  await this.page.keyboard.type('Firm');
  await this.page.keyboard.press('Enter');
}




};




























