import { Page } from '@playwright/test';

export class LoginPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto('http://172.21.0.139:5555/finairoLending-1.0.1/');
  }

  async login(username: string, password: string) {
    await this.page.fill('#loginId', username);
    await this.page.fill('#uiPwd', password);
    await this.page.click('#userLogin');
    await this.page.locator('[data-original-title="New Lead"]').waitFor();
  }
}
