import { Page } from '@playwright/test';
import users from '../Utils/users.json';

export class LeadCreationPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async selector(
  dropdownContainer: string,
  value: string
) {
  const container = this.page.locator(dropdownContainer);

  await container.click();
  await this.page.keyboard.type(value);
  await this.page.keyboard.press('Enter');
}



  async createcorporateLead() {
    const data = users.corporateLead;
    await this.page.locator('[data-original-title="New Lead"]').click();
    
    await this.page.locator('#fName').fill(data.firstName);
    await this.page.locator('#sName').fill(data.secondName);
    await this.page.locator('#famName').fill(data.familyName);
    await this.page.locator('#mobileNo').fill(data.mobileNo);
    await this.page.locator('#requestedAmount').fill(data.requestedAmount);
    await this.page.locator('#requestedTerm').fill(data.requestedTerm);
    

    
   await this.selector('#select2-loanForBusiness-container','Yes');
 
    await this.page.locator('#loanForBusinessComment').fill('Ok');
   
    await this.selector('#select2-loanForOtherPurpose-container','No');
   
    await this.selector('#select2-leadSource-container', 'publication in the magazine');
     await this.selector('#select2-entrepreneurRegistered-container', 'Physical Person');
     await this.selector('#select2-registrationChannel-container','Credit Specialist');
     await this.selector('#select2-formalIncomeSource-container','Crop Production');
     await this.selector('#select2-primaryIncomeSource-container','Crop processing');
     await this.selector('#select2-region-container','zhambyl region');
     await this.selector('#select2-district-container', 'Baizak district');
     await this.selector('#select2-village-container','Baiterek village');
     await this.page.locator('#convertpreLeadToApp').click();
     await this.page.locator('#warningPopYesConvertAp').click();
       

  }
}


