import { test, Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { LeadCreationPage } from '../pages/LeadCreationPage';
import { DashboardPage } from '../pages/DashboardPage';
import users from '../Utils/users.json';
import { KYCPage } from '../pages/KYCPage';

test.describe.serial('Finairo Flow', () => {
  let sharedPage: Page;

  test('Login', async ({ browser }) => {
    const context = await browser.newContext();
    sharedPage = await context.newPage();

    const loginPage = new LoginPage(sharedPage);
    await loginPage.goto();
    await loginPage.login('infraadmin', 'abcd1234');
  });

  test('Lead Creation', async () => {
    const leadPage = new LeadCreationPage(sharedPage);
    await leadPage.createcorporateLead();
  });
   test('Inbox Appearance', async() => {
    const dashboard = new DashboardPage(sharedPage);
    
    await dashboard.navigateToInbox();
    await dashboard.verifyLeadAppearsInInbox();


});
test('Fill Personal Details', async() => {
    const dashboard = new DashboardPage(sharedPage);
    const kyc = new KYCPage(sharedPage);
    await dashboard.openFirstInboxRecord();
    await kyc.GotoCustomerOnboarding();
    await kyc.FillCustomerDetails();
    
 });

test('Fill address details', async()=>{



});























});
