import { chromium, FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();
   await page.goto('http://172.21.0.139:5555/finairoLending-1.0.1/');
//  await page.goto('http://172.21.0.123:1997/finairoLending-1.0.1');

  await page.fill('#loginId', '20');
  await page.fill('#uiPwd', 'abcd1234');
  await page.click('#userLogin');

  // wait for successful login
 // await page.waitForSelector('[data-original-title="App Pool"]');

  await context.storageState({ path: 'storageState.json' });

  await browser.close(); // ✅ CLOSE HERE
}

export default globalSetup;