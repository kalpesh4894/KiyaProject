import { LoginPage } from '../Pages/LoginPage';
import { test, expect, Page } from '@playwright/test';

test.describe.serial('Finairo Flow', () => {
  let sharedPage: Page;

  test('Login', async ({ browser }) => {
    const context = await browser.newContext();
    sharedPage = await context.newPage();

    await sharedPage.goto('http://172.21.0.139:5555/finairoLending-1.0.1/');
    await sharedPage.fill('#loginId', 'infraadmin');
    await sharedPage.fill('#uiPwd', 'abcd1234');
    await sharedPage.click('#userLogin');
    await sharedPage.locator('[data-original-title="New Lead"]').waitFor();
  });

  test('Create Lead Flow', async () => {
  //  const loginPage = new LoginPage(sharedPage);

    await sharedPage.locator('[data-original-title="New Lead"]').click();

    await sharedPage.locator('#select2-idType-container').click();
    await sharedPage.locator('.select2-search__field').last().fill('CPR');
    await sharedPage.keyboard.press('Enter');

    await sharedPage.locator('#idNumber').fill('YOU789833');
    await sharedPage.locator('#fName').fill('Mehmood');
    await sharedPage.locator('#sName').fill('Sadik');
    await sharedPage.locator('#famName').fill('Pathan');

    await sharedPage.getByRole('button', { name: 'Search' }).click();
    await sharedPage.locator('#mobileNo').fill('98786545');

    await sharedPage.locator('#select2-product-container').click();
    await sharedPage.locator('.select2-search__field').last().fill('01-Auto Loan');
    await sharedPage.keyboard.press('Enter');

    await sharedPage.locator('#select2-subProduct-container').click();
    await sharedPage.locator('.select2-search__field').last().fill('01-Vehicle Retail');
    await sharedPage.keyboard.press('Enter');

    await sharedPage.locator('#select2-scheme-container').click();
    await sharedPage.locator('.select2-search__field').last().fill('101-new');
    await sharedPage.keyboard.press('Enter');

    await sharedPage.locator('#select2-nearestBranch-container').click();
    await sharedPage.locator('.select2-search__field').last().fill('Head Office');
    await sharedPage.keyboard.press('Enter');

    await sharedPage.locator('#convertpreLeadToApp').click();
    await sharedPage.locator('#warningPopYesConvertAp').click();
  });

});
