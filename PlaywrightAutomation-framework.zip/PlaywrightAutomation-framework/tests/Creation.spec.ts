import { test, expect } from '@playwright/test';

test.beforeEach(async ({ page }) => {
  await page.goto('http://172.21.0.139:5555/finairoLending-1.0.1');
  await page.fill('#loginId', 'infraadmin');
  await page.fill('#uiPwd', 'abcd1234');
  await page.click('#userLogin');
  await page.locator('[data-original-title="New Lead"]').waitFor();
});

test('Open Finairo Lending app', async ({ page }) => {
  await expect(page.locator('[data-original-title="New Lead"]')).toBeVisible();
});

test('Create Lead Flow', async ({ page }) => {
 // const loginPage = new LoginPage(page); 
//   await test.step('Create Lead', async () => {
 
   await page.locator('[data-original-title="New Lead"]').click();

    await page.locator('#select2-idType-container').click();
   await page.locator('.select2-search__field').last().fill('CPR');
    await page.keyboard.press('Enter');

   await page.locator('#idNumber').fill('YOU789833');
   await page.locator('#fName').fill("Mehmood");
   await page.locator('#sName').fill("Sadik");
   await page.locator('#famName').fill("Pathan");

});