import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',

 globalSetup: require.resolve('./tests/global.setup.ts'),

  use: {
    baseURL: 'http://172.21.0.123:1997/finairoLending-1.0.1',
    headless: false,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    storageState: 'storageState.json', // ← uses state saved by globalSetup
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    // If you want Edge:
    // {
    //   name: 'edge',
    //   use: { ...devices['Desktop Edge'] },
    // },
  ],
});