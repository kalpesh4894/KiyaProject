package APIAutomationFramework.WorkFrame.Endpoints;

public class APIConstants {
 
 public static String BASE_URL = "https://restful-booker.herokuapp.com/booking";
 public static String CREATE_UPDATE_BOOKING_URL = "/booking";
 public static String AUTH_URL = "/auth";
 public static String PING_URL = "/ping";
 
		 

	
	
	
}
