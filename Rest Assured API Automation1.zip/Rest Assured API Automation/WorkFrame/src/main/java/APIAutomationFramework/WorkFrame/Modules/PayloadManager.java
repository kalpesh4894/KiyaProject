package APIAutomationFramework.WorkFrame.Modules;
import com.google.gson.Gson;
import com.github.javafaker.Faker;

import APIAutomationFramework.WorkFrame.POJOS.Auth;
import APIAutomationFramework.WorkFrame.POJOS.Booking;
import APIAutomationFramework.WorkFrame.POJOS.BookingDates;
import APIAutomationFramework.WorkFrame.POJOS.BookingResponse;
import APIAutomationFramework.WorkFrame.POJOS.TokenResponse;

public class PayloadManager {
	//Ser and deser
	//Converting the Java object to the String 
	//{}
	  Gson gson;
	public static String createPayloadBookingAsString() {
		Booking booking = new Booking();  
		booking.setFirstname("Sumit");
		booking.setLastname("Sangle");
		booking.setTotalprice(111);
		booking.setDepositpaid(true);
		
		BookingDates Bookingdates = new BookingDates();
		Bookingdates.setCheckin("2018-01-01");
		Bookingdates.setCheckout("2019-01-01");
		booking.setBookingdates(Bookingdates); 
		booking.setAdditionalneeds("Breakfast");
		
		System.out.println(booking);
		
		//convert java object to JSON string to show proper response
	
		Gson gson = new Gson();
		String jsonStringPayload = gson.toJson(booking);
		System.out.println(jsonStringPayload);
		
		
			return jsonStringPayload;
	}
	public String fullUpdatePayloadAsString() {
		Booking booking = new Booking();  
		booking.setFirstname("Amit");
		booking.setLastname("Sangle");
		booking.setTotalprice(111);
		booking.setDepositpaid(true);
		
		BookingDates Bookingdates = new BookingDates();
		Bookingdates.setCheckin("2018-01-01");
		Bookingdates.setCheckout("2019-01-01");
		booking.setBookingdates(Bookingdates); 
		booking.setAdditionalneeds("Breakfast");
		
		System.out.println(booking);
		
		//convert java object to JSON string to show proper response
	
		Gson gson = new Gson();
		String jsonStringPayload = gson.toJson(booking);
		System.out.println(jsonStringPayload);
		
		
			return jsonStringPayload;
	}
	public String createPayloadBookingAsStringFaker() {
		Faker faker = new Faker();
		Booking booking = new Booking();
		booking.setFirstname("Bulbul");
		booking.setLastname("Brown");
		booking.setTotalprice(123);
		booking.setDepositpaid(false);
		
		BookingDates Bookingdates = new BookingDates();
		Bookingdates.setCheckin("2025-07-08");
		Bookingdates.setCheckout("2025-12-12");
		booking.setBookingdates(Bookingdates); 
		booking.setAdditionalneeds("Breakfast");
		
		System.out.println(booking);
		//convert java object to JSON string to show proper response
		 gson = new Gson();
		String jsonStringPayload = gson.toJson(booking);
		System.out.println(jsonStringPayload);
		
		
			return jsonStringPayload;
	}
	public static String UpdatePayloadBookingAsString() {
		Booking booking = new Booking();  
		booking.setFirstname("Ram");
		booking.setLastname("Sangle");
		booking.setTotalprice(111);
		booking.setDepositpaid(false);
		
		BookingDates Bookingdates = new BookingDates();
		Bookingdates.setCheckin("2018-01-01");
		Bookingdates.setCheckout("2019-01-01");
		booking.setBookingdates(Bookingdates); 
		booking.setAdditionalneeds("Breakfast");
		
		System.out.println(booking);
		//convert java object to JSON string to show proper response
		Gson gson = new Gson();
		String jsonStringPayload = gson.toJson(booking);
		System.out.println(jsonStringPayload);
		
		
			return jsonStringPayload;
	}
	//Function for deserialization //
	public BookingResponse bookingResponseJava(String responseString) {
		
		  gson = new Gson();
		BookingResponse bookingResponse = gson.fromJson(responseString,BookingResponse.class);
		return bookingResponse;
		
	}
	
	   //get Token
	
	
	
	public String setAuthPayload() {
		//Convert auth object to jsonString 
		Auth auth = new Auth();
		auth.setUsername("admin");
		auth.setPassword("password123");
		gson = new Gson();
		String jsonPayloadString = gson.toJson(auth);
		System.out.println("Payload set to  ->" + jsonPayloadString);
		return jsonPayloadString;		
	}		
		public String getTokenFromJSON(String tokenResponse) {
			gson = new Gson();
			TokenResponse tokenResponse1 =gson.fromJson(tokenResponse, TokenResponse.class);
			return tokenResponse1.getToken();
			
		} 
		
		public Booking getResponseFromJson(String getResponse) {
			
			gson = new Gson();
			//Deserialization ///
			Booking booking = gson.fromJson(getResponse, Booking.class);
			
			return booking;
			
		}
		
		
		
	}
	
	   
	  
	 
	
	
	
	

