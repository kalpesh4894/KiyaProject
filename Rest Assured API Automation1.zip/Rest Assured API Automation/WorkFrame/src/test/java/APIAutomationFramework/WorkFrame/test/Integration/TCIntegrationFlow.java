package APIAutomationFramework.WorkFrame.test.Integration;
import org.assertj.core.api.Assertions;
import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.*;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.*;

import APIAutomationFramework.WorkFrame.Actions.AssertActions;
import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.Modules.PayloadManager;

import static org.assertj.core.api.Assertions.assertThat;
import static org.testng.Assert.assertEquals;

public class TCIntegrationFlow {

    String token;
    int bookingID;
    int updatedbookingID;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
        token = getToken();
    }

    public String getToken() {
        String payload = "{\n" +
                "  \"username\": \"admin\",\n" +
                "  \"password\": \"password123\"\n" +
                "}";


        Response response = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(payload)
                .post("/auth");

        response.then().statusCode(200);
        return response.jsonPath().getString("token");
     
    }

   


    
    @Test(groups = "Integration", priority = 1)
    @Owner("Kalpesh")
    @Description("TC-Step 1 - Verify the booking can be created")
  
   	 public void createBookingPayload() {
    
    	System.out.println(token);
    	       
    	    	String payload = PayloadManager.createPayloadBookingAsString(); 

    	        Response response = RestAssured.given()
    	                .contentType(ContentType.JSON)
    	                .body(payload)
    	                .post("/booking");

    	        response.then().log().all().statusCode(200);

    	        bookingID = response.jsonPath().getInt("bookingid");
    	        System.out.println("Created Booking ID: " + bookingID);
    	        Assert.assertTrue(bookingID > 0, "Booking ID should be greater than 0");
    	       
    }
    
    @Test(groups = "Integration", priority = 2)
    @Owner("Kalpesh")
    @Description("TC-Step 2 - Verify the booking by name")
    public void testverifybookingbyid() {
        Response response = RestAssured.given()
                .get("/booking/" + bookingID);

        response.then().log().all().statusCode(200);
        assertEquals(response.jsonPath().getString("firstname"), "Sumit");
        
    }
    
    
    
    @Test(groups = "Integration", priority = 3)
    @Owner("Kalpesh")
    @Description("TC-Step 3 - Update booking and verify it by id")
    public void testupdatedbookingbyid() {
        String payload = PayloadManager.UpdatePayloadBookingAsString(); 

        // Ensure token is fetched and used
        if (token == null || token.isEmpty()) {
            token = getToken();
        }

        Response response = RestAssured.given()
                .contentType(ContentType.JSON)
                .cookie("token", token)  // <-- This line is required!
                .body(payload)
                .put("/booking/" + bookingID);

        response.then().log().all().statusCode(200);

          String updatedFirstname = response.jsonPath().getString("firstname");
         assertEquals(response.jsonPath().getString("firstname"),"Ram");
       
//             updatedbookingID = response.jsonPath().getInt("bookingid");
//             System.out.println("Updated Booking ID: " + updatedbookingID);
        
//        if( updatedbookingID == bookingID){
//       	 System.out.println("TestCase Failed as booking is not getting updated");
//        }
//        else {
//       	 System.out.println("Passed : Booking ID has been updated");
//       	 System.out.println("Created Booking ID: " + Updated_bookingID);
//        }
        
        
    }
    @Test(groups = "Integration", priority = 4)
    @Owner("Kalpesh")
    @Description("TC-Step 4 - Delete the booking by ID")
    public void deletetebookingbyid() {
        Response response = RestAssured.given()
                .cookie("token", token)
                .delete("/booking/" + bookingID);

        response.then().log().all().statusCode(201);

        // Confirm deletion
        Response checkResponse = RestAssured.given().get("/booking/" + bookingID);
        assertEquals(checkResponse.statusCode(), 404);
    }
}
    
    
    
    
       

