package APIAutomationFramework.WorkFrame.test.CRUD;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.*;
import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.POJOS.BookingResponse;
import APIAutomationFramework.WorkFrame.Utils.PropertyReader;
import APIAutomationFramework.WorkFrame.base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Owner;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.restassured.RestAssured;
import io.restassured.response.ValidatableResponse;

public class testCreateBookingPOST extends BaseTest{

	@Link(name ="Link to Tc" , url = "https://asdas.com")
	@Issue("Jira =RB04")
	@Owner("Kalpesh")
	@Severity(SeverityLevel.BLOCKER)
	@Description("To verify that POST request is working fine")
	@Test
	
	public void testVerifyCreateBookingTCPOST() {
		requestSpecification
		.baseUri(APIConstants.BASE_URL); 
        	response = RestAssured
			.given(requestSpecification)
	  		.when().body(payloadManager.createPayloadBookingAsString()).post();
		validatableResponse = response.then().log().all();
 		validatableResponse.statusCode(Integer.parseInt(PropertyReader.readKey("booking.post.statusCode.success")));
		
		//Default Rest Assured
		validatableResponse.body("booking.firstname", Matchers.equalTo(PropertyReader.readKey("booking.post.firstname")));
		
		BookingResponse bookingResponse = payloadManager.bookingResponseJava(response.asString());
		//assertJ -> Make sure import of assertJ imported 
	
		assertThat(bookingResponse.getBooking()).isNotNull();
		assertThat(bookingResponse.getBooking().getFirstname()).isEqualTo(PropertyReader.readKey("booking.post.firstname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getLastname()).isEqualTo(PropertyReader.readKey("booking.post.lastname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getAdditionalneeds()).isEqualTo("Breakfast").isNotEmpty().isNotNull();
		
		
//		//TestNg assertions//
		assertActions.VerifyStatusCode(response, 200);
      				
		
	}
	
}
