package APIAutomationFramework.WorkFrame.Actions;

import static org.testng.Assert.assertEquals;

import io.restassured.response.Response;

public class AssertActions {
	//Common asserts which can be reused //
	//Method overloading //
	
	
	public void VerifyResponseBody(String actual,String expected, String description)
	{
		assertEquals(actual, expected, description);
	}
	
	public void VerifyResponseBody(int actual, int expected, String description)
	{
		assertEquals(actual, expected, description);
	}
	
	public void VerifyResponseBody(Response response, Integer expected)
	{
		assertEquals(response.getStatusCode(),expected);
	}
	
	
	public void VerifyStatusCode(Response response, Integer expected)
	{
		assertEquals(response.getStatusCode(),expected);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
