package APIAutomationFramework.WorkFrame.test.CRUD;
import com.google.gson.Gson;
import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.POJOS.Booking;
import APIAutomationFramework.WorkFrame.POJOS.BookingDates;
import APIAutomationFramework.WorkFrame.Utils.PropertyReader;
import APIAutomationFramework.WorkFrame.base.BaseTest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import org.testng.annotations.Test;

public class Dummy extends BaseTest {

    public static String createPayloadBookingAsString() {
        Booking booking = new Booking();
        booking.setFirstname("Sumit");
        booking.setLastname("Sangle");
        booking.setTotalprice(111);
        booking.setDepositpaid(true);

        BookingDates bookingdates = new BookingDates();
        bookingdates.setCheckin("2018-01-01");
        bookingdates.setCheckout("2019-01-01");
        booking.setBookingdates(bookingdates);

        booking.setAdditionalneeds("Breakfast");

        Gson gson = new Gson();
        String jsonStringPayload = gson.toJson(booking);
        System.out.println("Payload: " + jsonStringPayload);
        return jsonStringPayload;
    }

    @Test
    public void testVerifyCreateBookingTCPOST1() {
        requestSpecification.baseUri(APIConstants.BASE_URL);

        Response response = RestAssured
                .given(requestSpecification)
                .body(createPayloadBookingAsString())
                .post();

        ValidatableResponse validatableResponse = response.then().log().all();

        int expectedStatusCode = Integer.parseInt(PropertyReader.readKey("booking.post.statusCode.success"));
        validatableResponse.statusCode(expectedStatusCode);
    }
}


