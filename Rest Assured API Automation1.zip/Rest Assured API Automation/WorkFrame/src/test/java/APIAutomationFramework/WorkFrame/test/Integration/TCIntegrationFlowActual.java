package APIAutomationFramework.WorkFrame.test.Integration;

import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import APIAutomationFramework.WorkFrame.Actions.AssertActions;
import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.Listeners.RetryAnalyzer;
import APIAutomationFramework.WorkFrame.Modules.PayloadManager;
import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

import static org.assertj.core.api.Assertions.assertThat;

import APIAutomationFramework.WorkFrame.POJOS.Booking;
import APIAutomationFramework.WorkFrame.POJOS.BookingResponse;
import APIAutomationFramework.WorkFrame.Utils.PropertyReader;
import APIAutomationFramework.WorkFrame.base.BaseTest;

    //Demo token testing from TCIntegrationFlow class //


@Test(retryAnalyzer = RetryAnalyzer.class)
public class TCIntegrationFlowActual extends BaseTest {

	public RequestSpecification requestSpecification;
	public AssertActions assertActions;
    public PayloadManager payloadManager;
    public JsonPath jsonPath;
    public Response response;
    public ValidatableResponse validatableResponse;
	String token;
    int bookingID;
    int updatedbookingID;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
        payloadManager = new PayloadManager();
        token = getToken();
    }

	
    @Test(groups = "Integration", priority = 1)
    @Owner("Kalpesh")
    @Description("TC-Step 1 - Verify the booking can be created")
  
   	 public void createBookingPayload(ITestContext iTestContext) {
          getToken();
         iTestContext.setAttribute("token", getToken());
    	 System.out.println(token);
    	       
    	 String payload = PayloadManager.createPayloadBookingAsString(); 

    	    Response response = RestAssured.given()
    	            .contentType(ContentType.JSON)
    	            .body(payload)
    	            .post("/booking");

    	    response.then().log().all().statusCode(200);
    	    bookingID = response.jsonPath().getInt("bookingid");
	        System.out.println("Created Booking ID: " + bookingID);
	        PayloadManager payloadManager = new PayloadManager();
	        BookingResponse bookingResponse = payloadManager.bookingResponseJava(response.asString());
          
			//assertJ -> Make sure import of assertJ imported 
		
		assertThat(bookingResponse.getBooking()).isNotNull();
		assertThat(bookingResponse.getBooking().getFirstname()).isEqualTo(PropertyReader.readKey("booking.post.firstname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getLastname()).isEqualTo(PropertyReader.readKey("booking.post.lastname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getAdditionalneeds()).isEqualTo("Breakfast").isNotEmpty().isNotNull();
			
		  //set booking ID//
		iTestContext.setAttribute("bookingid", bookingResponse.getBookingid());
    	    	
     }
    
    @Test(groups = "Integration", priority = 2)
    @Owner("Kalpesh")
    @Description("TC=02 - Verify that booking by ID")
    public void testVerifyBookingID(ITestContext iTestContext) {
        token = (String) iTestContext.getAttribute("token");
        Integer bookingid = (Integer) iTestContext.getAttribute("bookingid");

        String basePathGET = APIConstants.CREATE_UPDATE_BOOKING_URL + "/" + bookingid;
        System.out.println("GET URL: " + basePathGET);

        response = RestAssured
            .given()
            .basePath(basePathGET)
            .when()
            .get();

        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(200);

        Booking booking = payloadManager.getResponseFromJson(response.asString());

        assertThat(booking.getFirstname()).isEqualTo(PropertyReader.readKey("booking.get.firstname")).isNotEmpty().isNotNull();
    }

    
    
    @Test(groups = "Integration", priority = 3)
    @Owner("Kalpesh")
    @Description("TC=03 - Verify that booking updated by ID")
    public void testUpdateBookingByID(ITestContext iTestContext) {

        token = (String) iTestContext.getAttribute("token");
        Integer bookingid = (Integer) iTestContext.getAttribute("bookingid");

        String basePathUTPATCH = APIConstants.CREATE_UPDATE_BOOKING_URL + "/" + bookingid;
        System.out.println("PUT URL: " + basePathUTPATCH);

        response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .cookie("token", token)
            .body(payloadManager.fullUpdatePayloadAsString())
            .basePath(basePathUTPATCH)
            .when()
            .put();

        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(200);
        
        Booking booking = payloadManager.getResponseFromJson(response.asString());  
        assertThat(booking.getFirstname()).isEqualTo(PropertyReader.readKey("booking.get.putfirstname")).isNotEmpty().isNotNull();   
        
        
        
    }

    
    @Test(groups = "Integration", priority =4)
    @Owner("Kalpesh")
    @Description("TC=04 -Verify that booking can be created")
    public void testDeleteBookingByID(ITestContext iTestContext) {
    	String token = (String) iTestContext.getAttribute("token");
    
    	Integer bookingid = (Integer) iTestContext.getAttribute("bookingid");

        String deletePath = APIConstants.CREATE_UPDATE_BOOKING_URL + "/" + bookingid;
        System.out.println("DELETE URL: " + deletePath);

        response = RestAssured
            .given()
            .contentType(ContentType.JSON)
            .cookie("token", token)
            .basePath(deletePath)
            .when()
            .delete();

        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(201); // 201 means deleted in restful-booker 

   
  	  	   
  	  
 }
}  
    