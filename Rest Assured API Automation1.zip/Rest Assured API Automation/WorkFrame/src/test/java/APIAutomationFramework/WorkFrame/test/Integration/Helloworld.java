package APIAutomationFramework.WorkFrame.test.Integration;

public class Helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.print("Helloworld");	}

}
