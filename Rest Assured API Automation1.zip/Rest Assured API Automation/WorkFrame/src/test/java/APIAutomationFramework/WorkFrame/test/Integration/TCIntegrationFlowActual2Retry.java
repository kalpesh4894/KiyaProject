package APIAutomationFramework.WorkFrame.test.Integration;

import org.testng.annotations.Test;

import APIAutomationFramework.WorkFrame.Listeners.RetryAnalyzer;
import APIAutomationFramework.WorkFrame.base.BaseTest;

@Test(retryAnalyzer = RetryAnalyzer.class)
public class TCIntegrationFlowActual2Retry extends BaseTest {
	
	
	

	
	
	
}
