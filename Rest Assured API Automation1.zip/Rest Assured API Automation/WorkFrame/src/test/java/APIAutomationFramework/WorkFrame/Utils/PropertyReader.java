package APIAutomationFramework.WorkFrame.Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.hamcrest.Matcher;

public class PropertyReader {
//Responsibility of class is to give value by the key
	
	
	
	public static String readKey(String key)  {
		
		
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream("src//test//java//resources//data.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("read file data");
		//legacy 1, 2 jdk -old
		
		try {
//Read the properties file and give the key //			
	//FileInputStream  fileInputStream = new FileInputStream("src//test//java//resources//data.properties");
			
			}catch(Exception Ex){
			
			System.out.println(Ex.getMessage());
		}
		return properties.getProperty(key);
	}
	
}


//package APIAutomationFramework.WorkFrame.Utils;
//
//import java.io.InputStream;
//import java.util.Properties;
//
//public class PropertyReader {
//
//    private static final Properties properties = new Properties();
//
//    static {
//        try (InputStream input = PropertyReader.class.getClassLoader().getResourceAsStream("src/test/java/resources/data.properties")) {
//            if (input == null) {
//                throw new RuntimeException("Could not find data.properties in classpath");
//            }
//            properties.load(input);
//        } catch (Exception e) {
//            throw new RuntimeException("Failed to load data.properties: " + e.getMessage(), e);
//        }
//    }
//
//    // For String values
//    public static String readKey(String key) {
//        String value = properties.getProperty(key);
//        if (value == null) {
//            throw new RuntimeException("Key not found in data.properties: " + key);
//        }
//        return value;
//    }
//
//    // For int values
//    public static int readInt(String key) {
//        return Integer.parseInt(readKey(key));
//    }
//}