package APIAutomationFramework.WorkFrame.base;

import org.testng.annotations.BeforeTest;

import com.google.gson.Gson;

import APIAutomationFramework.WorkFrame.Actions.AssertActions;
import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.Modules.PayloadManager;
import APIAutomationFramework.WorkFrame.POJOS.TokenResponse;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

//Common to all test case
	//Base test father = testcase = son = single inheritance//
public class BaseTest {
  //TC- Header  common
	public RequestSpecification requestSpecification;
	public AssertActions assertActions;
    public PayloadManager payloadManager;
    public JsonPath jsonPath;
    public Response response;
    public ValidatableResponse validatableResponse;
    
    
		
	@BeforeTest
	public void setUp() { 
		
		payloadManager = new PayloadManager();
		assertActions = new AssertActions();
		requestSpecification = new RequestSpecBuilder()
				.setBaseUri(APIConstants.BASE_URL)
				.addHeader("content-Type", "application/json")
				.build().log().all();
		   
		     //OR - below can use any one of style//
		
		
//		requestSpecification = RestAssured
//				.given()
//				.baseUri(APIConstants.BASE_URL)
//				.contentType(ContentType.JSON)
//                .log().all();		
//		
		
		
		
		
	}
	
	
	
//	public String getToken() {
//		requestSpecification = RestAssured
//				               .given()
//				               .baseUri(APIConstants.BASE_URL)
//				               .basePath(APIConstants.AUTH_URL);
//		
//		//Setting the payload  //
//		String payload = payloadManager.setAuthPayload();
//		
//		//Get the token
//		
//		response = requestSpecification.contentType(ContentType.JSON).body(payload).when().post();
//		
//		//Token Extraction
//		
//		String token = payloadManager.getTokenFromJSON(response.asString());
//		
//	comment this 	return new Gson().fromJson(token, String.class);
//	    return token;
//	}
		
	
	 public String getToken() {
	        String payload = "{\n" +
	                "  \"username\": \"admin\",\n" +
	                "  \"password\": \"password123\"\n" +
	                "}";


	        Response response = RestAssured.given()
	                .contentType(ContentType.JSON)
	                .body(payload)
	                .post("/auth");

	        response.then().statusCode(200);
	        return response.jsonPath().getString("token");
	     
	    }
	
	 
	}
	
	
	
	
	

