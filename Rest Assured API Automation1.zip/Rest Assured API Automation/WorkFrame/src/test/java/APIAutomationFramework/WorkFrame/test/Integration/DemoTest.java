package APIAutomationFramework.WorkFrame.test.Integration;

import static org.assertj.core.api.Assertions.assertThat;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import APIAutomationFramework.WorkFrame.Endpoints.APIConstants;
import APIAutomationFramework.WorkFrame.Modules.PayloadManager;
import APIAutomationFramework.WorkFrame.POJOS.BookingResponse;
import APIAutomationFramework.WorkFrame.POJOS.TokenResponse;
import APIAutomationFramework.WorkFrame.Utils.PropertyReader;
import APIAutomationFramework.WorkFrame.base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;





public class DemoTest extends BaseTest{
    
  @Test(groups = "Integration", priority =1)
  @Owner("Kalpesh")
  @Description("TC=01 -Verify that booking can be created")
  public void testCreateBooking(ITestContext iTestContext) {
	  iTestContext.setAttribute("token", getToken());
	 
        requestSpecification
		.basePath(APIConstants.CREATE_UPDATE_BOOKING_URL); 
      	response = RestAssured
			.given(requestSpecification)
	  		.when().body(PayloadManager.createPayloadBookingAsString()).post();
		validatableResponse = response.then().log().all();
//		validatableResponse.statusCode(Integer.parseInt(PropertyReader.readKey("booking.post.statusCode.success")));
		validatableResponse.statusCode(200);
		//Default Rest Assured
//		validatableResponse.body("booking.firstname", Matchers.equalTo(PropertyReader.readKey("booking.post.firstname")));
		
		BookingResponse bookingResponse = payloadManager.bookingResponseJava(response.asString());
		//assertJ -> Make sure import of assertJ imported 
	
		assertThat(bookingResponse.getBooking()).isNotNull();
		assertThat(bookingResponse.getBooking().getFirstname()).isEqualTo(PropertyReader.readKey("booking.post.firstname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getLastname()).isEqualTo(PropertyReader.readKey("booking.post.lastname")).isNotEmpty().isNotNull();
		assertThat(bookingResponse.getBooking().getAdditionalneeds()).isEqualTo("Breakfast").isNotEmpty().isNotNull();
		
	  //set booking ID//
		iTestContext.setAttribute("bookingid", bookingResponse.getBookingid());
	  
  }
	
  private TokenResponse convertTokenStringToObject(String tokenJson) {
	// TODO Auto-generated method stub
	return null;
}
}
