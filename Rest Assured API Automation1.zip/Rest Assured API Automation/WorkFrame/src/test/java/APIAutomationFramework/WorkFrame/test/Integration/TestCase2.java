package APIAutomationFramework.WorkFrame.test.Integration;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import APIAutomationFramework.WorkFrame.Modules.PayloadManager;
import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

//Create a booking and verify it by boooking id and delet and verify by id // 

public class TestCase2 {
	 String token;
	    int bookingID;
	    int updatedbookingID;

	    @BeforeClass
	    public void setup() {
	        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
	        token = getToken();
	    }

	    public String getToken() {
	        String payload = "{\n" +
	                "  \"username\": \"admin\",\n" +
	                "  \"password\": \"password123\"\n" +
	                "}";


	        Response response = RestAssured.given()
	                .contentType(ContentType.JSON)
	                .body(payload)
	                .post("/auth");

	        response.then().log().all().statusCode(200);
	        String token = response.jsonPath().getString("token");

             System.out.println("Generated Token: " + token);   // ✅ PRINT HERE

             return token;

	    }

	    
	    
	    @Test(groups = "Integration", priority = 1)
	    @Owner("Kalpesh")
	    @Description("TC-Step 1 - Verify the booking can be created")
	  
	   	 public void createBookingPayload() {
	    	       
	    	    	String payload = PayloadManager.createPayloadBookingAsString(); 

	    	        Response response = RestAssured.given()
	    	                .contentType(ContentType.JSON)
	    	                .body(payload)
	    	                .post("/booking");

	    	        response.then().log().all().statusCode(200);

	    	        bookingID = response.jsonPath().getInt("bookingid");
	    	        System.out.println("Created Booking ID: " + bookingID);
	    	        Assert.assertTrue(bookingID > 0, "Booking ID should be greater than 0");
	    	       
	    }
	    
	    @Test(groups = "Integration", priority = 2)
	    @Owner("Kalpesh")
	    @Description("TC-Step 2 - Verify the booking by name")
	    public void testverifybookingbyid() {
	        Response response = RestAssured.given()
	                .get("/booking/" + bookingID);

	        response.then().log().all().statusCode(200);
	        assertEquals(response.jsonPath().getString("firstname"), "Sumit");
	        
	    }
	    
	    @Test(groups = "Integration", priority = 4)
	    @Owner("Kalpesh")
	    @Description("TC-Step 4 - Delete the booking by ID")
	    public void deletetebookingbyid() {
	        Response response = RestAssured.given()
	                .cookie("token", token)
	                .delete("/booking/" + bookingID);

	        response.then().log().all().statusCode(201);

	        // Confirm deletion
	        Response checkResponse = RestAssured.given().get("/booking/" + bookingID);
	        assertEquals(checkResponse.statusCode(), 404);
	    }
	
	
}
