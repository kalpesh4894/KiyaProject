package Ex_16072025;

import org.testng.annotations.Test;

import com.github.dockerjava.transport.DockerHttpClient.Response;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class PUTbyNONBDDHardcoded {
	//This is hardcoded as token and id we are passing manually
	RequestSpecification requestSpecification;
	ValidatableResponse validatableResponse;
	Response response;
	
	
	@Test
	
	public void test_PUT() {
		
		String token = "aea21aa10f59bd3";
		String  bookingid = "6989"; 
		String payloadPUT = "{\"firstname\" : \"Ahmad\", \"lastname\" : \"Brown\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : false, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Cookie Khanar\"}";
		
		requestSpecification = RestAssured.given();
	//	requestSpecification.baseUri("https://restful-booker.herokuapp.com/");
		requestSpecification.baseUri("https://restful-booker.herokuapp.com/booking/:id");
		requestSpecification.basePath("/booking/"+ bookingid);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.cookie("token", token);
		requestSpecification.body(payloadPUT).log().all();
		
		Response response = (Response) requestSpecification.when().put();
		validatableResponse =( ValidatableResponse) requestSpecification.then().log().all();
		validatableResponse.statusCode(200);
		
		
		
		
		
		
		
		
	}
	
	
	
	
	

}
