package Ex_16072025;


import org.testng.annotations.Test;
import io.restassured.RestAssured;
	import io.restassured.http.ContentType;
	import io.restassured.response.Response;
	import io.restassured.response.ValidatableResponse;
	import io.restassured.specification.RequestSpecification;

	public class PUTR {

	    // Fields for reuse if needed later
	    RequestSpecification requestSpecification;
	    ValidatableResponse validatableResponse;
	    Response response;

	    @Test
	    public void test_PUT() {

	        String token = "aea21aa10f59bd3";
	        String bookingid = "6111";
	        
	        String payloadPUT = "{\n" +
	                "  \"firstname\" : \"Rashid\",\n" +
	                "  \"lastname\" : \"Brown\",\n" +
	                "  \"totalprice\" : 111,\n" +
	                "  \"depositpaid\" : false,\n" +
	                "  \"bookingdates\" : {\n" +
	                "    \"checkin\" : \"2018-01-01\",\n" +
	                "    \"checkout\" : \"2019-01-01\"\n" +
	                "  },\n" +
	                "  \"additionalneeds\" : \"Cookie Khanar\"\n" +
	                "}";

	        requestSpecification = RestAssured.given();
	        requestSpecification.baseUri("https://restful-booker.herokuapp.com");
	        requestSpecification.basePath("/booking/" + bookingid);
	        requestSpecification.contentType(ContentType.JSON);
	        requestSpecification.cookie("token", token);
	        requestSpecification.body(payloadPUT).log().all();

	        response = requestSpecification.when().put(); // assign to class field
	        validatableResponse = response.then().log().all(); // validate from response
	        validatableResponse.statusCode(200);
	    }
	}


