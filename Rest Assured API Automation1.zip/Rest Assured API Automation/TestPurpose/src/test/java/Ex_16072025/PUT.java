package Ex_16072025;

public class PUT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
