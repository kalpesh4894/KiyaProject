package Ex_16072025;

import org.testng.annotations.Test;

import com.github.dockerjava.transport.DockerHttpClient.Response;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class PUTbyNONBDDstyle {

	RequestSpecification requestSpecification;
	ValidatableResponse validatableResponse;
	Response response;
	
		//bookinfg created 
		//Token needed
		//Payload needed - {
	//    "firstname" : "James",
	//    "lastname" : "Brown",
	 //   "totalprice" : 111,
	 //   "depositpaid" : true,
	 //   "bookingdates" : {
	 //       "checkin" : "2018-01-01",
	 //       "checkout" : "2019-01-01"
	  //  },
	 //  "additionalneeds" : "Breakfast"
  //	  } 
		
		
		//To make put requu , we need to make post req first
		 //which will give us a token
		//Put - depends on token and booking id 
	
//	public void get_token() {
		
			
//		}
	
//	public void get_booking() {
			
//	}
	
	
			@Test
		public void test_full_put_positive_tc() {
			//Post Auth tooken
 		String payload = "{\"firstname\" : \"James\", \"lastname\" : \"Brown\", "
					+ "      \"totalprice\" : 111, \"depositpaid\" : true, "
					+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
					+ "\"2019-01-01\"}, \"additionalneeds\" : \"Breakfast\"}";
		
		
	requestSpecification = RestAssured.given();
	requestSpecification.baseUri("https://restful-booker.herokuapp.com/");
	requestSpecification.basePath("");
	requestSpecification.contentType(ContentType.JSON);
		
		
		
		
		
		
		
		
		}		

	}


