package Ex_16072025;

import io.restassured.RestAssured;

public class GET {

	public static void main(String[] args) {

//BDD - framework diff syntax (given when then)
// Non BDD - Still uses gherkin syntax but with classes
		//Given
		//URL
		//Header ? Cookies
		//Base url - https://api.zippopotam.us/IN/425001
		//basepath
		//Auth - Basicc , digest , jwt ,bearer token, , OAuth 2.0 ? = No
		
		
		//When ->
		//payload -> No/yes -> json , xml -> string , hashmap, object class
		//Get method
		
		//Then ()
		//Response validation
		//Status code
		//Response body
		//Time,  headers , cookies
		
		RestAssured
		.given()
		        .baseUri("https://api.zippopotam.us")
		        .basePath("/IN/425001")
		 .when()
		        .log().all().get()
		  .then()
		        .log().all().statusCode(200);
		
		
		
	}

}
