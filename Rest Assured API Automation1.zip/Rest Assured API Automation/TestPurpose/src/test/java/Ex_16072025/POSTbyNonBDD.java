package Ex_16072025;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import io.restassured.response.Response;
public class POSTbyNonBDD {

	public static void main(String[] args) {
		
		String payload = "{\n" +
                "  \"username\": \"admin\",\n" +
                "  \"password\": \"password123\"\n" +
                "}";
		
		// Given request specificatiion
		RequestSpecification r = RestAssured.given();
		
		r.baseUri("https://restful-booker.herokuapp.com");     //All this is making of request
		r.basePath("/auth");
		r.contentType(ContentType.JSON).log().all();
		r.body(payload).when().post().then().log().all().statusCode(200);
     
		  //When response
   	 Response response =  r.when().post();
		
		//validation
		//Then validate response
   	 ValidatableResponse validatableResponse = response.then();  //This is verification of request
		validatableResponse.statusCode(200);
		
		
	
			
	}

}
