package Ex_16072025;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class GET_by_NONBDD {
	static RequestSpecification r = RestAssured.given();
	public static void main(String[] args) {
		//Rest assured provides lots of classes
		//Non BDD provides more scalability and eaasy to use structure than BDD styles so its mostly used 90% of the cases
	//Use if facing HTTPS related issue  ->	r.relaxedHTTPSValidation("TLS");
		r.baseUri("https://api.zippopotam.us");
		testcase1NonBDD();
        testcase2NonBDD();
  
	}   
	//Reusablility of code is the advatnage of non bdd
	//Make r static if gives error 
	
		private static void testcase2NonBDD() {
		
		r.basePath("/IN/422008");
		r.when().get();
		r.then().log().all().statusCode(200);
		
	}
	private static void testcase1NonBDD() {
		
		r.basePath("/IN/422003");
		r.when().get();
		r.then().log().all().statusCode(404);
		
	}
	
}
