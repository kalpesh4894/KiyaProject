package Ex_16072025;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class POST {

	public static void main(String[] args) {
		//Payload can be given in hashmaps(4%), string(1%)  or classes form (95%).
		String payload = "{\n" +
                "  \"username\": \"admin\",\n" +
                "  \"password\": \"password123\"\n" +
                "}";
		
		RestAssured
		.given()
		.baseUri("https://restful-booker.herokuapp.com")
		.basePath("/auth")
		.contentType(ContentType.JSON).log()
		.all().body(payload).when()
		.post().then().log()
		.all().statusCode(200);
		
		
		   
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
