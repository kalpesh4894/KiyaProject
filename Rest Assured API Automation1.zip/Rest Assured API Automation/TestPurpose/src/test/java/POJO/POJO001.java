package POJO;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.Test;

public class POJO001 {
	//string payload we have used earlier //
	
	//Hashmap -> 
	//{} -> map 
	//string payload(2%), hashmaps(4%) and class structure is widely used//
	//	Classes are mostly used not hasmaps//here is eg of hashmap //
	 @Test
	 void test_using_hashmap(){
	
	Map<String , Object> jsonBodyUsingMap = new LinkedHashMap<>();
    jsonBodyUsingMap.put("firstname", "jack");
    jsonBodyUsingMap.put("lastname", "disouza");
    jsonBodyUsingMap.put("totalprice", 111);
    jsonBodyUsingMap.put("depositpaid", true);
	
    Map<String , Object> BookingdatesMap = new LinkedHashMap<>();
    BookingdatesMap.put("checkin","2025-24-07");
    BookingdatesMap.put("check out","2025-30-12");
    
    jsonBodyUsingMap.put("bookingdates","BookingdatesMap");
    jsonBodyUsingMap.put("additionalneeds", "breakfast");
    
    System.out.println(jsonBodyUsingMap);
    
	
	

	
	
	 }	
	
	

}
