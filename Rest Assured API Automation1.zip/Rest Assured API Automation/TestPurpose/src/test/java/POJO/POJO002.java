package POJO;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;


  
public class POJO002 {
	@Test
	  void test_hashmap(){
	//Why we move from string to maps and maps to Class
	//The variable dynamic values becomes easier to handle so we moved 	
	Map<String , Object> jsonBodyUsingMap = new LinkedHashMap<>();
    jsonBodyUsingMap.put("firstname", "jack");
    jsonBodyUsingMap.put("lastname", "disouza");
    jsonBodyUsingMap.put("totalprice", 111);
    jsonBodyUsingMap.put("depositpaid", true);
	
    Map<String , Object> BookingdatesMap = new LinkedHashMap<>();
    BookingdatesMap.put("checkin","2025-24-07");
    BookingdatesMap.put("check out","2025-30-12");
    
    jsonBodyUsingMap.put("bookingdates","BookingdatesMap");
    jsonBodyUsingMap.put("additionalneeds", "breakfast");
    
    System.out.println(jsonBodyUsingMap);
	
	
	RequestSpecification requestSpecification = RestAssured.given();
	requestSpecification.baseUri("https://restful-booker.herokuapp.com/");
	requestSpecification.contentType(ContentType.JSON);
	requestSpecification.body(jsonBodyUsingMap).log().all();
	
	
	Response response = requestSpecification.when().put();
	ValidatableResponse validatableResponse = response.then().log().all();
	validatableResponse.statusCode(404);
	
}
}