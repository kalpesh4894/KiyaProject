package Assertions;

import org.testng.annotations.Test;

import io.qameta.allure.Description;

import static org.assertj.core.api.Assertions.*;

import java.util.List;
import java.util.Map;
import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;


public class Test003 {
	@Description("Verify that assertJ is working fine.")  //allurereport.org site //
	@Test
	
	public void test_verify_assertJ() {
		
		String name = "Shriram";
		assertThat(name).isEqualTo("Shriram").isNotEmpty().isNotNull();
		
		List <String> names =Arrays.asList("John","Doe","Jessica");
		assertThat(names).hasSize(3).isNotNull();
		
		LocalDate date = LocalDate.now();
		System.out.println("Todays date is -> " + date); 
		
		
		
		Map<String, Integer >ages = new HashMap<>();
		ages.put("Ola" , 35);
		ages.put("Bubzee", 28);
		assertThat(ages).hasSize(2).containsEntry("Ola",35).doesNotContainValue(40);
			
		
		
	}	
      @Test		
		
      public void file_test() {
		
		//To verify that file present exists and can read //
		
		File file = new File("testdata.json");
		assertThat(file).exists().canRead();
		
	}
	
	   
      	

}
