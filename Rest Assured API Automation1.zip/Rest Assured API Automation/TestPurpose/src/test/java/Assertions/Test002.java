package Assertions;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static org.assertj.core.api.Assertions.*;

public class Test002 {
	
	// Verification of response using assertJ -> best way  //
	
	RequestSpecification requestSpecification;
	ValidatableResponse validatableResponse;
	Response response;
	String token;
	String bookingid;
	
	@Test
	public void test_post1(){
		String payloadPOST = "{\"firstname\" : \"Kaadar\", \"lastname\" : \"Khan\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : true, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Breakfast\"}";
	
	
		requestSpecification = RestAssured.given();
        requestSpecification.baseUri("https://restful-booker.herokuapp.com/"); 
        requestSpecification.basePath("/booking/");
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.body(payloadPOST).log().all();
        
        Response response = requestSpecification.when().post();

        // Get validatable response to perform validation 
        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(200);
        
      
        
        int bookingid = response.then().extract().path("bookingid");
    //    Assert.assertNotNull(bookingID);
        
        String firstname = response.then().extract().path("booking.firstname");
        String lastname = response.then().extract().path("booking.lastname");
        boolean depositpaid = response.jsonPath().getBoolean("booking.depositpaid");
        int totalprice = response.then().extract().path("booking.totalprice");

        //   Response validation using AssertJ //     
        assertThat(bookingid).isNotNull();
        assertThat(firstname).isEqualTo("Kaadar").isNotEmpty().isNotBlank();
        assertThat(lastname).isEqualTo("Khan").isNotEmpty().isNotBlank();
        assertThat(depositpaid).isTrue();
        assertThat(totalprice).isEqualTo(111).isNotNegative();
        
       
         
        
 	}
	
	
}