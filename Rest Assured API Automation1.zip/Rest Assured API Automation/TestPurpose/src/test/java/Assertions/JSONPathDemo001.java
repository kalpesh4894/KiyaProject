package Assertions;

import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static org.assertj.core.api.Assertions.*;

public class JSONPathDemo001 {
	
	RequestSpecification requestSpecification;
	ValidatableResponse validatableResponse;
	Response response;
	String token;
	String bookingID;
	
	@Test
	public void test_post(){
		String payloadPOST = "{\"firstname\" : \"James\", \"lastname\" : \"Brown\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : true, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Breakfast\"}";
	
	
		requestSpecification = RestAssured.given();
        requestSpecification.baseUri("https://restful-booker.herokuapp.com/"); 
        requestSpecification.basePath("/booking/");
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.body(payloadPOST).log().all();
        
        Response response = requestSpecification.when().post();

        // Get validatable response to perform validation 
        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(200);
        
        //GExtraction using JSONPath //
        
        System.out.println(response.asString());
        JsonPath jsonPath = new JsonPath(response.asString());
        String bookingid =jsonPath.getString("bookingid");
        String firstname = jsonPath.getString("booking.firstname");
        String checkout = jsonPath.getString("booking.boookingdates.checkout");
        System.out.println(bookingid);
        System.out.println(firstname);
        System.out.println(checkout);
        
     assertThat(bookingid).isNotNull().isNotBlank().isEqualTo("James").isGreaterThan("0");
     assertThat(firstname).isNotNull().isNotBlank().isEqualTo("James");
     assertThat(checkout).isNotNull().isNotBlank();
     
	//here can also test with testNG assertions //
	
	
	
		
}}