package Assertions;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static org.assertj.core.api.Assertions.*;

public class Test001 {
	
	//Verify status code
	//Validate bookingID  > 0
	//id =! null
	//Firstname , last name should match with expected result
	//Response time
	//Verify headers 
	
	RequestSpecification requestSpecification;
	ValidatableResponse validatableResponse;
	Response response;
	String token;
	String bookingID;
	
	@Test
	public void test_post(){
		String payloadPOST = "{\"firstname\" : \"James\", \"lastname\" : \"Brown\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : true, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Breakfast\"}";
	
	
		requestSpecification = RestAssured.given();
        requestSpecification.baseUri("https://restful-booker.herokuapp.com/"); 
        requestSpecification.basePath("/booking/");
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.body(payloadPOST).log().all();
        
        Response response = requestSpecification.when().post();

        // Get validatable response to perform validation 
        validatableResponse = response.then().log().all();
        validatableResponse.statusCode(200);
        
        //There are 3 4 types to validation expected = Actual as follow //
	    // RestAssured default - Hemcrast 
        //import org.hamcrest.Matchers;
        //But these are boring and not advanced 
        validatableResponse.body("booking.firstname",Matchers.equalTo("James"));
        validatableResponse.body("booking.lastname",Matchers.equalTo("Brown"));
        validatableResponse.body("booking.depositpaid",Matchers.equalTo(true));
        
        //TestNG Assertions
        
        //Hard Assertions will stop the further execution of code 
        //But soft assertions doesn't stops the execution of the code
        
        bookingID = response.then().extract().path("bookingID");
        Assert.assertNotNull(bookingID);
        
        String firstname = response.then().extract().path("booking.firstname");
       Assert.assertEquals(firstname, "James");
    //Upper ways of hard assert is also boring  //
        
        
      
        //AssertJ -> Best library 
        
        assertThat(bookingID).isNotNull().isNotNull();
        assertThat(firstname).isEqualTo("James").isNotEmpty().isNotBlank();
       
        
        
        
        
        
        
        
        
          
		
	}
	
	
}
