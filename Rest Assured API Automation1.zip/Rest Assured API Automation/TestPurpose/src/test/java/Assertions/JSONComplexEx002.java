package Assertions;
import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;

import static org.assertj.core.api.Assertions.*;

import org.assertj.core.api.Assert;

public class JSONComplexEx002 {
	@Test
	
	void Test(){
		
	
		String response = "{"
			    + "\"firstname\": \"John\","
			    + "\"lastname\": \"Doe\","
			    + "\"age\": \"26\","
			    + "\"address\": {"
			    +     "\"Street address\": \"Moist street\","
			    +     "\"City\": \"Morocco\","
			    +     "\"PostCode\": \"725736\""
			    + "},"
			    + "\"PhoneNumbers\": ["
			    +     "{"
			    +         "\"Type\": \"Work\","
			    +         "\"Number\": \"2635237732\""
			    +     "},"
			    +     "{"
			    +         "\"Type\": \"Home\","
			    +         "\"Number\": \"8347658732\""
			    +     "}"
			    + "]"
			+ "}";
		
		
		
		
		
		
		
		
		
	JsonPath jsonPath = JsonPath.from(response);
	
	System.out.println(jsonPath.getString("firstname")); 
	System.out.println(jsonPath.getString("PhoneNumbers[1].type")); //Here path comes from jsonpathfinder site directly// 
	System.out.println(jsonPath.getString("address['Street address']")); 
	
	assertThat(jsonPath.getString("firstname")).isNotNull().isNotEmpty().isEqualTo("John");
	assertThat(jsonPath.getString("PhoneNumbers[1].Number")).isNotNull().isNotEmpty().isEqualTo("8347658732");
	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
