package TestNG;

import org.testng.annotations.Test;

import groovyjarjarantlr4.v4.runtime.Dependents;

public class TestNG_007 {
	
	@Test
	public void serverstartedok() {
		System.out.println("I will run first");
	}
	
	
	@Test(dependsOnMethods = "serverstartedok")
	public void method1() {
		
	System.out.println("Method 1 will run");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
