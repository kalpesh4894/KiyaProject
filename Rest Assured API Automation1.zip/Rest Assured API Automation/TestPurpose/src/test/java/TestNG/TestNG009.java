package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNG009 {
	@Test
	
	public void test1() {
		Assert.assertTrue(false);
	}
	

	@Test(enabled = false)
	
	public void test2() {
		Assert.assertTrue(false);
	}
   
	
	@Test(alwaysRun = true)

   public void test3() {
	Assert.assertTrue(true);
   }
	
	
}
