package TestNG;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Test002 {
	
	//Test Execution heirarchy //

	@BeforeSuite
	
	void demo1()
	
	{
		System.out.println("Read the date from MySQL");
	}
		
	
	@BeforeTest
	void demo2()
	{
		System.out.println("Read the data from Matrix , Tcase");
	}
	

	@BeforeClass
	void demo3()
	{
		System.out.println("This will execute before class");
	}
		
  @BeforeMethod	
	
	void demo4()
	{
		System.out.println("This will execute before Method");
	}
		
  
		@Test
		
	void demo5() {
			System.out.println("This will execute now");
		}	
		
		@AfterMethod
		void demo6() {
			System.out.println("This will execute after method");
		}
		
		
	@AfterClass
	void  demo7() {
		System.out.println("This will execute after class");
	}
		
	@AfterTest
	void demo8() {
		System.out.println("This will execute after test");
	}
		@AfterSuite
		void demo9(){
		System.out.print("This will execute after suite");
		System.out.print("Close everything ,delete all the temp files");
		}
		
		
	}


