package TestNG;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//Just an example of testcases will be 
public class Test004 {
	
	String token;
	int bookingid;
	
	
	@BeforeTest
	public String gettoken() {
		token = "123";
		return token;
	}
	
	@BeforeTest
	
	public void getTokenAndBooking() {
		//post req
		//post code
		bookingid = 12345454;
	}
	
	@Test
	
	public void TestPUTRequest() {
		
		System.out.println(token);
		System.out.println(bookingid);
	}

	
	@Test
	public void TestPUTRequest2() {
		
		System.out.println(token);
		System.out.println(bookingid);
	}

	@Test
public void TestPUTRequest3() {
	
	System.out.println(token);
	System.out.println(bookingid);
}
	
	
}
