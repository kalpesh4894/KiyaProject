package TestNG;

import org.testng.annotations.Test;

public class Test005 {

@Test(priority = 2)
	
	public void Test1() {
		
		System.out.println("token");
		
	}

@Test(priority = 1)

public void Test2() {
	
	System.out.println("token");
}


@Test(priority = 3)

public void Test3() {
	
	System.out.println("token");
}
	
	
	
	
	
	
	
	
}
