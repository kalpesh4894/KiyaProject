package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNG_groups006 {
	@Test(groups = {"Sanity","QA"})
	public void SanityRun() {
		
	System.out.println("This is sanity Run");
	System.out.println("This is QA Run");
	}
	
	@Test(groups = {"QA"})
	public void RegressionRun() {
		
	System.out.println("This is QA Run");
	Assert.assertEquals(true, true);	
	}
	
	
	@Test(groups = {"Dev"})
	public void SmokeRun() {
		
	System.out.println("This is Smoke Run");
	Assert.assertTrue(false);
	}
	
	
}
