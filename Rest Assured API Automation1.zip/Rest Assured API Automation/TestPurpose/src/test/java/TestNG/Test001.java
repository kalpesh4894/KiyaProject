package TestNG;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Test001 {

	
 @Test
  
 public void get_test() {
	 RestAssured
	 .given()
	         .baseUri("https://api.zippopotam.us")
	         .basePath("/IN/425008")
	  .when()
	         .log().all().get()
	   .then()
	         .log().all().statusCode(200);



	 	}
 }






