package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;

public class Test003 {

	@Description("Verify that true == true")
	@Severity(SeverityLevel.NORMAL)
	@Test
	public void testcase01() {
		
		Assert.assertEquals(true, true);
		
	}
	
	@Description("Verify that true!= false")
	@Severity(SeverityLevel.BLOCKER)
	@Test
	public void testcase02() {
		
		Assert.assertEquals( true, false);
		
	}
	
}
