package TestNG;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class TestNG008 {

	@Parameters("browser")
	@Test
	void demo(String value) {
		System.out.print("Browser is ->" + value);
		
		//Open the browser and select the data 
	}
	
	//Rename pom, add <parameter> into xml and pas value chrome/firefox //	
	
}
