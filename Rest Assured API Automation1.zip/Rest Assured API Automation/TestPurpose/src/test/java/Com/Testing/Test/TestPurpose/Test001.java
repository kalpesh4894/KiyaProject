package Com.Testing.Test.TestPurpose;

import io.restassured.RestAssured;

public class Test001 {

	public static void main(String[] args) {
	
		
		
	System.out.println("Rest Assured Test Case");	
	System.out.println("Get Request Demo");
	
	//Gherkin Syntax 
	//given() - url, headers, body or payload
	//when() - http methods - get post , put , delete
	//then() - verify the response  -er == ar
	
	RestAssured
	.given()
	      .baseUri("https://restful-booker.herokuapp.com")
          .basePath("/booking/1")
           
	.when()
	       .get()
	 .then().log().all()       //log().all()  - if to see all data 
	       .statusCode(200);   //Check with 201 if want to see error
	
		
		
	
	}

}
