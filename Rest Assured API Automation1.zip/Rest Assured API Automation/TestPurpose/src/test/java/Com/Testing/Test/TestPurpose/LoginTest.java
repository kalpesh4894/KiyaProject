package Com.Testing.Test.TestPurpose;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {

	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		
		WebDriver driver =  new EdgeDriver();  // create the object of the edge driver
		driver.get("https://www.google.com");

	}

}
