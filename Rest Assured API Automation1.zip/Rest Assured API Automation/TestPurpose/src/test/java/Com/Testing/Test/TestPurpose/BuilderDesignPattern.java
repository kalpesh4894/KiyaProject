package Com.Testing.Test.TestPurpose;

public class BuilderDesignPattern {

//Change return type of each method as class type
//'this' always pointsto current/ calling objects
//Returning the same to have same reference 
	
		public BuilderDesignPattern step1() {
			System.out.println("Stage 1 is done");
			return this;
		}
		public BuilderDesignPattern step2(String param) {
			System.out.println("Stage 2 is done");
			return this;
		}
		public BuilderDesignPattern step3() {
			System.out.println("Stage 3 is done");
			return this;
		}

		public static void main(String[] args) {
			
			BuilderDesignPattern BP = new BuilderDesignPattern();
			
			BP.step1().step2("Kalpesh").step3();
			
		//Its just like cement is given from 1st flover to 2nd flover and then 3rd flover as they are dependant
			
			
		}


	}


