package Com.Testing.Test.TestPurpose;

public class NoDesignPattern {
	//This is nodesignpattern as as classes are not dependant on each other //
	public void step1() {
		System.out.println("Stage 1");
	}
	public void step2() {
		System.out.println("Stage 2");
	}
	public void step3(String param) {
		System.out.println("Stage 3");
	}

	public static void main(String[] args) {
		
		NoDesignPattern NP = new NoDesignPattern();
		NP.step1();
		NP.step2();
		NP.step3("Kalpesh");
		
		
	}

}
