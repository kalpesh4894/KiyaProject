package POJO_GSONSerialization;

import org.testng.annotations.Test;

import com.google.gson.Gson;

import io.qameta.allure.Description;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Gson_Serialization {
	
	RequestSpecification r =RestAssured
			.given();
	Response response;
	ValidatableResponse validatableResponse;
	
	
	
	
	@Description("TC#1 - Verify that create booking is working with valid payload")
	@Test

public void testNONBDDstylePOSITIVE() {
		
		Booking booking = new Booking();
		booking.setFirstname("Rohan");
		booking.setLastname("Brown");
		booking.setTotalprice(123);
		booking.setDepositpaid(true);
		
		BookingDates Bookingdates = new BookingDates();
		Bookingdates.setCheckin("2025-07-08");
		Bookingdates.setCheckout("2025-12-12");
		booking.setBookingdates(Bookingdates); 
		booking.setAdditionalneeds("Breakfast");
		
		System.out.println(booking);
		//convert object to JSON string to show proper response
		Gson gson = new Gson();
		String jsonStringPayload = gson.toJson(booking);
		System.out.println(jsonStringPayload);
		
		
		
		
		
		String BASE_URL = "https://restful-booker.herokuapp.com";
		String BASE_PATH = "/booking";
		r.baseUri(BASE_URL);
		r.basePath(BASE_PATH);
		r.contentType(ContentType.JSON).log().all();
		r.body(jsonStringPayload);
     
		 
	   response = r.when().log().all().post();
	   String responseString = response.asString();
	   System.out.println(responseString);
	
   	 ValidatableResponse validatableResponse = response.then(); 
		validatableResponse.statusCode(200);
		
		
			
	
	
}	
	
}
