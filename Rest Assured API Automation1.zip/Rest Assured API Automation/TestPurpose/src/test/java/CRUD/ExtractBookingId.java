

package CRUD;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

	public class ExtractBookingId {

	    RequestSpecification requestSpecification;
	    String token;
	    String bookingID;
	    
	    
	    public void getToken() {
      String payload = "{\n" +
                       "  \"username\": \"admin\",\n" +
                       "  \"password\": \"password123\"\n" +
                       "}";

      // Build the request
      RequestSpecification request = RestAssured.given()
          .baseUri("https://restful-booker.herokuapp.com")
          .basePath("/auth")
          .contentType(ContentType.JSON)
          .log().all()
          .body(payload);

      // Send POST request and get response
      Response response = request.when().post();

      // Validate status code 200
      response.then().statusCode(200);

      // Extract token from response JSON
      token = response.jsonPath().getString("token");

      System.out.println("Token obtained: " + token);
  }

	    public String getBookingID() {
	        String payloadPUT = "{\n" +
	                "  \"firstname\": \"Jim\",\n" +
	                "  \"lastname\": \"Brown\",\n" +
	                "  \"totalprice\": 111,\n" +
	                "  \"depositpaid\": true,\n" +
	                "  \"bookingdates\": {\n" +
	                "    \"checkin\": \"2018-01-01\",\n" +
	                "    \"checkout\": \"2019-01-01\"\n" +
	                "  },\n" +
	                "  \"additionalneeds\": \"Breakfast\"\n" +
	                "}";

	        requestSpecification = RestAssured.given()
	                .baseUri("https://restful-booker.herokuapp.com/")
	                .basePath("/booking")
	                .contentType(ContentType.JSON)
	                .body(payloadPUT)
	                .log().all();

	        Response response = requestSpecification.post();

	        response.then().statusCode(200);

	        // Fix key name
	        bookingID = response.jsonPath().getString("bookingid");
	        System.out.println("Created booking ID: " + bookingID);
	        return bookingID;
	    }
	    
	    
	    @Test
	    
	    public void test_extracted_bookingId() {
	    	
	    	getBookingID();
	    	
	    	
	    System.out.println("Extracted booking Id is : " + bookingID);	
	    	
	    	
	    	
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	}
