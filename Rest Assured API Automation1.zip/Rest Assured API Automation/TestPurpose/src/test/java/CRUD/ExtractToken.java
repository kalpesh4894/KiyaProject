package CRUD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class ExtractToken {
	
	public class ExtractBookingId {

	    RequestSpecification requestSpecification;
	    String token;
	    String bookingID;
	    
	    
	    public void getToken() {
      String payload = "{\n" +
                       "  \"username\": \"admin\",\n" +
                       "  \"password\": \"password123\"\n" +
                       "}";

      // Build the request
      RequestSpecification request = RestAssured.given()
          .baseUri("https://restful-booker.herokuapp.com")
          .basePath("/auth")
          .contentType(ContentType.JSON)
          .log().all()
          .body(payload);

      // Send POST request and get response
      Response response = request.when().post();

      // Validate status code 200
      response.then().statusCode(200);

      // Extract token from response JSON
      token = response.jsonPath().getString("token");

      System.out.println("Token obtained: " + token);
 
}
	
	
	    
	    
	    @Test(groups = "Integration", priority = 1)
	    @Owner("Kalpesh")
	    @Description("TC-Step 1 - Verify the token is getting generated")
	    public void VerifyExtractedToken() {
	        // Call the method to set bookingID
	    	  getToken();

	        // Now bookingID is set
	        System.out.println("Extracted Token from the test: " + token);

	    }
	    
	    
	    
	    
	  
	       
	}}
