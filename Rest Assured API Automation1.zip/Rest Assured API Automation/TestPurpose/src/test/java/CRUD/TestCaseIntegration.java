package CRUD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Owner;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

   //Create a token and booking id and extract them
   //Create and verify the booking id 
   //Update booking and verify it by id
   //Delete booking id
   //Verify the deleted booking id by id 


	public class TestCaseIntegration {

	    RequestSpecification requestSpecification;
	    String token;
	    String bookingID;
	    
	    
	    public void getToken() {
      String payload = "{\n" +
                       "  \"username\": \"admin\",\n" +
                       "  \"password\": \"password123\"\n" +
                       "}";

      // Build the request
      RequestSpecification request = RestAssured.given()
          .baseUri("https://restful-booker.herokuapp.com")
          .basePath("/auth")
          .contentType(ContentType.JSON)
          .log().all()
          .body(payload);

      // Send POST request and get response
      Response response = request.when().post();

      // Validate status code 200
      response.then().statusCode(200);

      // Extract token from response JSON
      token = response.jsonPath().getString("token");

      System.out.println("Token obtained: " + token);
  }

	    public String getBookingID() {
	        String payloadPUT = "{\n" +
	                "  \"firstname\": \"Jim\",\n" +
	                "  \"lastname\": \"Brown\",\n" +
	                "  \"totalprice\": 111,\n" +
	                "  \"depositpaid\": true,\n" +
	                "  \"bookingdates\": {\n" +
	                "    \"checkin\": \"2018-01-01\",\n" +
	                "    \"checkout\": \"2019-01-01\"\n" +
	                "  },\n" +
	                "  \"additionalneeds\": \"Breakfast\"\n" +
	                "}";

	        requestSpecification = RestAssured.given()
	                .baseUri("https://restful-booker.herokuapp.com/")
	                .basePath("/booking")
	                .contentType(ContentType.JSON)
	                .body(payloadPUT)
	                .log().all();

	        Response response = requestSpecification.post();

	        response.then().statusCode(200);

	        // Fix key name
	        bookingID = response.jsonPath().getString("bookingid");
	        System.out.println("Created booking ID: " + bookingID);
	        return bookingID;
	    }

	
	    
	    
	    
	    
	    @Test(groups = "Integration", priority = 1)
	    @Owner("Kalpesh")
	    @Description("TC-Step 1 - Verify the booking can be created")
	    public void VerifyExtractedBookingById() {
	        // Call the method to set bookingID
	    	  getBookingID();

	        // Now bookingID is set
	      
	    	  if (bookingID == null) {
	    	        System.out.println("TestCase is Failing as Booking Id is fetching as Null");
	    	  }else {
	    		  bookingID = getBookingID();
	    		  System.out.println("Booking ID from test: " + bookingID);
	    	  }
	    	  
	    	  
	    	  
	    	

	 //       Assert.assertNotNull(bookingID, "Booking ID should not be null");
	    }

	
	    @Test(groups = "Integration", priority = 2)  //Or can also sequence in pom.xml //
	  		public void test_update_request_put() {
	  	    	
	    	
	    	if (token == null) getToken();
	        if (bookingID == null) getBookingID();
	    	
	    	
	  	    	String payloadPUT = "{\"firstname\" : \"Mayur\", \"lastname\" : \"Brown\", "
	  					+ "      \"totalprice\" : 111, \"depositpaid\" : false, "
	  					+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
	  					+ "\"2019-01-01\"}, \"additionalneeds\" : \"Lunch\"}";
	  			
	  			requestSpecification = RestAssured.given();
	  			requestSpecification.baseUri("https://restful-booker.herokuapp.com/");
	  			requestSpecification.basePath("/booking/"+ bookingID);
	  			requestSpecification.contentType(ContentType.JSON);
	  			requestSpecification.cookie("token", token);
	  			requestSpecification.body(payloadPUT).log().all();
	  			
	  			
	    		Response response = requestSpecification.when().put();
	  			ValidatableResponse validatableResponse = response.then().log().all();  
	  			validatableResponse.statusCode(200);	
	    		 getBookingID();
	  	
	    		 if (bookingID == getBookingID()) {
		    	        System.out.println("TestCase is Failing as BookingId is not getting updated");
		    	  }else {
		    		 
		    		  System.out.println("TestCase passed as bookingId is updated");
		    	  }
		    	  
	    		 System.out.println("Updated Booking Id from test is : " + bookingID);
	    		 Assert.assertEquals(response.jsonPath().getString("firstname"), "Mayur");
	    		    Assert.assertEquals(response.jsonPath().getString("lastname"), "Brown");
	    		    Assert.assertEquals((int)response.jsonPath().getInt("totalprice"), 111);
	  			
	  			
	  	   }

	
	    
	    @Test(groups = "Integration", priority = 3)
	    public void test_delete_booking() {
	        // Ensure token and bookingID are set before proceeding
	        if (token == null) getToken();
	        if (bookingID == null) getBookingID();

	        // Step 1: Delete the booking using the bookingID
	        Response deleteResponse = RestAssured.given()
	        	.baseUri("https://restful-booker.herokuapp.com")
	            .basePath("/booking/" + bookingID)
	            .cookie("token", token)
	            .when()
	            .delete();

	        // Validate status code 201, which means the deletion was successful
	        deleteResponse.then().log().all().statusCode(201);
	        System.out.println("Booking ID " + bookingID + " deleted successfully.");
	    }
	    
	    
	    
	    @Test(groups = "Integration", priority = 4)
		public void test_delete_get() {
	    	
	    	  // Step : Verify the booking was deleted by sending a GET request
	        Response verifyResponse = RestAssured.given()
	            .baseUri("https://restful-booker.herokuapp.com")
	            .basePath("/booking/" + bookingID)
	            .when()
	            .get();

	        // Validate status code 404, which means the booking is no longer available
	        verifyResponse.then().log().all().statusCode(404);
	        System.out.println("Booking ID " + bookingID + " confirmed deleted (status 404).");
	    }
	    }
			

