package CRUD;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Demo {
	RequestSpecification requestSpecification;
    String token;
    String bookingID;
    
   
    public void getToken() {
        String payload = "{\n" +
                         "  \"username\": \"admin\",\n" +
                         "  \"password\": \"password123\"\n" +
                         "}";

        // Build the request
        RequestSpecification request = RestAssured.given()
            .baseUri("https://restful-booker.herokuapp.com")
            .basePath("/auth")
            .contentType(ContentType.JSON)
            .log().all()
            .body(payload);

        // Send POST request and get response
        Response response = request.when().post();

        // Validate status code 200
        response.then().statusCode(200);

        // Extract token from response JSON
        token = response.jsonPath().getString("token");

        System.out.println("Token obtained: " + token);
    }

   
	public String getBookingID() {
		String payloadPUT = "{\"firstname\" : \"James\", \"lastname\" : \"Brown\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : true, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Breakfast\"}";
	
	
		requestSpecification = RestAssured.given();
        requestSpecification.baseUri("https://restful-booker.herokuapp.com/"); 
        requestSpecification.basePath("/booking/");
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.cookie("token", token);
        requestSpecification.body(payloadPUT).log().all();
        
        Response response = requestSpecification.post();

        // Validate status code 200
        response.then().statusCode(200);

		bookingID = response.jsonPath().getString("bookingID");
		System.out.println(bookingID);
		return bookingID;
	
		
		}

    @Test(priority = 1)  //Or can also sequence in pom.xml //
	public void test_update_request_put() {
    	
    	String payloadPUT = "{\"firstname\" : \"Mayur\", \"lastname\" : \"Brown\", "
				+ "      \"totalprice\" : 111, \"depositpaid\" : false, "
				+ "\"bookingdates\" : {\"checkin\" : \"2018-01-01\", \"checkout\" : "
				+ "\"2019-01-01\"}, \"additionalneeds\" : \"Lunch\"}";
		
		requestSpecification = RestAssured.given();
		requestSpecification.baseUri("https://restful-booker.herokuapp.com/");
		requestSpecification.basePath("/booking/"+ bookingID);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.cookie("token", token);
		requestSpecification.body(payloadPUT).log().all();
		
		Response response = (Response) requestSpecification.when().put();
		ValidatableResponse validatableResponse = ( ValidatableResponse) requestSpecification.then().log().all();
		validatableResponse.statusCode(200);
		
    	
    	   	
		
	}
	
	@Test(priority = 2)
	public void  test_update_request_get() {
		
		
		requestSpecification = RestAssured.given();
		
		requestSpecification.contentType(ContentType.JSON);
		
		
		requestSpecification.when().get("/booking/" + bookingID);
        
		requestSpecification.then().statusCode(200);
        
		requestSpecification.body("booking.firstname").equals("Mayur");
		
		
		
		
		
		
		
		
				
		
	}
	
	
	
	
	@Test(priority = 3)
	public void test_delete_booking() {
//		System.out.println(bookingID);
		//		System.out.println(token);
		
	}
	

	@Test(priority = 4)
	public void test_delete_get() { 
//		System.out.println("Done");
		
	}





}
