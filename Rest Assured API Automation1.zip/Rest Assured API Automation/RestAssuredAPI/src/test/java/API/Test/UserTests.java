package API.Test;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import API.Endpoints.UserEndPoints;
import API.Payload.User;
import io.restassured.response.Response;


public class UserTests {
	
  Faker faker;
  User userPayLoad;
	

  @BeforeClass
  public void setupData() {
  
  
  faker = new Faker();
  userPayLoad = new User();
  
  userPayLoad.setId(faker.idNumber().hashCode());
  userPayLoad.setUsername(faker.name().username());
  userPayLoad.setFirstname(faker.name().firstName());
  userPayLoad.setLastname(faker.name().lastName());
  userPayLoad.setEmail(faker.internet().safeEmailAddress());
  userPayLoad.setPassword(faker.internet().password());
  userPayLoad.setPhone(faker.phoneNumber().cellPhone());
  
  
 }

  @Test(priority=1)
  
  
  public void testpostUser(){
	  
	   Response response = UserEndPoints.CreateUser(userPayLoad);
	   response.then().log().all();
	   
	   Assert.assertEquals(response.getStatusCode(),200);
	   
  }
  
  @Test(priority=2)
  public void testgetUser() {
	  
	  
	 Response response = UserEndPoints.ReadUser(this.userPayLoad.getUsername());
	 response.then().log().all();
	 Assert.assertEquals(response.getStatusCode(),200);
  }
  
  
  @Test(priority=3)
  public void testupdateuserbyname() {
	  //Update the payload //
	  
	  userPayLoad.setFirstname(faker.name().firstName());
	  userPayLoad.setLastname(faker.name().lastName());
	  userPayLoad.setEmail(faker.internet().safeEmailAddress());
	  
	  
	  Response response = UserEndPoints.UpdateUser(this.userPayLoad.getUsername(), userPayLoad);
		 response.then().log().all();
		 response.then().log().body().statusCode(200);
//OR     Assert.assertEquals(response.getStatusCode(),200);
		
		 //Checking data after update //
		 Response responseafterupdate = UserEndPoints.ReadUser(this.userPayLoad.getUsername());
		 responseafterupdate.then().log().all();
		 Assert.assertEquals(responseafterupdate.getStatusCode(),200);
		 }
  
  
  @Test(priority=4)
  public void testDeleteUserbyname() {
	  
	  Response response = UserEndPoints.DeleteUser(this.userPayLoad.getUsername());
		 response.then().log().all();
	  
  }
  
  
  
  
  }
  
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 
