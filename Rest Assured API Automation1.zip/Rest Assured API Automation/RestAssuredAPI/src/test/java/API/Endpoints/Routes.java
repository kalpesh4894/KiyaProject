package API.Endpoints;

//https://petstore.swagger.io/v2/user
//

//Routes contains only URL'S //

public class Routes {

	
	public static String base_url = "https://petstore.swagger.io/v2";
	                                 
	//user module
// 	POST UPDATE DELETE 
	public static String post_url = base_url + "/user";
	
	public static String  get_url = base_url + "/user/{username}";
	public static String update_url = base_url + "/user/{username}";
	public static String delete_url = base_url + "/user/{username}";                                 
	 
	
	//Store module//
	//Here you will create store module url's 
	 
	//Pet Module 
	//Here you will create pet module url's 
	
	
}
